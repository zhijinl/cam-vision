
Geometric Marked Point Pattern {#tuto_rpatt_geom}
================================================================================


--------------------------------------------------------------------------------

## Summary

--------------------------------------------------------------------------------

This calss represents random point patterns with **geometric shape object as mark**.
It offers various APIs enabling:
- **Constructions** of geometric random point patterns:
  + either by hand.
  + via input data structure.
  + or by I/O operations.
- **Query** of patern properties & pattern elements:
  + access of points, marks individually or as a whole.
  + access geometric properties of the pattern such as bounding_box, volume etc.
  + query overlap ratio of an element with respect to the rest.
  + perform inside test query with input points or point matrix.
- **Modifications** on ensemble elements in the pattern.
  + Trivial modifications: modify observation window, perform translation, remove
  element & slicing of element given an logical bool vector.
  + Thinning operations, including independent thinning with retaintion
   probability value. Or functional ( possibly  dependent) thinning with
   retaintion probability function.
  + Constrain operation based on input criteria.
- **Discretization** of an analytical geometric pattern into a lattice / discrete
  binary random field based on desired spacing / resolution, domain or even value
  rules.


--------------------------------------------------------------------------------

## Class signatures

--------------------------------------------------------------------------------

            stogeo::MarkedPointPattern<Mark>

@param Mark: type of a geomtric shape, anything from stogeo::shapes.


--------------------------------------------------------------------------------

## Construction of a geometric marked point pattern.

--------------------------------------------------------------------------------

stogeo::MarkedPointPattern<Mark> offers three types of constructions:
- **Empty pattern construction** followed by **stogeo::MarkedPointPattern<Mark>::append**
  method.
- **Construction using `Eigen::Matrix`**. Note that the input matrix should be a
  **matrix representation** of an ensemble of geometric shapes. Meaning that
  **each column** of the matrix should be a **vector representation** of the
  shape. A **vector representation** of a shape is an Eigen fixed-size vector
  containing the center positions plus the parameters of a shape shape object.
  It is specified in the `vpack_t` typedef in every `stogeo::shapes` class.
  See for example `stogeo::shapes::Ellipsoid::vpack_t` for detail.
- **Construction using `std::vector`** of shape elements.
- Copy or move construction.

@warning When construction using `std::vector` of shape elements is used, extra
care should be taken for `allocator_type` passed to the `std::vector`. Actually
due to **alignment issues** related to Eigen's fixed-size vectors, it is dangerous
to pass default `allocator_type` to a `std::vector` containing `stogeo::shapes`,
since all `stogeo::shapes` elements store internally **Eigen's fixed-size** vectors.
A convenient typedef `alloc_t` is provided for all `stogeo::shapes` classes to
retreive the correct `allocator_type` that should be passed to `std::vector`.
@sa [Using STL containers with Eigen]
(http://eigen.tuxfamily.org/dox-devel/group__TopicStlContainers.html?_sm_au_=inVkRNWV7883Ns07)

Here are some examples demonstrating different ways to construct
MarkedPointPattern<Mark> s:

> #### 1. Empty construction followed by `append` method.
@include ex_gmpatt_ctor_append.cc

> #### 2. Construction using `Eigen::Matrix`.
@include ex_gmpatt_ctor_matrix.cc

> #### 3. Construction using `std::vector` of shape elements.
@include ex_gmpatt_ctor_vector.cc


--------------------------------------------------------------------------------

## Query operations.

--------------------------------------------------------------------------------

> #### 1. Basic const & non-const query.

- **Access properties** of the current pattern.
  + Access the **current observation winodw** through
    `stogeo::MarkedPointPattern::window`.
  + Access **current number of elements** through
    `stogeo::MarkedPointPattern::n_elem`.
  + Get the **current bounding box** of the pattern through
    `stogeo::MarkedPointPattern::bounding_box`.
  + Get the **current volume** of the pattern observation window through
    `stogeo::MarkedPointPattern::volume`.
    
- **Access points** as a whole or individually. This is offered by the
  `stogeo::MarkedPointPattern::pts()` (return a matrix containing all shape
  centers, in column direction) and `stogeo::MarkedPointPattern::pt(int)` (return
  center of a shape object of given index) methods.

- **Acess marks** as a whole or individually. This is offered by the
  `stogeo::MarkedPointPattern::marks()` (return the internal `std::vector`
  containing all shapes) and `stogeo::MarkedPointPattern::mark(int)` (return
  shape element of given index) methods.

@warning The `stogeo::MarkedPointPattern::pts()` in this case **does not return
a reference**. Instead a new matrix is constructed and returned by value. The
reason of this incosistency stems from the fact that all shape elements are
stored internally into a `std::vector`, therefore a matrix containing all shape
element centers has to be constructed from scratch.

Here are some examples showing typical use cases.
@include ex_gmpatt_access.cc


> #### 2. Advanced query.

- An **inside testing** query can be performed on an input point or input point
  matrix with respect to current geometric pattern. This is offered by the method
  `stogeo::MarkedPointPattern::inside_test`.
- **Overlapping ratio** of one element with the rest can be computed using
  `stogeo::MarkedPointPattern::overlap_ratio_mcmc` and
  `stogeo::MarkedPointPattern::overlap_ratio_lattice`.
  + The first version uses random **uniform sampling technique**. The overlap
    ratio is approximately computed as the ratio of number of points inside the
    intersection and the total number. It is **very fast, but not accurate**.
  + The second version discretize the queried shape to a lattice system and the
    ratio is computed using regular counting. It is **relatively slow** compared
    with the first version, but the **result is much more accurate**.

Here are some examples showing typical use cases.
@include ex_gmpatt_advanced.cc


--------------------------------------------------------------------------------

## Point pattern modifications.

--------------------------------------------------------------------------------

> #### 1. Trivial element modifications.

- The **observation window can be reset** through
  `stogeo::MarkedPointPattern::set_window` method.
- The `stogeo::MarkedPointPattern::translate` method **translates** each element by
  a vector, aka an Eigen fixed-size column vector of size dim.
- The `stogeo::MarkedPointPattern::remove` method **removes** element with given
  index.
- The `stogeo::MarkedPointPattern::slicing` deletes mutilple elements at a time.
  This method takes a **logical vector** as the input specifying which element
  at each position should be deleted or not. The logical vector could be an
  `std::vector<bool>` or an Eigen column Boolean vector.

@warning Calling `stogeo::MarkedPointPattern::set_window` will not examine if all
elements are still inside the new observation window. Users can can that manually
via iterating though all elements and call sub-sequent operations.

Here are some examples showing typical use cases.
@include ex_gmpatt_modif.cc

> #### 2. Transformations: thinning & constrain.

**Thinning** is the process of randomly deleting element based on user defined
criteria. This is offered by the `stogeo::MarkedPointPattern::thinning` function.
The criteria can be:
- A retaintion prbability **value**: specifiy the probability that an element
  will get deleted. This performs an **independent thinning**.
- A retaintion probability **function**: a function taking const reference of
  a shape element and returning a probability value (betwenn 0 and 1). Could be a
  **functor** or a **lambda expression**. This can acheive **dependent
  thinning**.

A **special case of thinning** is offered by stogeo::the method
`stogeo::MarkedPointPattern::constrain`. This method's input argument is a functor
or lambda expression taking const reference of a shape element, and return a
Boolean value specifying **whether** an element should be deleted or not.

Here are some examples showing typical use cases.
@include ex_gmpatt_thinn.cc

> #### 2. Discretization.

Discretization is the process of **transforming an analytical geometric point
pattern to a discrete binary image or volume** depending on the dimension. It
is offer bby the method `stogeo::MarkedPointPattern<Mark>::discrete`. For input
arguments, the desired spacing / resolution and (optionally) values to assigned
to positions inside & outside the shape element need to be given. Alternatively,
a cmn::Domain could also be passed in the place of spacing / resolution.

Here are some examples showing typical use cases.
@include ex_gmpatt_disc.cc


--------------------------------------------------------------------------------

## I/O operations.

--------------------------------------------------------------------------------

- Read a geometric marked point pattern from a **text file**. The input text
  file must represent a **row-ordered matrix**, each row represent the **vector
  representation** of a shape element.
- Write a geometric marked point pattern into a **text file**. The text file
  will be filled with a **row-ordered matrix**, each row represent the **vector
  representation** of a shape element.

The follwing example demonstrates the trivial use case.
@include ex_gmpatt_io.cc
