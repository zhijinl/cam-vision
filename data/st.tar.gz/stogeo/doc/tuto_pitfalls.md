
Common Usage Pitfalls {#tuto_pitfalls}
================================================================================


--------------------------------------------------------------------------------

## Summary

--------------------------------------------------------------------------------

This is a detailed summary of advanced usages & common usage pitfalls of `StoGeo`
libray & its `Eigen` backend. It targets mainly:
- Developers that are **contributing or considering contributing** to `StoGeo`.
- **Advanced users** that require **maximum runtime efficiency** of the library.

Common users and common usage cases are probably not going to be affected by
what's described here, but I recommand every user to **at least scan through
the tutorial**, because it is always good to acknowledge that there are traps &
caveats related to this library. And who knows, one day you might become advanced
user or contributor, and this page will help you **avoid shooting yourself in the
foot easily**.

The following subjects are discussed in detail:
- **Alignment issue** with **fix-sized** `Eigen` object, its impact on arguments
  passing, `STL` container usage & and its solutions.
- Using the `auto` keyword and **perfect forwarding** with `Eigen` expressions:
  why you should **be carefull with them**.
- Ternary operator with `Eigen` expressions: why you should be cautious.
- Ways to write **generic functions** taking `Eigen` structures as input, with
  **maximum efficiency**:
  * The **almost-ok way**.
  * The **optimal way**.
  * And the **wrong way_S_**.
- `Eigen` 3.2 APIs -> 3.3 APIs: **what changed** and how it is related to using
  `StoGeo`.
