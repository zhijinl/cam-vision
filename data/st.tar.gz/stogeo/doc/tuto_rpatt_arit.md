
Arithmetic Marked Point Pattern {#tuto_rpatt_arit}
================================================================================


--------------------------------------------------------------------------------

## Summary

--------------------------------------------------------------------------------

Random point pattern with arithmetic marks.


--------------------------------------------------------------------------------

## Class signatures

--------------------------------------------------------------------------------

            stogeo::MarkedPointPattern <PScalr.PDim,MScalr,MDim>

@param PScalr: data type for scalar used for point corrdinates.
@param PDim: dimension of the points.
@param MScalr: data type for mark's value.
@param MDim: dimension of the marks.


--------------------------------------------------------------------------------

## Usage Examples

--------------------------------------------------------------------------------
