
StoGeo Tutorials {#tuto_main}
================================================================================


This is the main page for **StoGeo** tutorials.

For **advanced users**, before you start, you might want to first read this
dedicated page for **Common Usage Pitfalls:** @subpage tuto_pitfalls. Normal
users may choose to skip this one, but it is **recommanded to read it anyway**.

Detailed tutorials are divided into the following sessions:

1. Multivariate Statistics                       @subpage tuto_stats

2. Geometric Primitives                          @subpage tuto_shape

3. Random Point Patterns                         @subpage tuto_rpatt

4. Point Processes                               @subpage tuto_pproc

5. Spatial Statistics                            @subpage tuto_spats

6. Utilities                                     @subpage tuto_utils
