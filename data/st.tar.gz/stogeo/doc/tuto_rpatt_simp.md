
Simple Point Pattern {#tuto_rpatt_simp}
================================================================================


--------------------------------------------------------------------------------

## Summary

--------------------------------------------------------------------------------

This calss represents simple random point patterns. It internally stores an
`Eigen` column majored matrix, containing **each column a point position**.
