# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...

  // Construct a marked point pattern with spheric window.
  using window_type = shapes::Sphere<dtype,dim>;

  // ...

  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ... fill it with elements.
  using Point = Eigen::Matrix<dtype,dim,1>;
  auto field = mpp.discrete(Point{0.1, 0.1, 0.1}, 42.0f, 0.0f);
  // Resolution is isotropic 0.1 / pixel. Positions inside patterns shapes
  // are assigned 42, outside 0. Discretization is done inside obs_window.

  // Note: an Image / Volume of float is deduced. If the 2nd & 3rd argument
  // are not available, the data type need to be given explicitly:
  auto field2 = mpp.template discrete<short>(Point{0.1, 0.1, 0.1});
  // An Image / Volume of short is created. By default inside val = 0,
  // outside = 1. Discretization is done inside obs_window.

  // Create a domain, see reference API of this function for detail.
  auto domain = utils::make_cmn_domain(origin, spacings, sizes);
  auto field3 = mpp.template discrete<short>(domain);
  // This uses domain's sizes & spacing for discretization.
}
