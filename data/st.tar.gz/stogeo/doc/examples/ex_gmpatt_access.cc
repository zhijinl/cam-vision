# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...

  // Construct a marked point pattern with spheric window.
  using window_type = shapes::Sphere<dtype,dim>;

  // ...

  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ... fill it with elements.

  auto n_elem = mpp.n_elem(); // Access number of elements.
  auto window = mpp.template window<window_type>(); // Get current window.
  auto bound = mpp.bounding_box(); // Bounding box is an Eigen dim x 2 matrix.
  auto voulme = mpp.volume(); // Get volume of current observation window.

  // ...
}
