# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...

  // Construct a marked point pattern with spheric window.
  using Point = Eigen<dtype,dim,1>;
  using window_type = shapes::Sphere<dtype,dim>;

  // ...

  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ... fill it with elements.

  mpp.thinning(0.1); // Independent thinning with retaintion probability 0.1.
  mpp.thinning( [/* capture &mpp itself if dependent thinning is desired */]
                (const shapes::Ellipsoid<dtype,dim> &ellip)
                {
                  return /* ... compute retaintion probability. */;
                }); // (Possibly dependent thinning) by a lambda.

  mpp.constrain( [/* capture &mpp itself if dependent thinning is desired */]
                 (const shapes::Ellipsoid<dtype,dim> &ellip)
                 {
                   return /* ... This return a Boolean here. */;
                 }); // Delete any element with a false result.
  // ...
}
