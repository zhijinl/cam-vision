# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...
  std::string path = /*...*/;
  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window);

  mpp.read_from(path); // Load a marked point pattern from text file.

  // ... some processing.

  std::string new_path = /*...*/;
  mpp.write_to(new_path); // Write down result.
}
