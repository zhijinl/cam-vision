# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...

  // Construct a marked point pattern.
  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ... fill it with elements.

  using Point = Eigen::Matrix<dtype,dim,1>;
  using PtsMat = Eigen::Matrix<dtype,dim,Eigen::Dynamic>;

  Point pt = /* ... initialize. */;
  PtsMat pt_mat = /* ... initialize. */;

  bool result = mpp.inside_test(pt); // Query 1 point.
  auto vec = mpp.inside_test(pt_mat); // Quer point matrix. Returns bool vector.
  
  // ...
}
