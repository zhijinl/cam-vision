# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...

  // Construct a marked point pattern with spheric window.
  using Point = Eigen<dtype,dim,1>;
  using window_type = shapes::Sphere<dtype,dim>;

  // ...

  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ... fill it with elements.

  shapes::Box<dtype,dim> box(origin, 100, 100, 100);
  mpp.set_window(box); // Set new window.
  mpp.remove(0);       // Remove first element.
  mpp.translate(Point{10, 5, 5}); // Translate all points byb (10, 5, 5).

  // ... Initialize a slicing logical vector.
  Eigen::Matrix<bool,Eigen::Dynamic,1> lv(mpp.n_elem());
  // ... Initialize it.
  mpp.slicing(lv, true); // Elements indicated as false will get deleted.

  // ...
}
