# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...
  
  // Create a std::vector containing all the shapes.
  // First we need to use the right allocator_type.
  using alloc_t = typename shapes::Ellipsoid<dtype,dim>::alloc_t;
  std::vector<shapes::Ellipsoid<dtype,dim>,alloc_t> mark_vec;

  // ... fill in the vector.
  
  // Construction.
  MarkedPointPattern<shapes::Ellipsoid<dtype,dim> > mpp(window,mark_vec);

  // ...
}
