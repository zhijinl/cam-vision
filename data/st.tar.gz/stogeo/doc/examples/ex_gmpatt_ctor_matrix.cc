# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"

using namespace stogeo;

int main()
{
  // ...
  
  // Create a matrix pack.
  constexpr int n_params = shapes::Sphere<dtype,dim>::n_params;
  Eigen::Matrix<dtype,dim+n_params,-1> mat_pack(dim+n_params,pts.n_elem());

  // ... fill map_pack with elements:
  // each column contains shape center & parameters
  
  // Construction.
  MarkedPointPattern<shapes::Sphere<dtype,dim> > mpp(window,mat_pack);
  
  // ...
}
