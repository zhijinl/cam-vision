# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"

using namespace stogeo;

int main()
{
  // Define data types.
  using dtype = double;
  constexpr int dim = 3;
                                                         
  // Observation window is a sphere of radius 50 centered at the origin.
  shapes::Sphere<dtype,dim> window(origin, 50.0);
                                                         
  // Create empty pattern. Pre-allocate memory for 1e5 elements.
  constexpr int n_elem = 1e5;                            
  MarkedPointPattern<shapes::Sphere<dtype,dim> > mpp(window, n_elem);
  std::cout << "Number of elements: " << mpp.n_elem() << '\n';
  // Note: number of elements is always 0.
  
  // Append random spheres.
  for(int n = 0; n < n_elem; ++n) mpp.append(sphere.draw(origin));

  // Append can also forward constructor arguments of shape class.
  // This internally performs an in-place construction of shape element.
  for(int n = 0; n < n_elem; ++n) mpp2.append(origin, rnd_radius.draw());
  // This append forwards arguments to Sphere constructor.

  return 0;
}
