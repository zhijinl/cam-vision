
Random Point Patterns {#tuto_rpatt}
================================================================================


--------------------------------------------------------------------------------

## Overview

--------------------------------------------------------------------------------

This module contains **random point patterns**. Three types of random point
patterns exist in `StoGeo`:
- **Simple point pattern**: stogeo::SimplePointPattern which internally stores
  a **point matrix** in forms of an `Eigen` column majored matrix.
- **Geometric marked point pattern**: stogeo::MarkedPointPattern<Mark>,
  where marks are stogeo::shapes objects.
- **Arithmetic marked point pattern**: stogeo::MarkedPointPattern, where
  marks are `Eigen` fixed-size vectors, or arithmetic numbers if mark
  dimension is 1.

Similar interfaces are offered for both classes, containing:
- **Construction** of point patterns via **rmpty construction followed by
  `append`** & **construction using data structures**.
- **Query access** (constant and/or non-constant) of point & mark elements &
  pattern properties.
- **Manipulations** of point & mark elements via **remove**, **constrain**
  & **arithmetic / functional thinning** operations etc.
- **I/O operations** through reading & writing points and/or marks from & to
  text files.


--------------------------------------------------------------------------------

## Tutorials

--------------------------------------------------------------------------------

For detailed tutorials, see the following chapters:

1. On @subpage tuto_rpatt_simp

2. On @subpage tuto_rpatt_geom

3. On @subpage tuto_rpatt_arit
