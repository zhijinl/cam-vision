
--------------------------------------------------------------------------------

## StoGeo: a header-only C++ Library for Stochastic Geometry, Spatial Statistics.

Author: Zhijin Li [jonathan.li@ge.com](jonathan.li@ge.com)

--------------------------------------------------------------------------------
   <br><br>


--------------------------------------------------------------------------------

### Project entries

--------------------------------------------------------------------------------

* **Soure code pages**:
    - On **OpenGE**: [Link](https://openge.ge.com/gf/project/stogeo/)
    - On **GitHub**: [Link](https://github.build.ge.com/212329445/stogeo)

* **Documentation page**:
    - **StoGeo tutorials & design documentation**: [Link]
      (https://github.build.ge.com/pages/212329445/stogeo_doc/)

   <br><br>


--------------------------------------------------------------------------------

### Overview

--------------------------------------------------------------------------------

StoGeo is a C++ library for **2D & 3D stochastic/random geometry** and
**multivariate statistics**. It is implemented using standard C++11 features.
The library is developed under the following philosophies:

- **Headers-only**: no runtime linking is needed to install the library.
- **Generic**: classes & functions are templated offering high level of genericity.
- **Optimized for peformance**: one of the goal of the project is to offer high
 performance computation for three-dimensional point statistics. Most of the
 features are benchmarked against several alternative implementations.
   <br><br>


--------------------------------------------------------------------------------

### Features

--------------------------------------------------------------------------------

StoGeo contains the following features:

1. **Multivariate statistics**. @ref tuto_stats.
   - A carefully implemented **random seeding scheme**, enabling **long-runing
     Monte Carlo simulations** & also **reproducible experiments**.
   - Common **univariate probability distributions**:
     `stogeo::rnd::Bernoulli`, `stogeo::rnd::RUniform`,
     `stogeo::rnd::Poisson`, `stogeo::rnd::Gaussian`.
   - Common **multivariate probability distributions**:
     `stogeo::rnd::MultiNomial`, `stogeo::rnd::MultiNormal`
   - Generic wrapper for **user-defined probability distribution function** of
     any dimension: `stogeo::rnd::Distribution`.
   - **Statistical samplers**:
     + Either from **analytically defined** `stogeo::rnd::Distribution` objects.
     + Or from **empirical data**: `stogeo::stats::InverseSampler`,
       `stogeo::stats::RejectSampler` and
       `stogeo::stats::AdaptRejectSampler` etc.
   - Various **statical estimators**: order statistics, kernel density estimator
     with various kernels etc.
   <br><br>

2. **Geometric primitives**: @ref tuto_shape.
   <br> **Random or deterministic** common geometric objects, including:
   - `stogeo::shapes::Box`: a **deterministic** rectangle that is always aligned
     with canonical cartesian axes.
   - `stogeo::shapes::Sphere`: can have **random or deterministic** radius.
   - `stogeo::shapes::Ellipsoid`: can have **random or deterministic** axis
     lengths & orientation angles.
   - `stogeo::shapes::Rectangle`: can have **random or deterministic** axis
     lengths & orientation angles.
   Various interfaces are provided fro geometric primitives, including
   construction, manipulation, query, inside testing and discretization etc.
   Geometric primitives can be random (except for `stogeo::shapes::Box`), if
   it's the case, probability distribution object can be used to construct
   random primitive objects.
   <br><br>

3. **Random point patterns**: @ref tuto_rpatt.
   <br> They are **data structures containing obejects of interest of spatial
   statistics** and **realizations of different stochastic geometric
   processes**.
   - **stogeo::SimplePointPattern** contains **ensemble of randomly placed
     points**. It holds the realization of a simple poit process.
   - **stogeo::MarkedPointPattern** contains **ensemble of points together
     with marks**. It holds the realization a marked point process. Two types of
     marked point patterns are distinguished in `StoGeo`:
     + Geometric marked point pattern: `stogeo::MarkedPointPattern<Mark>`. It
       represents a point pattern having `stogeo::shapes` objects as marks.
     + Arithmetic marked point pattern: `stogeo::MarkedPointPattern`. It
       represents a point pattern having arithmetic marks.
   Interfaces provided for random point patterns includes: **construction**,
   **query**, **modification**, **transformation** and **I/O operations** etc.
   <br><br>

4. **Point processes**: @ref tuto_pproc.
   - **Simple point processes**, such as:
     + **stogeo::pps::BinomialPP** with arbitrary point probability
       distribution.
     + **Homogeneous Poison point processes** (expecting intensity value) and
       **inhomogeneous Poisson point processes** (expecting custom intensity
       function via `stogeo::pps::Intensity`): `stogeo::pps::PoissonPP`.
     + **Hardcore point process**: `stogeo::pps::HardcorePP` and
       `stogeo::pps::MaternHardPP` of type I, II & III.
     + **stogeo::pps::MaternClusterPP** with arbitrary `stogeo::shapes` type
       for cluster shape and homogeneous or inihomogeneous Poisson point process
       for local point process within a cluster.
   - **Marked point processes**, which are parametrized by an **arbitrary simple
     point process** and an extra **mark distribution**. The mark can be from
     random `stogeo::shapes` or a multivariate distribution object.
   <br><br>

5. **Spatial statistics**: @ref tuto_spats
   - Estimation of **summary statistics** from given point pattern:
     + **Intensity value or intensity function** in case of inhomogeneity.
     + **Pair correlation function**.
     + **Ripley's K-function**.
     + **Besag's J-function**.
     + **Empty space F-function**.
     + **Nearest neighbor G-function**.
   - **Fitting** a given point pattern to a chosen model, based-on:
     + **Minimum constrast** method.
     + **Maximum pseudo-likelihood** method.
   <br><br>

6. **Various utilities**: @ref tuto_utils
   - It contains a **tiny meta-programming libray** for **type traits helpers**,
     **compile time dispatchers** and **helpers for SFINAE type constraints**.
   - **Discrete operations**: interfaces enableing discretizing analytical
     objects into lattice systems, in order to play well with functionalities
     offered by the **common** and **mipp** libraries.
   - **I/O interfaces** for reading & writing Eigen types from & to text files,
     interacting with raw files etc.
   - Others like **computational methods on Eigen structure**, convenient
     manipulation on **random generator seed**, **generic pimpl idiom** etc.
   <br><br>


--------------------------------------------------------------------------------

### Dependencies

--------------------------------------------------------------------------------

Most of `StoGeo` is developed using the **C++11** standard features.
- It is **mandatory to have a compiler supporting C++11 features**
  (`G++4.8 or +`).
- It is **recommanded to update to lastest compiler version whenever it's
  possbible** to enable more advanced `C++14` & `C++17` features in the future.

`StoGeo` uses intensively the following libraries & featrures:
- `Eigen 3` library. It is **recommanded to have the lastest Eigen library
  installed**.
- `Boost` library. It is **recommanded to have the lastest Boost library
  installed**. The following features from boost are intensively used in
  `StoGeo`:
  + `boost::variant` ( -> `C++17 std::variant` whenever possible).
  + `boost::optional` ( -> `C++17 std::optional` whenever possible).
- The `Mammo Common` library, available from [OpenGE]
  (https://openge.ge.com/gf/project/mammo_cmn/).
- The `MIPP` library available from [OpenGE]
  (https://openge.ge.com/gf/project/mipp/)
   <br><br>


--------------------------------------------------------------------------------

### Installing StoGeo

--------------------------------------------------------------------------------

#### Easy install

`StoGeo` is a **header-only library**: **no actual linking is necessary**.
- To use the library, just include necessary `StoGeo` headers and **make sure
  that `StoGeo` is in your include search path**, and you are ready to go.
- Standard `autotools` are used only for library maintaining, automated unit-
  tests, and GNU standard installation. It is **perfectly fine if you ignore
  the autotools stuff**.

The following is an example including different `StoGeo` headers. In practice it
is recommanded to include **only header that are to be used** in your project.
The content of each header is exactly as it's name indicates.

~~~~~~~~~~~~{.cc}
# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "stogeo/discrete.hh"
# include "stogeo/geometry.hh"
# include "stogeo/utilities.hh"
# include "stogeo/statistics.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"
# include "stogeo/tessellations.hh"

int main()
{
  // ... use StoGeo features.
}
~~~~~~~~~~~~

#### Install & run unit-tests using `automake`

The **standard `autotools` utilities** are also provided, more particularly for
automatic testing & documentation generation. To generate a `configure` script,
run the following command **from out-of-source** directory. This will setup the
build environment.

    /src/path/bootstrap.sh <path/to/dependencies> <path/to/prefix/dir> <extra...>

Mandatory flags are (in-order):
  + `<path/to/dependencies>`, path to **pre-installed dependency libraries**.
  + `<path/to/prefix/dir>`, path to installation prefix.

Extra flags are (in-order):
  + `CMN_VERSION=`, provide `no` if you want to manually specify the `Common`
    library path or let configure search under `LOCAL_DIR`.
  + `MIPP_VERSION=`, provide `no` if you want to manually specify the `MIPP`
    library path or let configure search under `LOCAL_DIR`.
  + `--with-Eigen`, path to `Eigen 3` library.
  + `--with-boost`, path to `Boost` library.
  + `--with-voro`, path to `Voro++` library.

- Use `make` and `make check` to run automatic unit-testing.
- Use `make doc` to generate the API documentation.

- Use `make install` to copy header files under `LOCAL_DIR/include/stogeo` and
  doc files under `LOCAL_DIR/share/doc/stogeo`.

- Use `make uninstall` to remove installed headers and docs. Use `make clean`
  and `make distclean` to clean up (in-tree) for a clean re-build.
   <br><br>


--------------------------------------------------------------------------------

### Usages

--------------------------------------------------------------------------------

#### Before you start

I **strongly recommand** that you read this @ref_pitfalls tutorial page. Inside
it you will find detailed explanation of:
- How to used `StoGeo` & its `Eigen` backend **effectively and correctly**.
- Common **pitfalls** that are related either to the C++ language itself or 3rd
  party libraries.

In normal use cases, such as using `StoGeo`'s random model for **reproducible
Monte Carlo simulations**, you generally **do not need to worry about all the
stuff described in this tutorial**. It does target more advanced users that have
fairly complete understanding of the C++ language. However, it is **still worth
your time to acknowledge these pitfalls, so that if one day you shoot yourself
in the foot, you'll known where to look for help**.

#### How-tos

Tutorials on different `StoGeo` modules are available: @ref tuto_main. You'll find
almost all **common usages** there.
