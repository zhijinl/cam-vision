// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// VoronoiDiagram.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Dec  9 14:13:21 2015 Zhijin Li
// Last update Tue Jun 12 14:07:13 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_VORONOIDIAGRAM_HH
# define STOGEO_VORONOIDIAGRAM_HH

# include <vector>
# include "../PointPatterns/SimplePointPattern.hh"


namespace stogeo
{

  // Fwd decl.
  namespace tess
  { template<typename T, int Dim> class VoronoiDiagram; }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::tess::VoronoiDiagram`
    /// class.
    ///
    template<typename T, int Dim> struct specs<tess::VoronoiDiagram<T,Dim> >
    {
      static const stg_ids stg_id =  stg_ids::STOGEO_MSAIC;
      typedef SimplePointPattern<T,Dim>            field_t;
      typedef T                                    scalr_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>    vectr_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1> slice_t;
    };
  }


  /// @defgroup group_tess Random Tessellations
  ///
  /// @brief Stochastic tessellation processes such as Voronoi tessellation
  /// etc.

  /// @ingroup group_tess
  namespace tess
  {
    /// @ingroup group_tess
    ///
    /// @brief Class for Voronoi Tessellation / Diagram
    ///
    /// @warning This class is implemented using the Voro++ library. No
    /// optimization was ever attempted. It is currently **neither scalable to
    /// arbitrary dimension, nor generic**.
    ///
    /// Even though the class is templated, `Voro++` however use `double` for
    /// all internal computations.
    ///
    /// @param T: scalar type. Note that **all internal computations uses
    /// actually `double`**, due to `Voro++` library's internal implementation.
    /// @param Dim: **it currently works only for 3D.**
    ///
    template<typename T, int Dim> class VoronoiDiagram
    {

      static_assert(Dim == 3,
                    "ERROR: CURRENT BACKEND ONLY SUPPORTS 3D VORONOI.");

    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t = VoronoiDiagram<T,Dim>;
      using specs_t = traits::specs<exact_t>;
      using field_t = typename specs_t::field_t;
      using scalr_t = typename specs_t::scalr_t;
      using vectr_t = typename specs_t::vectr_t;
      using slice_t = typename specs_t::slice_t;

      template<typename ValueType> using image_t = cmn_img_t<ValueType,Dim>;

      using vcell_t = voro::voronoicell;
      using point_t = Eigen::Matrix<double,3,1>; // Voro++ uses double.
      using bound_t = Eigen::Matrix<double,Dim,2>; // Likewise.
      using matrx_t = Eigen::Matrix<double,3,Eigen::Dynamic>; // Likewise.

      /// @brief Ctor.
      ///
      /// @param pattern: the input point pattern containing
      /// all Voronoi cell centers.
      /// @param b_blocks: number of blocks used by Voro++ cutting-plane
      /// algorithm. Defaults to 8. The default value may cause runtime
      /// error when the number of cell centers is too large.
      ///
      VoronoiDiagram(const field_t &pattern, int n_blocks=8);

      /// @brief Get number of paticles.
      ///
      /// @return Number of particles in current diagram.
      ///
      int n_particles() const
      {
        return const_cast<exact_t*>(this)->_contner.total_particles();
      }

      /// @brief Assign value to chosen cells.
      ///
      /// Discretize the Voronoi diagram. Assign specific value to
      /// certain cells specified by a bool vector.
      ///
      /// @warning Unspecified cells will **not be assigned 0**.
      /// Instead their values will __untouched__. This means, it is
      /// recommanded to initialize the input volume before calling
      /// the assign function.
      ///
      /// @param vol: the input/output volume to hold the discretized
      /// Voronoi diagram. A non-owning raw pointer.
      /// @param spacing: an Eigen floating-point vector specifying the
      /// spacing of the input/output volume.
      /// @param val: the value to be assigned to a the chosen subset
      /// of cells.
      /// @param lv: a logical vector, i.e. Eigen bool column vector
      /// specifying which cells will be assigned the value `val`. If
      /// `lv(k) = 1`, the k_th cell will be assigned value `val`.
      /// Otherwise it will be **untouched**.
      /// @param epsilon: tolerance parameter for discrtization error.
      /// It defaults to 0.1, which is __generally__ ok for simulations
      /// at high resolution. The bigger the epsilon value is, more the
      /// Voronoi cells will be deformed. Inversely, the smaller
      /// epsilon is, the more __residual__ voxels you'll observed in
      /// discretized result.
      ///
      template<typename ValueType, typename Point>
      void assign_cell_if(ValueType *vol,
                          Point &&spacing,
                          ValueType val,
                          const slice_t &lv,
                          scalr_t epsilon=0.1);

      /// @brief Assign value to chosen cells.
      ///
      /// Discretize the Voronoi diagram. Assign specific value to
      /// certain cells specified by a bool vector.
      ///
      /// @warning Unspecified cells will **not be assigned 0**.
      /// Instead their values will __untouched__. This means, it is
      /// recommanded to initialize the input volume before calling
      /// the assign function.
      ///
      /// @warning The default `epsilonn = 0.1` is experimental: for
      /// high resolution simulations (<= 0.1) it's perfect. Lower
      /// resol still may have artifacts left around the cell face
      /// boundaries. In case of artifacts, you need to tweak epsilon
      /// to a more appropriate value.
      ///
      /// @param vol: the input/output volume to hold the discretized
      /// Voronoi diagram. A cmn volume object.
      /// @param val: the value to be assigned to a the chosen subset
      /// of cells.
      /// @param lv: a logical vector, i.e. Eigen bool column vector
      /// specifying which cells will be assigned the value `val`. If
      /// `lv(k) = 1`, the k_th cell will be assigned value `val`.
      /// Otherwise it will be **untouched**.
      /// @param epsilon: tolerance parameter for discrtization error.
      /// It defaults to 0.1, which is __generally__ ok for simulations
      /// at high resolution. The bigger the epsilon value is, more the
      /// Voronoi cells will be deformed. Inversely, the smaller
      /// epsilon is, the more __residual__ voxels you'll observed in
      /// discretized result.
      ///
      template<typename ValueType>
      void assign_cell_if(image_t<ValueType> &vol,
                          ValueType val,
                          const slice_t &lv,
                          scalr_t epsilon=0.1);

      /// @brief Assigns labels to the voxels in the specified volume
      /// @param vol: 3d discrete volume
      /// @param epsilon: tolerance parameter for discretization error
      ///
      template<typename ValueType>
      void label_cells(image_t<ValueType> &vol,
                          scalr_t epsilon=0.1);

      /// @brief Assigns labels to the voxels in the specified volume
      /// @param vol: 3d discrete volume
      /// @param n_labels: number of labelized cells
      /// @param lv: logical array
      /// @param epsilon: tolerance parameter for discretization error
      ///
      template<typename ValueType>
      void label_cells_if(image_t<ValueType> &vol,
                          int& n_labels,
                          const slice_t &lv,
                          scalr_t epsilon=0.1);

      /// @brief Outputs individual voxelized cells to an std::vector
      /// @param vol: 3d discrete volume
      /// @param vec: vector of cmn volume objects
      /// @param lv: logical array
      /// @param epsilon: tolerance parameter for discretization error
      ///
      template<typename ValueType>
      void output_cells_if(image_t<ValueType> &vol,
                            std::vector<image_t<ValueType>> &vec,
                            const slice_t &lv,
                            scalr_t epsilon=0.1);

      /// @brief Gathers cell centroids in a std::vector
      /// @param mask: 3d discrete volume. Voxels with value 0 are ignored
      /// when computing centroids
      /// @param centroids: std::vector of centroids
      /// @param epsilon: tolerance parameter for discretization error
      ///
      template<typename ValueType>
      void collect_centroids(const image_t<ValueType> &mask,
                             matrx_t& centroids,
                             scalr_t epsilon=0.1);

      /// @brief Gathers particles in a std::vector
      /// @param partcles: std::vector of particles
      /// @param epsilon: tolerance parameter for discretization error
      ///
      void collect_particles(matrx_t& particles,
                             scalr_t epsilon=0.1);

      /// @brief Computes the SSD (sum of squared differences) for the tessellation
      ///
      /// The SSD is based on the distance between each point and the centroid of
      /// its cell.
      ///
      /// @param vol: 3d discrete volume
      /// @param epsilon: tolerance parameter for discretization error
      /// @returm SSD value
      ///
      template<typename ValueType>
      double compute_global_distortion(const image_t<ValueType> &mask,
                                      scalr_t epsilon=0.1);

      /// @brief Updates the points of the Voronoi Diagram according to Lloyd's
      /// algorithm
      ///
      /// @param vol: 3d discrete volume
      /// @param epsilon: tolerance parameter for discretization error
      ///
      template<typename ValueType>
      void one_lloyd_iteration(const image_t<ValueType> &mask,
                                scalr_t epsilon=0.1);

      /// @brief Dtor.
      /// @note _contner owns pointers to data which is shared between copies
      /// of a given VoronoiDiagram. This data is invalidated for all copies
      /// when this dtor is called from one copy, causing a segfault for
      /// the next dtor call. For this reason, the following
      /// ctors and assignment operators are disabled
      ~VoronoiDiagram() { _contner.clear(); };

      /// @brief Disabled copy ctor.
      // VoronoiDiagram(const VoronoiDiagram &rhs) = delete;

      /// @brief Disabled Move ctor.
      // VoronoiDiagram(VoronoiDiagram &&rhs) = delete;

      /// @brief Disabled copy assignment operator.
      // exact_t& operator=(const VoronoiDiagram &rhs) = delete;

      /// @brief Disabled Move assignment operator.
      // exact_t& operator=(VoronoiDiagram &&rhs) = delete;


    private:

      /// @brief Compute cell statistics.
      ///
      /// @note
      /// - All face normals are converted to point
      ///   **inward**.
      /// - The reference point of each face is
      ///   its **first vectice in storage order**.
      ///
      /// @param cell_pos: the center position of the cell.
      /// An Eigen dim x 1 column vector.
      /// @param cell: the Voronoi cell of interest.
      /// @param vertices: an Eigen dynamic matrix to hold
      /// all the vertices of the input cell.
      /// @param nmls_mat: an Eigen dynamic matrix to hold
      /// all face normals of the input cell.
      /// @param refs_mat: an Eigen dynamic matrix to hold
      /// all face reference points of the input cell.
      ///
      void prep_cell_stats(const point_t &cell_pos,
                           vcell_t &cell,
                           matrx_t &vectices,
                           matrx_t &nmls_mat,
                           matrx_t &refs_mat);

      /// @brief Discretize and assign value to a single cell.
      ///
      /// @param vol: the input/output volume to hold the discretized
      /// Voronoi diagram. A non-owning raw pointer.
      /// @param spacing: an Eigen floating-point vector specifying the
      /// spacing of the input/output volume.
      /// @param val: the value to be assigned to a the chosen subset
      /// of cells.
      /// @param cell_pos: the center position of the cell.
      /// An Eigen dim x 1 column vector.
      /// @param cell: the Voronoi cell of interest.
      /// @param epsilon: tolerance parameter for discrtization error.
      /// The bigger the epsilon value is, more the
      /// Voronoi cells will be deformed. Inversely, the smaller
      /// epsilon is, the more __residual__ voxels you'll observed in
      /// discretized result.
      ///
      template<typename ValueType, typename Point>
      void assign_cell_impl(ValueType *vol,
                            Point &&spacing,
                            ValueType val,
                            const point_t &cell_pos,
                            vcell_t &cell,
                            scalr_t epsilon);

      /// @brief Discretize and assign value to a single cell.
      ///
      /// @param vol: the input/output volume to hold the discretized
      /// Voronoi diagram. A cmn volume object.
      /// @param val: the value to be assigned to a the chosen subset
      /// of cells.
      /// @param cell_pos: the center position of the cell.
      /// An Eigen dim x 1 column vector.
      /// @param cell: the Voronoi cell of interest.
      /// @param epsilon: tolerance parameter for discrtization error.
      /// The bigger the epsilon value is, more the
      /// Voronoi cells will be deformed. Inversely, the smaller
      /// epsilon is, the more __residual__ voxels you'll observed in
      /// discretized result.
      ///
      template<typename ValueType>
      void assign_cell_impl(image_t<ValueType> &vol,
                            ValueType val,
                            const point_t &cell_pos,
                            vcell_t &cell,
                            scalr_t epsilon);

      /// @brief Voxelizes a single cell and stores the result
      ///
      /// @param vol: the input/output volume to hold the discretized
      /// Voronoi diagram. A cmn volume object.
      /// @param img: pointer to voxelized cell recipient (cmn volume)
      /// @param cell_pos: the center position of the cell.
      /// An Eigen dim x 1 column vector.
      /// @param cell: the Voronoi cell of interest.
      /// @param epsilon: tolerance parameter for discrtization error
      ///
      template<typename ValueType>
      void output_cell_impl(image_t<ValueType> &vol,
                            image_t<ValueType>* img,
                            const point_t &cell_pos,
                            vcell_t &cell,
                            scalr_t epsilon);

      /// @brief Compute the centroid in a given cell
      /// @param mask: 3d discrete volume. Voxels with value 0 are ignored
      /// @param centroid: variable for storing the resulting centroid
      /// @param cell_pos: "center" position of the cell
      /// @param cell: Voronoi cell of interest
      /// @param epsilon: tolerance parameter
      ///
      template<typename ValueType>
      void compute_centroid(const image_t<ValueType> &mask,
                            point_t& centroid,
                            const point_t &cell_pos,
                            vcell_t &cell,
                            scalr_t epsilon);

      /// @brief Compute the distortion in a given cell
      /// @param mask: 3d discrete volume. Voxels with value 0 are ignored
      /// @param distortion: variable for storing the resulting distortion
      /// @param cell_pos: "center" position of the cell
      /// @param cell: Voronoi cell of interest
      /// @param epsilon: tolerance parameter
      ///
      template<typename ValueType>
      void compute_cell_distortion(const image_t<ValueType> &mask,
                                   double &cell_distortion,
                                   const point_t &cell_pos,
                                   vcell_t &cell,
                                   scalr_t epsilon);

      /// @brief Test if a point is inside a 3D polygon.
      ///
      /// @param pt: the querry point.
      /// @param face_nmls: an Eigen dynamic matrix containing all the
      /// face normals.
      /// @param face_refs: an Eigen dynamic matrix containing all the
      /// face reference points.
      /// @return True if the point falls inside the polygon.
      /// @param epsilon: tolerance parameter for discrtization error.
      /// The bigger the epsilon value is, more the
      /// Voronoi cells will be deformed. Inversely, the smaller
      /// epsilon is, the more __residual__ voxels you'll observed in
      /// discretized result.
      ///
      bool inside_polyhedra(const point_t &pt,
                            const matrx_t &face_nmls,
                            const matrx_t &face_refs,
                            scalr_t epsilon) const;

      int                  _n_cells;
      bound_t              _bnd_box;
      voro::container      _contner;
      voro::particle_order _p_order;
    };

  } //!tess
} //!stogeo


# include "VoronoiDiagram.hxx"
#endif //!STOGEO_VORONOIDIAGRAM_HH
