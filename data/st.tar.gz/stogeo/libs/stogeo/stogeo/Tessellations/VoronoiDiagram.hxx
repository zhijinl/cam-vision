// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// VoronoiDiagram.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Dec  9 15:49:17 2015 Zhijin Li
// Last update Mon Sep 25 17:12:31 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace tess
  {

    // =====================================================================
    template<typename T, int Dim>
    VoronoiDiagram<T,Dim>::VoronoiDiagram(const field_t &pattern,
                                          int n_blocks):
      _n_cells(pattern.n_elem()),
      _bnd_box(pattern.bounding_box().template cast<double>()),
      _contner(_bnd_box(0,0),_bnd_box(0,1),
               _bnd_box(1,0),_bnd_box(1,1),
               _bnd_box(2,0),_bnd_box(2,1),
               n_blocks,n_blocks,n_blocks,false,false,false,20),
      _p_order()
    {
      assert( (pattern.n_elem() > 0) && "err: no input points specified.");
      for(int __i = 0; __i < pattern.n_elem(); ++__i)
        _contner.put(_p_order,
                     __i,
                     pattern.pts().col(__i)(0),
                     pattern.pts().col(__i)(1),
                     pattern.pts().col(__i)(2));
    };

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType, typename Point>
    void VoronoiDiagram<T,Dim>::
    assign_cell_if(ValueType *vol,
                   Point &&spacing,
                   ValueType val,
                   const slice_t &lv,
                   scalr_t epsilon)
    {
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
          if(lv(__i))
          {
            // o in particle order stores pairs of (block_indx & relative_indx).
            int __block_indx = _p_order.o[2*__i];
            int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
            _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

            double *__pos_ptr = _contner.p[__block_indx]+
              __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
            for(auto __d = 0; __d < Dim; ++__d)
              __curr_particle(__d) = __pos_ptr[__d];

            assign_cell_impl(vol, spacing, val,
                             __curr_particle, __curr_cell, epsilon);
          }
          utils::loadbar(__i+1,_n_cells);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    assign_cell_if(image_t<ValueType> &vol,
                   ValueType val,
                   const slice_t &lv,
                   scalr_t epsilon)
    {
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
          if(lv(__i))
          {
            // o in particle order stores pairs of (block_indx & relative_indx).
            int __block_indx = _p_order.o[2*__i];
            int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
            _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

            double *__pos_ptr = _contner.p[__block_indx]+
              __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
            for(auto __d = 0; __d < Dim; ++__d)
              __curr_particle(__d) = __pos_ptr[__d];

            assign_cell_impl(vol,val,__curr_particle,__curr_cell,epsilon);
          }
          utils::loadbar(__i+1,_n_cells);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    label_cells(image_t<ValueType> &vol,
                scalr_t epsilon)
    {
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      ValueType label_value(0);

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
            // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            __curr_particle(__d) = __pos_ptr[__d];

          assign_cell_impl(vol,label_value,__curr_particle,__curr_cell,epsilon);
          utils::loadbar(__i+1,_n_cells);
          // potentially thread-unsafe assignment
          label_value += 1;
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    label_cells_if(image_t<ValueType> &vol,
                int& n_labels,
                const slice_t &lv,
                scalr_t epsilon)
    {
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      ValueType label_value(0);

      if(__voro_loop.start())
      {
        std::vector<ValueType> indexes;

        for(auto __k = 0; __k < _n_cells; ++__k)
        {
          if (lv(__k) > ValueType(0))
          {
            indexes.push_back(__k);
          }
        }
        n_labels = indexes.size();

#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __j = 0; __j < n_labels; ++__j)
        {
          auto __i = indexes[__j];
          // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
          // p (double **) stores particle positions. Access thru block_indx+
          // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            __curr_particle(__d) = __pos_ptr[__d];

          assign_cell_impl(vol, ValueType(__j + 1) ,__curr_particle,__curr_cell,epsilon);
          utils::loadbar(__i+1,_n_cells);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    output_cells_if(image_t<ValueType> &vol,
                    std::vector<image_t<ValueType>> &vec,
                    const slice_t &lv,
                    scalr_t epsilon)
    {
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      ValueType label_value(0);

      if(__voro_loop.start())
      {
        std::vector<int> indexes;

        for(int __k = 0; __k < _n_cells; ++__k)
        {
          if (lv(__k) > ValueType(0))
          {
            indexes.push_back(__k);
          }
        }
        int n_cells = indexes.size();
        vec.resize(n_cells);

#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __j = 0; __j < n_cells; ++__j)
        {
          auto __i = indexes[__j];
          // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
          // p (double **) stores particle positions. Access thru block_indx+
          // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            __curr_particle(__d) = __pos_ptr[__d];

          image_t<ValueType>* __res_ptr = &vec[__j];
          output_cell_impl<ValueType>(vol,__res_ptr,__curr_particle,__curr_cell,epsilon);
          utils::loadbar(__i+1,_n_cells);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T, Dim>::
    collect_centroids(const image_t<ValueType> &mask,
                            matrx_t& centroids,
                            scalr_t epsilon)
    {
      centroids.resize(Dim, _n_cells);
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
            // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            __curr_particle(__d) = __pos_ptr[__d];

          point_t __centroid;
          compute_centroid<ValueType>(mask,
            __centroid,
            __curr_particle,
            __curr_cell,
            epsilon);
          utils::loadbar(__i+1,_n_cells);
          centroids(0, __i) = __centroid(0);
          centroids(1, __i) = __centroid(1);
          centroids(2, __i) = __centroid(2);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    void VoronoiDiagram<T, Dim>::
    collect_particles(matrx_t& particles,
                      scalr_t epsilon)
    {
      particles.resize(Dim, _n_cells);
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
            // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            particles(__d, __i) = __pos_ptr[__d];

          utils::loadbar(__i+1,_n_cells);
        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    double VoronoiDiagram<T, Dim>::
    compute_global_distortion(const image_t<ValueType> &mask,
                              scalr_t epsilon)
    {
      double global_distortion(0);
      std::vector<double> cell_distortions;
      cell_distortions.resize(_n_cells);
      voro::c_loop_order __voro_loop(_contner,_p_order);
      voro::voronoicell __curr_cell;
      point_t __curr_particle;

      if(__voro_loop.start())
      {
#pragma omp parallel for private(__curr_cell,__curr_particle)
        for(auto __i = 0; __i < _n_cells; ++__i)
        {
            // o in particle order stores pairs of (block_indx & relative_indx).
          int __block_indx = _p_order.o[2*__i];
          int __relative_pos = _p_order.o[2*__i+1];

            // This is the most expensive operation.
          _contner.compute_cell(__curr_cell,__block_indx,__relative_pos);

          double *__pos_ptr = _contner.p[__block_indx]+
          __relative_pos*_contner.ps;
            // p (double **) stores particle positions. Access thru block_indx+
            // relative_indx.
          for(auto __d = 0; __d < Dim; ++__d)
            __curr_particle(__d) = __pos_ptr[__d];

          compute_cell_distortion<ValueType>
            (mask, cell_distortions[__i], __curr_particle, __curr_cell, epsilon);
          utils::loadbar(__i+1,_n_cells);
        }
      }

      for(int __j = 0; __j < _n_cells; ++__j){
        global_distortion += cell_distortions[__j];
      }

      return global_distortion;
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T, Dim>::
    one_lloyd_iteration(const image_t<ValueType> &mask,
                        scalr_t epsilon)
    {
      matrx_t centroids;
      collect_centroids<ValueType>(mask, centroids, epsilon);

      auto bbox_domain = mask.domain();
      float o0 = bbox_domain.originLU(0);
      float o1 = bbox_domain.originLU(1);
      float o2 = bbox_domain.originLU(2);

      point_t offset;
      offset << o0, o1, o2;

      _contner.clear();
      for(int __i = 0; __i < centroids.cols(); ++__i)
      {
        _contner.put(_p_order,
                     __i,
                     centroids(0, __i),
                     centroids(1, __i),
                     centroids(2, __i));
      }

    }

    // =====================================================================
    template<typename T, int Dim>
    void VoronoiDiagram<T,Dim>::
    prep_cell_stats(const point_t &cell_pos,
                    vcell_t &cell,
                    matrx_t &vertices,
                    matrx_t &nmls_mat,
                    matrx_t &refs_mat)
    {
      // Statistics of all faces.
      for(auto __c = 0; __c < 3*cell.p; ++__c)
        vertices(__c%3,__c/3) = cell_pos(__c%3)+cell.pts[__c]*0.5;

      std::vector<int> __orders; cell.face_orders(__orders);
      std::vector<int> __verts_indxing; cell.face_vertices(__verts_indxing);
      std::vector<double> __nmls; cell.normals(__nmls);

      // Iterate over all faces.
      auto __shift = 0;
      for(int __f = 0; __f < cell.number_of_faces(); ++__f)
      {
        // # of vertices of the current face.
        int __curr_order = __orders[__f];
        // The 1st vertex is chosen to be the reference.
        refs_mat.col(__f) = vertices.col(__verts_indxing[__shift+1]);
        // Normals are always pointing outwards the cell center in Voro++.
        nmls_mat(0,__f) = -__nmls[__f*3];
        nmls_mat(1,__f) = -__nmls[__f*3+1];
        nmls_mat(2,__f) = -__nmls[__f*3+2];

        __shift += (__curr_order+1);
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType, typename Point>
    void VoronoiDiagram<T,Dim>::
    assign_cell_impl(ValueType *vol,
                     Point &&spacing,
                     ValueType val,
                     const point_t &cell_pos,
                     vcell_t &cell,
                     scalr_t epsilon)
    {
      static_assert(is_eigen_v<Point>() &&
                    eigen_rows_v<Point>()==Dim,
                    "ERROR: EXPECTS AND EIGEN VEC FOR SPACING.");
      static_assert(is_floating_point_v<eigen_val_t<Point> >(),
                    "ERROR: SPACING MUST BE FLOATING POINT.");

      matrx_t __vertices(Dim,cell.p);
      matrx_t __nmls_mat(Dim,cell.number_of_faces());
      matrx_t __refs_mat(Dim,cell.number_of_faces());
      prep_cell_stats(cell_pos,cell,__vertices,__nmls_mat,__refs_mat);

      auto __cell_domain = utils::make_cmn_domain
        (utils::comp_bound(__vertices),spacing);
      point_t __curr_pos = point_t::Zero();
      cmn_fwditr_t<Dim> __cell_it(__cell_domain);
      cmn_for_all(__cell_it)
      {
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it);
        // inside_cell_test.
        if( inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
            utils::in_bound(__curr_pos,_bnd_box) )
          // Note: domain is alwys bigger than the real bound.
          // (To ensure absolute inclusion of all test points)
          // in_bound is important here: otherwise segfault.
          vol[utils::eigen_pos_indx(__curr_pos,_bnd_box,spacing)] = val;
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    assign_cell_impl(image_t<ValueType> &vol,
                     ValueType val,
                     const point_t &cell_pos,
                     vcell_t &cell,
                     scalr_t epsilon)
    {
      matrx_t __vertices(Dim,cell.p);
      matrx_t __nmls_mat(Dim,cell.number_of_faces());
      matrx_t __refs_mat(Dim,cell.number_of_faces());
      prep_cell_stats(cell_pos,cell,__vertices,__nmls_mat,__refs_mat);

      auto __cell_domain = utils::make_cmn_domain
        (utils::comp_bound(__vertices),vol.domain().sp());
      auto __shift = utils::align_domains(vol.domain(),__cell_domain);

      cmn::Point3D __curr_coord;
      point_t __curr_pos = point_t::Zero();

      cmn_fwditr_t<Dim> __cell_it(__cell_domain);
      cmn_for_all(__cell_it)
      {
        __curr_coord = __cell_it+__shift;
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it);
        // inside_cell_test.
        if( inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
            vol.hold(__curr_coord) )
          // Note: domain is alwys bigger than the real bound.
          // (To ensure absolute inclusion of all test points)
          // in_bound is essential here: otherwise segfault.
          vol[__curr_coord] = val;
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T,Dim>::
    output_cell_impl(image_t<ValueType> &vol,
                     image_t<ValueType>* img,
                     const point_t &cell_pos,
                     vcell_t &cell,
                     scalr_t epsilon)
    {
      matrx_t __vertices(Dim,cell.p);
      matrx_t __nmls_mat(Dim,cell.number_of_faces());
      matrx_t __refs_mat(Dim,cell.number_of_faces());
      prep_cell_stats(cell_pos,cell,__vertices,__nmls_mat,__refs_mat);


      auto __cell_domain = utils::make_cmn_domain
        (utils::comp_bound(__vertices),vol.domain().sp());
      *img = image_t<ValueType>(__cell_domain);

      auto __shift = utils::align_domains(vol.domain(),__cell_domain);

      cmn::Point3D __curr_coord;
      point_t __curr_pos = point_t::Zero();

      cmn_fwditr_t<Dim> __cell_it(img->domain());
      cmn_for_all(__cell_it)
      {
        (*img)[__cell_it] = 0;
        // __curr_coord = __cell_it+__shift;
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it);
        __curr_coord = stogeo::utils::make_cmn_pt(__curr_pos, vol.domain());
        // inside_cell_test.
        if( inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
            vol.hold(__curr_coord) )
        {
          if(vol[__curr_coord] == 1)
          {
            (*img)[__cell_it] = 1;
          }

        }
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T, Dim>::
    compute_centroid(const image_t<ValueType> &mask,
                      point_t& centroid,
                      const point_t &cell_pos,
                      vcell_t &cell,
                      scalr_t epsilon)
    {
      centroid(0) = 0;
      centroid(1) = 0;
      centroid(2) = 0;

      matrx_t __vertices(Dim,cell.p);
      matrx_t __nmls_mat(Dim,cell.number_of_faces());
      matrx_t __refs_mat(Dim,cell.number_of_faces());
      prep_cell_stats(cell_pos,cell,__vertices,__nmls_mat,__refs_mat);

      auto __cell_domain = utils::make_cmn_domain
        (utils::comp_bound(__vertices),mask.domain().sp());
      auto __shift = utils::align_domains(mask.domain(),__cell_domain);

      cmn::Point3D __curr_coord;
      point_t __curr_pos = point_t::Zero();

      cmn_fwditr_t<Dim> __cell_it(__cell_domain);
      int counter(0);

      cmn_for_all(__cell_it)
      {
        __curr_coord = __cell_it+__shift;
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it);

        // inside_cell_test.
        if(inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
        (mask.hold(__curr_coord)))
        {
          if((mask[__curr_coord] == 1)){
            point_t __pt_tmp;
            __pt_tmp <<
              __curr_pos[0],
              __curr_pos[1],
              __curr_pos[2];
            centroid += __pt_tmp;
            ++counter;
          }
        }
      }
      centroid *= (1.0/ ((double) counter));
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename ValueType>
    void VoronoiDiagram<T, Dim>::
    compute_cell_distortion(const image_t<ValueType> &mask,
                            double &cell_distortion,
                            const point_t &cell_pos,
                            vcell_t &cell,
                            scalr_t epsilon)
    {
      matrx_t __vertices(Dim,cell.p);
      matrx_t __nmls_mat(Dim,cell.number_of_faces());
      matrx_t __refs_mat(Dim,cell.number_of_faces());
      prep_cell_stats(cell_pos,cell,__vertices,__nmls_mat,__refs_mat);

      auto __cell_domain = utils::make_cmn_domain
        (utils::comp_bound(__vertices),mask.domain().sp());
      auto __shift = utils::align_domains(mask.domain(),__cell_domain);

      cmn::Point3D __curr_coord;
      point_t __curr_pos = point_t::Zero();

      //CENTROID
      cmn_fwditr_t<Dim> __cell_it_1(__cell_domain);
      point_t centroid;
      centroid << 0, 0, 0;
      int counter(0);

      cmn_for_all(__cell_it_1)
      {
        __curr_coord = __cell_it_1 + __shift;
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it_1);
        // inside_cell_test.
        if( inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
        (mask.hold(__curr_coord)))
        {
          if((mask[__curr_coord] == 1)){
            point_t __pt_tmp;
            __pt_tmp << __curr_coord[0], __curr_coord[1], __curr_coord[2];
            centroid += __pt_tmp;
            ++counter;
          }
        }
      }
      centroid *= (1.0/ ((double) counter));

      // SUM OF SQUARES
      cell_distortion = 0;

      cmn_fwditr_t<Dim> __cell_it_2(__cell_domain);
      cmn_for_all(__cell_it_2)
      {
        __curr_coord = __cell_it_2+__shift;
        __curr_pos = utils::cmn_itr_pos<double>(__cell_it_2);
        // inside_cell_test.
        if( inside_polyhedra(__curr_pos,__nmls_mat,__refs_mat,epsilon) &&
        (mask.hold(__curr_coord)))
        {
          if((mask[__curr_coord] == 1)){
            point_t __pt_tmp;
            __pt_tmp << __curr_coord[0], __curr_coord[1], __curr_coord[2];
            cell_distortion += (__pt_tmp - centroid).squaredNorm();
          }
        }
      }

    }

    // =====================================================================
    template<typename T, int Dim>
    bool VoronoiDiagram<T,Dim>::
    inside_polyhedra(const point_t &pt,
                     const matrx_t &face_nmls,
                     const matrx_t &face_refs,
                     scalr_t epsilon) const
    {
      for(int __i = 0;__i < face_nmls.cols(); ++__i)
        if( face_nmls.col(__i).dot(pt-face_refs.col(__i)) <= -epsilon )
          // Note this -0.1 value is experimental: for high resolution
          // (<= 0.1) simulations it's perfect. Lower resol still have
          // artifact left around the cell face boundaries.
        {
          return false;
        }
      return true;
    }

  } //!tess
} //!stogeo
