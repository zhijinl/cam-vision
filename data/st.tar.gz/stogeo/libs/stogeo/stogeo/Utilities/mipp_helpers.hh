// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// mipp_helpers.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 11 15:27:55 2016 Zhijin Li
// Last update Thu Dec 14 18:47:09 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_MIPP_HELPERS_HH
# define STOGEO_MIPP_HELPERS_HH

# include "common/Image.hh"
# include "common/Signal.hh"
# include "common/Volume.hh"
# include "mipp/core/SAVolume.hh"
# include "common/FwdIterator.hh"
# include "mipp/core/Histogram.hh"
# include "mipp/core/Properties.hh"
# include "mipp/core/Neighborhood.hh"
# include "stogeo/Utilities/utils.hh"


namespace stogeo
{

  /// @brief Definition of the type of volume to use.
  ///
  /// By default, `StoGeo` uses the **single-array** volume
  /// implementation from `mipp` with continuous memory layout,
  /// unless a specific compilation is given.
  ///
#ifdef STG_USE_NON_CONTIGUOUS_CMN_VOLUME_IMPL
  template<typename T>
  using stg_volume_t = typename cmn::Volume<T>;
#else
  template<typename T>
  using stg_volume_t = typename mipp::SAVolume<T>;
#endif

  // Fwd decl.
  namespace shapes { template<typename,int> class Box; }

  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Get the dimension of an input `common` structure.
  ///
  /// @param Input: an input `common` structure.
  /// @return The dimension of the input `common` structure.
  ///
  template<typename Input> struct cmn_struct_dim
  { static constexpr int value = 0; };

  template<typename ValueType>
  struct cmn_struct_dim<cmn::Signal<ValueType> >
  { static constexpr int value = 1; };

  template<typename ValueType>
  struct cmn_struct_dim<cmn::Image<ValueType> >
  { static constexpr int value = 2; };

  template<typename ValueType>
  struct cmn_struct_dim<cmn::Volume<ValueType> >
  { static constexpr int value = 3; };

  template<typename ValueType>
  struct cmn_struct_dim<mipp::SAVolume<ValueType> >
  { static constexpr int value = 3; };

  template<typename Input>
  constexpr int cmn_struct_dim_v()
  { return cmn_struct_dim<decay_t<Input> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve common image type.
  ///
  /// @param T: the value type.
  /// @param Dim: the dimension.
  /// @return The image type with proper value type and dimension.
  ///
  template<typename T, int Dim> struct cmn_img
  { static_assert(Dim <= 3 && Dim > 0,
                  "ERROR: IMAGE WITH DIM > 3 OR <= 0 UNDEFINED."); };
  template<typename T> struct cmn_img<T,1>
  { using type = typename cmn::Signal<T>; };
  template<typename T> struct cmn_img<T,2>
  { using type = typename cmn::Image<T>; };
  template<typename T> struct cmn_img<T,3>
  { using type = stg_volume_t<T>; };
  template<typename T, int Dim>
  using cmn_img_t = typename cmn_img<decay_t<T>,Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve common point type.
  ///
  /// @param Dim: the dimension.
  /// @return The common point type with proper dimension.
  ///
  template<int Dim> struct cmn_pt
  { static_assert(Dim <= 3 && Dim > 0,
                  "ERROR: POINT WITH DIM > 3 OR <= 0 UNDEFINED."); };
  template<> struct cmn_pt<1> { using type = cmn::Point1D; };
  template<> struct cmn_pt<2> { using type = cmn::Point2D; };
  template<> struct cmn_pt<3> { using type = cmn::Point3D; };
  template<int Dim> using cmn_pt_t = typename cmn_pt<Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve common dpoint type.
  ///
  /// @param Dim: the dimension.
  /// @return The common dpoint type with proper dimension.
  ///
  template<int Dim> struct cmn_dpt
  { static_assert(Dim <= 3 && Dim > 0,
                  "ERROR: DPOINT WITH DIM > 3 OR <= 0 UNDEFINED."); };
  template<> struct cmn_dpt<1> { using type = cmn::DPoint1D; };
  template<> struct cmn_dpt<2> { using type = cmn::DPoint2D; };
  template<> struct cmn_dpt<3> { using type = cmn::DPoint3D; };
  template<int Dim> using cmn_dpt_t = typename cmn_dpt<Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve common domain type.
  ///
  /// @param Dim: the dimension.
  /// @return The domain type with proper dimension.
  ///
  template<unsigned Dim> struct cmn_domain
  { static_assert(Dim <= 3 && Dim > 0,
                  "ERROR: DOMAIN WITH DIM > 3 OR <= 0 UNDEFINED."); };
  template<> struct cmn_domain<1> { using type = cmn::Domain1D; };
  template<> struct cmn_domain<2> { using type = cmn::Domain2D; };
  template<> struct cmn_domain<3> { using type = cmn::Domain3D; };
  template<unsigned Dim> using cmn_domain_t = typename cmn_domain<Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Get the dimension of a common `Domain`.
  ///
  /// @param D: the input domain type.
  /// @return Dimension of the input domain.
  ///
  template<typename D> struct cmn_domdim { static const unsigned value = 0; };
  template<> struct cmn_domdim<cmn::Domain1D>
  { static const unsigned value = 1; };
  template<> struct cmn_domdim<cmn::Domain2D>
  { static const unsigned value = 2; };
  template<> struct cmn_domdim<cmn::Domain3D>
  { static const unsigned value = 3; };

  template<typename D>
  constexpr int cmn_domdim_v() { return cmn_domdim<decay_t<D> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve common `FwdIterator` type.
  ///
  /// @param Dim: the input dimension.
  /// @return The corresponded `FwdIterator`.
  ///
  template<int Dim> struct cmn_fwditr
  { static_assert(Dim <= 3 && Dim > 0,
                  "ERROR: FWDITERATOR WITH DIM > 3 OR <= 0 UNDEFINED."); };
  template<> struct cmn_fwditr<1> { using type = cmn::FwdIterator1D; };
  template<> struct cmn_fwditr<2> { using type = cmn::FwdIterator2D; };
  template<> struct cmn_fwditr<3> { using type = cmn::FwdIterator3D; };
  template<int Dim> using cmn_fwditr_t = typename cmn_fwditr<Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve cmn::value_type.
  ///
  /// @param E: an inpute common structure.
  /// @return The value_type corresponding to the input structure.
  ///
  template<typename E>
  using cmn_value_t =
    typename cmn::traits::img_specs<decay_t<E> >::value_type;
  ///@}


  ///@{
  /// @brief Check is an input type is a domain from `common`.
  ///
  template<typename Input>
  struct is_cmn_domain_t
  {
    static constexpr int value = is_base_of_v
      <cmn::abstract::Domain<cmn_domdim_v<Input>()>, decay_t<Input> >();
  };

  template<typename Input>
  constexpr bool is_cmn_domain_v()
  { return is_cmn_domain_t<Input>::value; }
  ///@}

  /// @ingroup group_utils
  namespace utils
  {

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from input origin, spacing, border and
    /// sizes.
    ///
    /// @param origin: the origin in physical length units: an Eigen
    /// floating-point **column vector** expression. Number of
    /// rows of the vector must equal to the domain's dimension,
    /// otherwise a compile-time error will be triggered.
    ///
    /// @param spacing: the desired spacing between adjacent elements.
    /// An Eigen floating-point **column vector** expression. Number of
    /// rows of the vector must equal to the domain's dimension,
    /// otherwise a compile-time error will be triggered.
    ///
    /// @border: int value for domain border extension.
    ///
    /// @param sizes: variadic integrer specifying sizes. Number of
    /// the size arguments must equal to the domain's dimension,
    /// otherwise a compile-time error will be triggered.
    ///
    /// @return A cmn::Domain of the appropriate dimension.
    ///
    template<typename EigVec1, typename EigVec2, typename ...Sizes,
             enable_if_all_t<is_eigen_v<EigVec1>(),
                             is_eigen_v<EigVec2>(),
                             eigen_rows_v<EigVec1>()==
                             sizeof...(Sizes)>* = nullptr,
             typename Indx = make_seq_t<eigen_rows_v<EigVec1>()> >
    inline auto make_cmn_domain(EigVec1 &&origin,
                                EigVec2 &&spacing,
                                int border,
                                Sizes ...sizes)
      -> cmn_domain_t<eigen_rows_v<EigVec1>()>;


    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from input origin, spacing, sizes and
    /// border.
    ///
    /// @note If the input sizes are integrals, the domain's discrete sizes
    /// are exactly the same values as input sizes. If the sizes are floats,
    /// the domain size is ceil(float_size/resol)+1. Example: [-1,1] &
    /// [-1,0.9] with resol = 0.5 yield both 5 discrete interval: [-1 -0.5
    /// 0 0.5 1.0]. And [-1,1.1] will yield 6 discrte interval: [-1 -0.5 0
    /// 0.5 1.0 1.5]. This is to make sure that the domain covers all
    /// positions.
    ///
    /// @param origin: the origin in physical length units: an Eigen
    /// floating-point **column vector** expression. Number of
    /// rows of the vector must equal to the domain's dimension,
    /// otherwise a compile-time error will be triggered.
    ///
    /// @param spacing: the desired spacing between adjacent elements.
    /// An Eigen floating-point **column vector** expression. Number of
    /// rows of the vector must equal to the domain's dimension,
    /// otherwise a compile-time error will be triggered.
    ///
    /// @param sizes: an Eigen **column vector** expression specifying the
    /// domain sizes in **either physical length units or discrete units**.
    /// - When an integer type Eigen vector is given: the domain's discrete
    ///   sizes will be set for the values in it.
    /// - When a floating-point Eigen vector is given: the domain's sizes in
    ///   physical length units will be set for values in it.
    ///
    /// @border: int value for domain border extension. Defaults to 0.
    ///
    /// @return A cmn::Domain of the appropriate dimension.
    ///
    template<typename EigVec1, typename EigVec2, typename EigVec3,
             enable_if_all_t<is_eigen_v<EigVec1>(),
                             is_eigen_v<EigVec2>(),
                             is_eigen_v<EigVec3>()>* = nullptr,
             typename Indx = make_seq_t<eigen_rows_v<EigVec1>()> >
    inline auto make_cmn_domain(EigVec1 &&origin,
                                EigVec2 &&spacing,
                                EigVec3 &&sizes,
                                int border=0)
      -> cmn_domain_t<eigen_rows_v<EigVec1>()>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from an input floating-point bounding
    /// box, spacing and border.
    ///
    /// The origin (in physical length units) of the domain is set to
    /// be 1st column of the bound.
    ///
    /// @param bound: a bounding box: an Eigen Dim x 2 floating-point
    /// matix expression.
    /// @param spacing: the desired spacing: an Eigen Dim x 1 float-point
    /// vector expression.
    /// @border: int value for domain border extension. Defaults to 0.
    /// @return The computed Domain.
    ///
    template<typename BoundType, typename EigVec,
             enable_if_all_t<is_eigen_v<BoundType>(),
                             is_eigen_v<EigVec>(),
                             is_floating_point_v<eigen_val_t<BoundType> >()>*
             = nullptr>
    auto make_cmn_domain(BoundType &&bound,
                         EigVec &&spacing,
                         int border=0)
      -> cmn_domain_t<eigen_rows_v<BoundType>()>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from an input integer bounding
    /// box.
    ///
    /// The discrete origin of the domain is set to be 1st column of the
    /// bound.
    ///
    /// @warning For integral type bounding box, the internal computation
    /// explicitly add 1 after dividing the spacing. For example: a bound
    /// [0, ..., 8] with spacing = 1, has actually length of
    /// 9 = (8-0)/spacing + 1.
    ///
    /// @param bound: a bounding box: an Eigen Dim x 2 integer matix
    /// expression.
    /// @param spacing: the desired spacing: an Eigen Dim x 1 float-point
    /// vector expression.
    /// @border: int value for domain border extension. Defaults to 0.
    /// @return The computed Domain.
    ///
    template<typename BoundType, typename EigVec,
             enable_if_all_t<is_eigen_v<BoundType>(),
                             is_eigen_v<EigVec>(),
                             is_integral_v<eigen_val_t<BoundType> >()>*
             = nullptr>
    auto make_cmn_domain(BoundType &&bound,
                         EigVec &&spacing,
                         int border=0)
      -> cmn_domain_t<eigen_rows_v<BoundType>()>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from an input floating-point bounding
    /// box, spacing and border. In this version the spacing is specified
    /// using the cmn::Spacing type.
    ///
    /// The origin (in physical length units) of the domain is set to
    /// be 1st column of the bound.
    ///
    /// @param bound: a bounding box: an Eigen Dim x 2 floating-point
    /// matix expression.
    /// @param spacing: the desired spacing: an `cmn::Spacing<Dim>` object.
    /// @border: int value for domain border extension. Defaults to 0.
    /// @return The computed Domain.
    ///
    template<typename BoundType, unsigned Dim,
             enable_if_t<is_eigen_v<BoundType>()>* = nullptr>
    auto make_cmn_domain(BoundType &&bound,
                         const cmn::Spacing<Dim> &spacing,
                         int border=0)
      -> cmn_domain_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Domain from a Box of dimension Dim.
    ///
    /// @param box: the input stogeo::shapes::Box.
    /// @param spacing: the input spacing Eigen vector of Dim x 1.
    /// @param border: integral value border size.
    /// @return A cmn::Domain.
    ///
    template<typename T, typename PT, int Dim,
             typename = enable_if_all_t<eigen_size_is_v<PT,Dim,1>()> >
    auto make_cmn_domain(const shapes::Box<T,Dim> &box, PT &&spacing,
                         int border=0)
      -> cmn_domain_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Create an aligned domain from a shape's bounding box.
    ///
    /// @param shape: the input shape, a stogeo::Shape.
    /// @param domain: the reference domain, where the output domain
    /// need to be aligned with.
    /// @return `std::pair` of origin shift from reference domain to
    /// the created one & the created aligned domain.
    ///
    template<typename Shape, unsigned Dim>
    auto make_aligned_domain(Shape &&shape,
                             const cmn::abstract::Domain<Dim> &domain)
      -> std::pair<cmn_dpt_t<Dim>,cmn_domain_t<Dim> >;

    /// @ingroup group_utils
    ///
    /// @brief Create a domain whose origin is aligned with another one.
    ///
    /// @param domain: the reference domain, where the output domain origin
    /// need to be aligned with.
    /// @param args: variadic arguments for `make_cmn_domain` function.
    /// @return `std::pair` containing origin shift from reference domain to
    /// the created one & the created aligned domain.
    ///
    /// @sa `stogeo::utils::make_cmn_domain`.
    ///
    template<unsigned Dim, typename ...Args>
    auto make_aligned_domain(const cmn::abstract::Domain<Dim> &domain,
                             Args ...args)
      -> std::pair<cmn_dpt_t<Dim>,cmn_domain_t<Dim> >;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Spacing from an Eigen vec.
    ///
    /// @param pt: an Eigen point. Dim x 1 vec. Colmajored.
    /// @return A cmn::Spacing of proper dimension.
    ///
    template<typename PT,
             typename = enable_if_t<is_eigen_v<PT>()> >
    auto make_spacing(PT &&pt) -> cmn::Spacing<eigen_rows_v<PT>()>;

    /// @ingroup group_utils
    ///
    /// @breif Compute discrete center of the domain.
    ///
    /// This function just returns a point with nth corrdinate equal
    /// to `domain_size(n)/2`.
    ///
    /// @note For even size, this will return the point of 1-past the
    /// analytical center. For odd size, this returns the exact center
    /// coordinates.
    ///
    /// @param domain: the input domain.
    /// @return The computed center point. A cmn::Point of correct dim.
    ///
    template<unsigned Dim>
    auto domain_center(const cmn::abstract::Domain<Dim> &domain)
      -> cmn_pt_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @breif Compute center of the domain in **length units**.
    ///
    /// The center is computed as:
    ///
    ///         `center = dom.originLU() + dom_size*spacing/2.0`.
    ///
    /// So all in floating point.
    ///
    /// @param domain: the input domain.
    /// @return The computed center point in length units. An Eigen
    /// point
    ///
    template<typename Scalar, unsigned Dim>
    auto domain_center_lu(const cmn::abstract::Domain<Dim> &domain)
      -> Eigen::Matrix<Scalar,Dim,1>;

    ///@{
    /// @ingroup group_utils
    ///
    /// @breif Generic computation of inner product from two Eigen vec
    /// expression or two `cmn::Vector` derived types.
    ///
    /// @note For Eigen types: input vectors are **NOT assumed to be
    /// column-ordered**: in both cases it will work, as long as they
    /// are both **vectors of the same size**..
    ///
    /// @param lhs: left hand side vector.
    /// @param rhs: right hand side vector.
    /// @return The computed inner product.
    ///
    template<typename Scalar, typename Left, typename Right,
             enable_if_all_t<is_eigen_v<Left>(),
                             is_eigen_v<Right>()>* = nullptr>
    Scalar comp_inner_prod(Left &&lhs, Right &&rhs);

    template<typename Scalar, typename Left, typename Right,
             enable_if_all_t<!is_eigen_v<Left>(),
                             !is_eigen_v<Right>()>* = nullptr>
    Scalar comp_inner_prod(Left &&lhs, Right &&rhs);
    ///@}

    /// @ingroup group_utils
    ///
    /// @brief Create an Eigen point from cmn::Spacing.
    ///
    /// @param spacing: an input cmn::Spacing.
    /// @return An Eigen Dim x 1 vec.
    ///
    template<typename T, unsigned Dim>
    auto spacing_to_pt(const cmn::Spacing<Dim> &spacing)
      -> Eigen::Matrix<T,Dim,1>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::FwdIterator & bind it to a bounding box.
    ///
    /// @param bound: the input bounding box: an Eigen Dim x 2 mat.
    /// @param spacing: the desired spacing.
    /// @return The created FwdIterator that binds to bound.
    ///
    template<typename BT, typename ET,
             enable_if_t<is_eigen_v<BT>()>* = nullptr>
    auto make_cmn_fwditr(BT &&bound, ET &&spacing)
      -> cmn_fwditr_t<eigen_rows_v<BT>()>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Point with Dim number of coordinates.
    ///
    /// @param args: Dim number of integral args representing point
    /// coordinates.
    /// @return A cmn::Point w/ dim = number of args.
    ///
    template<typename ...TPS,
             enable_if_all_t<is_arithmetic_v<TPS>()...>* = nullptr>
    auto make_cmn_pt(TPS ...args) -> cmn_pt_t<sizeof...(TPS)>;

    /// @ingroup group_utils
    ///
    /// @brief Create `cmn::Point` from an Eigen integral column vec.
    ///
    /// @param pt: the input Eigen integral column vec.
    /// @return A `cmn::PointND`.
    ///
    template<typename PT>
    cmn_pt_t<eigen_rows_v<PT>()> make_cmn_pt(PT &&pt);

    /// @ingroup group_utils
    ///
    /// @brief Get relative pos vector of an Eigen::pt vs cmn::Domain.
    /// originLU.
    ///
    /// Relative pos = (pt - dom.originLU)/spacing. Division res is
    /// std::rounded to nearest integer.
    ///
    /// @param pt: the input Eigen point, Dim x 1.
    /// @param dom: the input cmn::Domain of the same dimension.
    /// @return `cmn::PointND`: the computed relative shift (cmn::Point).
    ///
    template<unsigned Dim, typename PT>
    auto make_cmn_pt(PT &&pt, const cmn::abstract::Domain<Dim> &dom)
      -> cmn_pt_t<Dim>;

    /// @brief Compute the correpsonding integral point from an array
    /// index given a domain.
    ///
    /// This function assumes that the ordering of the array's element
    /// in the domain follows:
    ///      `x -> y -> z`
    ///
    template<unsigned Dim, typename Integral>
    auto cmn_ind_pos(Integral indx, const cmn::abstract::Domain<Dim> &dom)
      -> cmn_pt_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Compute the integer arr index of a cmn::Iterator at its
    /// current state.
    ///
    /// @note The computation is done by wrapping the iterator's domain
    /// sizes in lexicographic order. For example, in 3D case, the array
    /// index ind = pt[x] + pt[y]*size_x + pt[z]*size_x*size_y.
    ///
    /// @param it: the input cmn forward iterator.
    /// @return The computed array index, an int.
    ///
    template<typename ET>
    int cmn_itr_ind(const cmn::abstract::FwdIterator<ET> &it);

    /// @ingroup group_utils
    ///
    /// @brief Compute spatial pos of a cmn::Iterator.
    ///
    /// Result pos = originLU + (x_ind,y_ind,z_ind)*spacing.
    ///
    /// @note need explicit template arg, non-deduced context.
    ///
    /// @param it: input iterator.
    /// @return An Eigen pt aka fixed size Dim x 1 vector.
    ///
    template<typename T, typename ET>
    auto cmn_itr_pos(const cmn::abstract::FwdIterator<ET> &it)
      -> Eigen::Matrix<T,cmn_it_dim(ET),1>;

    /// @ingroup group_utils
    ///
    /// @brief Transform integral coordinate point to spatial pos
    /// with specific origin and spacing of the input domain.
    ///
    /// Result pos = dom.originLU + coords*spacing.
    ///
    /// @note Need explicit template arg for data type.
    ///
    /// @warning The input coordinates are **relative to domain
    /// origin***, for example for center of the domain you will
    /// write dom_size/2.
    ///
    /// @param domain: the input domain.
    /// @param coords: Dim number of integral coordinates.
    /// @return An Eigen pt aka fixed size Dim x 1 vector.
    ///
    template<typename T, unsigned Dim, typename ...ITS>
    auto cmn_coord_pos(const cmn::abstract::Domain<Dim> &domain,
                       ITS ...coords)
      -> Eigen::Matrix<T,Dim,1>;

    /// @ingroup group_utils
    ///
    /// @brief Transform integral coordinate point to spatial pos
    /// with specific origin and spacing of the input domain.
    ///
    /// Result pos = dom.originLU + coords*spacing.
    ///
    /// @note Need explicit template arg for data type.
    ///
    /// @warning The input coordinates are **relative to domain
    /// origin***, for example for center of the domain you will
    /// write dom_size/2.
    ///
    /// @param domain: the input domain.
    /// @param coords: a cmn::Point indicating coordinates.
    /// @return An Eigen pt aka fixed size Dim x 1 vector.
    ///
    template<typename T, typename PT, unsigned Dim>
    auto cmn_coord_pos(const cmn::abstract::Domain<Dim> &domain,
                       const cmn::abstract::Point<PT> &coords)
      -> Eigen::Matrix<T,Dim,1>;

    /// @ingroup group_utils
    ///
    /// @brief Compute shift in **length unit** of a query point
    /// from the origin of a domain.
    ///
    /// @param domain: the input domain.
    /// @param pt: cn input cmn::Point specifying the integral
    /// coordinates of the point.
    /// @return An Eigen pt aka fixed size Dim x 1 vector, holding
    /// the computed shift in **length unit**.
    ///
    template<typename T, unsigned Dim, typename PT>
    auto lu_shift_from_origin(const cmn::abstract::Domain<Dim> &domain,
                              const cmn::abstract::Point<PT> &pt)
      -> Eigen::Matrix<T,Dim,1>;

    /// @ingroup group_utils
    ///
    /// @brief Compute spatial position of integral coordianates,
    /// **with respect to the domain center**, in **length units**.
    ///
    /// Result `pos = (coords-dom.center)*spacing`.
    /// The `dom.center` is the dicrete center of the domain, it
    /// is computed as dom.size/2, **rounded down**.
    ///
    /// @note Need explicit template arg for data type.
    ///
    /// @param domain: the input domain.
    /// @param coords: Dim number of integral coordinates.
    /// @return An Eigen pt aka fixed size Dim x 1 vector.
    ///
    template<typename Scalar, unsigned Dim, typename ...ITS>
    auto cmn_pos_to_center(const cmn::abstract::Domain<Dim> &domain,
                           ITS ...coords)
      -> Eigen::Matrix<Scalar,Dim,1>;

    /// @ingroup group_utils
    ///
    /// @brief Compute spatial position of integral coordianates,
    /// **with respect to the domain center**, in **length units**.
    ///
    /// Result `pos = (coords-dom.center)*spacing`.
    /// The `dom.center` is the dicrete center of the domain, it
    /// is computed as dom.size/2, **rounded down**.
    ///
    /// @note Need explicit template arg for data type.
    ///
    /// @param domain: the input domain.
    /// @param coords: a cmn::Point indicating coordinates.
    /// @return An Eigen pt aka fixed size Dim x 1 vector.
    ///
    template<typename T, typename PT, unsigned Dim>
    auto cmn_pos_to_center(const cmn::abstract::Domain<Dim> &domain,
                           const cmn::abstract::Point<PT> &coords)
      -> Eigen::Matrix<T,Dim,1>;

    ///@{
    /// @brief Convert a cmn::Point or an Eigen integral point to
    /// cmn::DPoint.
    ///
    template<typename PointType, enable_if_all_t
             <is_eigen_v<PointType>(),
              is_integral_v<eigen_val_t<PointType> >()>* = nullptr>
    auto to_dpoint(PointType &&pt)
      -> cmn_dpt_t<eigen_rows_v<PointType>()>;

    template<typename PointType,
             enable_if_t<!is_eigen_v<PointType>()>* = nullptr>
    auto to_dpoint(PointType &&pt)
      -> cmn_dpt_t<cmn_dim(decay_t<PointType>)>;
    ///@}

    /// Compute d discrete indices for an Eigen point assumed in
    /// **length units**.
    ///
    /// It takes into account the domain's physical origin (in
    /// length units) and the domain's physical spacing (in length
    /// units). The result is the relative index to the domain
    /// origin.
    ///
    /// @param pos: input position in length units.
    /// @param domain: the cmn::Domain where the physical position
    /// is defined.
    /// @return: Discrete Eigen point.
    ///
    template<typename PointType , typename DomainType,
             typename = enable_if_t<is_eigen_v<PointType>()> >
    auto to_discrete_pos_eigen(PointType &&pos, const DomainType &domain)
      -> Eigen::Matrix<int,cmn_domdim_v<DomainType>(),1>;

    ///@{
    /// @brief Compute discrete position of an input position in
    /// cmn or Eigen form.
    ///
    /// When input's coordiantes are integral types, it simply return
    /// the same point in cmn::Point format. When input's coordiantes
    /// are floating-point types, it uses information in domain to
    /// compute a proper indexing of the input position in reference
    /// to the domain's origin.
    ///
    /// @param pos: the input position. Integral or floating-point
    /// type will get dispatched properly.
    /// @param domain: the domain of reference.
    /// @return A cmn::Point of proper dimension, representing the
    /// discrete index position of the input point, in reference of
    /// the input domain.
    ///
    template<typename PointType , typename DomainType,
             enable_if_t<!is_eigen_v<PointType>()>* = nullptr>
    auto to_discrete_pos(PointType &&pos, const DomainType &domain)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>;

    template<typename PointType , typename DomainType,
             enable_if_all_t
             <is_eigen_v<PointType>(),
              is_floating_point_v<eigen_val_t<PointType> >()>* = nullptr>
    auto to_discrete_pos(PointType &&pos, const DomainType &domain)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>;

    template<typename PointType , typename DomainType,
             enable_if_all_t
             <is_eigen_v<PointType>(),
              is_integral_v<eigen_val_t<PointType> >()>* = nullptr>
    auto to_discrete_pos(PointType &&pos, const DomainType &domain)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>;
    ///@}

    /// @brief Compute **Length-Unit** shift vector from a src position
    /// to a destination position.
    ///
    /// res = (dst - src)*spacing.
    ///
    /// @note The source position can be in discrete form coordinates
    /// or length unit. The destination coordinates are specified using
    /// integral coordinates. The final result is always in **length
    /// units**.
    ///
    /// @param src: the source position. Can be an Eigen floating point
    /// or integral vector, or a cmn point (integral). According to
    /// input data type (floating point or integral), different impl
    /// func will get properly dispatched.
    /// @param domain: the input domain.
    /// @param dst_coords: destination coordinates, variadic integral
    /// coordinates.
    ///
    template<typename Scalar, typename Position, typename DomainType,
             typename ...Coords,
             enable_if_all_t<is_integral_v<Coords>()...>* = nullptr>
    auto comp_pos_shift(Position &&src, const DomainType &domain,
                        Coords ...dst_coords)
      -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

    /// @brief Compute **Length-Unit** shift vector from a src position
    /// to a destination position.
    ///
    /// res = (dst - src)*spacing.
    ///
    /// @note The source position can be in discrete form coordinates
    /// or length unit. The destination coordinates are specified using
    /// integral coordinates. The final result is always in **length
    /// units**.
    ///
    /// @param src: the source position. Can be an Eigen floating point
    /// or integral vector, or a cmn point (integral). According to
    /// input data type (floating point or integral), different impl
    /// func will get properly dispatched.
    /// @param domain: the input domain.
    /// @param dst: destination point, a cmn::Point.
    ///
    template<typename Scalar, typename Position, typename DomainType,
             typename PointType,
             enable_if_t<!is_integral_v<PointType>()>* = nullptr>
    auto comp_pos_shift(Position &&src, const DomainType &domain,
                        PointType &&dst)
      -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::DPoint with dim = number of args.
    ///
    /// @param args: variadic integral args.
    /// @return A cmn::DPoint w/ dim = number of args.
    ///
    template<typename ...TPS,
             enable_if_all_t<is_arithmetic_v<TPS>()...>* = nullptr>
    auto make_cmn_dpt(TPS ...args) -> cmn_dpt_t<sizeof...(TPS)>;

    /// @ingroup group_utils
    ///
    /// @brief Comp cmn::DPoint from 2 Eigen pts of **integral type**.
    ///
    /// result = dst - src.
    ///
    /// @warning The input Eigen vector must be column ordered.
    ///
    /// @param src: the src position vec: an Eigen pt (integral, Dim x 1).
    /// @param dst: the dst position vec. Same type as above.
    /// @return The computed DPoint.
    ///
    template<typename PT1, typename PT2,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>()>* = nullptr>
    auto comp_dpoint(PT1 &&src, PT2 &&dst)
      -> cmn_dpt_t<eigen_rows_v<PT1>()>;

    /// @ingroup group_utils
    ///
    /// @brief Comp cmn::DPoint from 2 Eigen pts, with given spacing.
    ///
    /// result = dst - src.
    ///
    /// @warning The input Eigen vector must be column ordered.
    ///
    /// @param src: the src position vec: an Eigen pt (Dim x 1).
    /// @param dst: the dst position vec. same type as above.
    /// @param spacing: the desired spacing: same as above.
    /// @return The computed DPoint.
    ///
    template<typename PT1, typename PT2, typename PT3,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>(),
                             is_eigen_v<PT3>()>* = nullptr>
    auto comp_dpoint(PT1 &&src, PT2 &&dst, PT3 &&spacing)
      -> cmn_dpt_t<eigen_rows_v<PT1>()>;

    /// @ingroup group_utils
    ///
    /// @brief Comp cmn::DPoint from 2 Eigen pts, with given spacing.
    ///
    /// result = dst - src.
    ///
    /// @warning The input Eigen vector must be column ordered.
    ///
    /// @param src: the src position vec: an Eigen pt (Dim x 1).
    /// @param dst: the dst position vec. same type as above.
    /// @param spacing: the desired spacing: cmn::Spacing type.
    /// @return The computed DPoint.
    ///
    template<typename PT1, typename PT2, typename PT3, unsigned Dim,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>()>* = nullptr>
    auto comp_dpoint(PT1 &&src, PT2 &&dst, const cmn::Spacing<Dim> &spacing)
      -> cmn_dpt_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Align the origin of two cmn::domain.
    ///
    /// @note When using two cmn::Domains for pt parsing, their
    /// origins need to be aligned: otherwise locs parsed by the
    /// dst domain may step on the inter-gap btw src locactions.
    /// This function aligns the dst origin with the src one wrt
    /// the specific spacing which must be the same for src and
    /// dst. The dst domain will be bigger in case of non-align
    /// ment pre-condition.
    ///
    /// @param src: the src domain.
    /// @param dst: the dst domain whose origin is going to be
    /// aligned with src's.
    /// @return A dpoint = dst.origin - src.origin.
    ///
    template<unsigned Dim>
    auto align_domains(const cmn::abstract::Domain<Dim> &src,
                       cmn::abstract::Domain<Dim> &dst) -> cmn_dpt_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Comp DPointND from 2 cmn::Domain.
    ///
    /// result = dst.origin() - src.origin(): rounded to nearest int.
    ///
    /// @param src: the src domain: a cmn::Domain of Dim.
    /// @param dst: the dst domain. Same type as above.
    /// @return The computed DPoint.
    ///
    template<unsigned Dim>
    auto domain_origin_shift(const cmn::abstract::Domain<Dim> &src,
                             const cmn::abstract::Domain<Dim> &dst)
      -> cmn_dpt_t<Dim>;

    /// @ingroup group_utils
    ///
    /// @brief Check if two Image domain intersect
    ///
    /// Works for arbitrary dim. Test condition is:
    /// (lhs.bb(i,0) < rhs.bb(i,1)) && (lhs.bb(i,1) > rhs.bb(i,0))
    ///
    /// @param lhs: cmn::Domain A.
    /// @param rhs: cmn::Domain B.
    /// @return True if A and B intersect.
    ///
    template<typename DT>
    bool domain_intersect(DT &&lhs, DT &&rhs);

    /// @ingroup group_utils
    ///
    /// @brief Create stogeo bounding box using cmn::Domain.
    ///
    /// @warning Need explicitly specify the scalar type used for
    /// returned bounding box.
    ///
    /// @param domain: a cmn::Domain of ND.
    /// @return A stogeo bounding box: Eigen Dim x 2 matrix.
    ///
    template<typename T, int Dim>
    auto make_bound(const cmn::abstract::Domain<Dim> &domain)
      -> Eigen::Matrix<T,Dim,2>;

    /// @ingroup group_utils
    ///
    /// @brief Create cmn::Signal from Eigen vec.
    ///
    /// @param vec: the input vector. Eigen Dym x 1 mat.
    /// @return A `cmn::Signal`.
    ///
    template<typename VT,
             enable_if_t<is_eigen_v<VT>()>* = nullptr>
    auto vec2signal(VT &&vec) -> cmn::Signal<eigen_val_t<VT> >;

    /// @ingroup group_utils
    ///
    /// @brief Create Eigen vec from cmn::Signal.
    ///
    /// @param sig: the input cmn::Signal.
    /// @return An Eigen vector. Dym x 1 mat.
    ///
    template<typename T>
    Eigen::Matrix<T,Eigen::Dynamic,1> signal2vec(const cmn::Signal<T> &sig);

    /// @ingroup group_utils
    ///
    /// @brief Create Eigen Matrix from mipp::Histogram.
    ///
    /// @note counts may not be ints: casted to T, (float type possible)
    /// to be uniform with the indexing type. Indexings are integral spatial
    /// positions.
    ///
    /// @param hist: input mipp:Histogram.
    /// @return An Eigen::(Dym x 2) matrix. col(0) is histo counts, col(1)
    /// is the indexing.
    ///
    template<typename T>
    Eigen::Matrix<T,Eigen::Dynamic,2> hist2mat(const mipp::Histogram<T> &hist);

    namespace detail
    {
      // Overload #1: variadic int sizes.
      template<typename ET1, typename ET2, int... Indx, typename ...ITS>
      auto make_cmn_domain_impl(indx_seq<Indx...>,
                                ET1 &&, ET2 &&, int , ITS ...)
        -> cmn_domain_t<sizeof...(Indx)>;

      // Overload #2: float-type Eigen vec for sizes.
      template<typename ET1, typename ET2, typename ET3,
               enable_if_t<is_floating_point_v
                           <eigen_val_t<ET3> >()>* = nullptr,
               int... Indx>
      auto make_cmn_domain_impl(indx_seq<Indx...>,
                                ET1 &&, ET2 &&, ET3 &&, int )
        -> cmn_domain_t<sizeof...(Indx)>;

      // Overload #3: int-type Eigen vec for sizes.
      template<typename ET1, typename ET2, typename ET3,
               enable_if_t<is_integral_v
                           <eigen_val_t<ET3> >()>* = nullptr,
               int... Indx>
      auto make_cmn_domain_impl(indx_seq<Indx...>,
                                ET1 &&, ET2 &&, ET3 &&, int )
        -> cmn_domain_t<sizeof...(Indx)>;

      // Overload #4: bounding_box with cmn::Spacing.
      template<typename BT, unsigned Dim, int... Indx>
      auto make_cmn_domain_impl(indx_seq<Indx...>,
                                BT &&, const cmn::Spacing<Dim> &, int)
        -> cmn_domain_t<sizeof...(Indx)>;

      template<typename PT, int... Indx>
      auto make_cmn_pt_impl(indx_seq<Indx...>, PT &&point)
        -> cmn_pt_t<sizeof...(Indx)>;

      template<unsigned Dim, int... Indx>
      auto domain_center_impl(indx_seq<Indx...>,
                              const cmn::abstract::Domain<Dim> &dom)
        -> cmn_pt_t<Dim>;

      template<typename Scalar, unsigned Dim, int... Indx>
      auto domain_center_lu_impl(indx_seq<Indx...>,
                                 const cmn::abstract::Domain<Dim> &dom)
        -> cmn_pt_t<Dim>;

      template<typename T, unsigned Dim, typename ...ITS, int ...Indx,
               typename = enable_if_all_t<is_integral_v<ITS>()...> >
      auto cmn_coord_pos_impl(indx_seq<Indx...>,
                              const cmn::abstract::Domain<Dim> &,
                              ITS ...) -> Eigen::Matrix<T,Dim,1>;

      template<typename T, typename PT, unsigned Dim, int ...Indx>
      auto cmn_coord_pos_impl(indx_seq<Indx...>,
                              const cmn::abstract::Domain<Dim> &,
                              const cmn::abstract::Point<PT> &)
        -> Eigen::Matrix<T,Dim,1>;

      template<typename Scalar, unsigned Dim, typename ...Coords, int ...Indx,
               typename = enable_if_all_t<is_integral_v<Coords>()...> >
      inline auto
      cmn_pos_to_center_impl(indx_seq<Indx...>,
                             const cmn::abstract::Domain<Dim> &domain,
                             Coords ...coords)
        -> Eigen::Matrix<Scalar,Dim,1>;

      template<typename Scalar, typename Point, unsigned Dim, int ...Indx>
      inline auto
      cmn_pos_to_center_impl(indx_seq<Indx...>,
                             const cmn::abstract::Domain<Dim> &domain,
                             const cmn::abstract::Point<Point> &coords)
        -> Eigen::Matrix<Scalar,Dim,1>;

      template<typename T, typename VT, int ...Indx>
      auto cmn_vec2eigen(indx_seq<Indx...>, VT &&)
        -> Eigen::Matrix<T,sizeof...(Indx),1>;

      // 1
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t
               <is_eigen_v<Position>(),
                is_floating_point_v<eigen_val_t<Position> >(),
                is_integral_v<Coords>()...>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

      // 2
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t
               <is_eigen_v<Position>(),
                is_integral_v<eigen_val_t<Position> >(),
                is_integral_v<Coords>()...>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

      // 3
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t<!is_eigen_v<Position>(),
                               is_integral_v<Coords>()...>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

      // 4
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t
               <is_eigen_v<Position>(),
                is_floating_point_v<eigen_val_t<Position> >(),
                !is_integral_v<PointType>()>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

      // 5
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t<is_eigen_v<Position>(),
                               is_integral_v<eigen_val_t<Position> >(),
                               !is_integral_v<PointType>()>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

      // 6
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t<!is_eigen_v<Position>(),
                               !is_integral_v<PointType>()>* = nullptr>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>;

    }

  }
}


# include "mipp_helpers.hxx"
#endif
