// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// pimpl.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Sep  7 12:54:36 2015 Zhijin Li
// Last update Wed Aug  3 15:27:31 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace internal__
  {
    
    // =====================================================================
    template<typename T>
    pimpl<T>::pimpl():_pdata{new T{}} {};
    
    // =====================================================================
    template<typename T> 
    template<typename ...Args, enable_if_all_t
             <!is_base_of_v<pimpl<T>,decay_t<Args> >()...>*>
    pimpl<T>::pimpl(Args &&...args)
      :_pdata( new T{std::forward<Args>(args)...} ) {};
    
    // =====================================================================
    template<typename T>
    pimpl<T>::pimpl(const pimpl<T> &rhs):
      _pdata( utils::make_unique<T>(*rhs._pdata) ) {};
    
    // =====================================================================
    template<typename T>
    pimpl<T>& pimpl<T>::operator=(const pimpl<T> &rhs)
    {
      *_pdata = *rhs._pdata;
      return *this;
    }
    
    // =====================================================================
    template<typename T>
    pimpl<T>::pimpl(pimpl<T> &&) {};
    
    // =====================================================================
    template<typename T>
    pimpl<T>& pimpl<T>::operator=(pimpl<T> &&) {};
    
    // =====================================================================
    template<typename T>
    pimpl<T>::~pimpl() {}

    // =====================================================================
    template<typename T>
    const T* pimpl<T>::operator->() const { return _pdata.get(); }
    
    // =====================================================================
    template<typename T>
    T* pimpl<T>::operator->() { return _pdata.get(); }

    // =====================================================================
    template<typename T>
    const T& pimpl<T>::operator*() const { return *_pdata.get(); }
    
    // =====================================================================
    template<typename T>
    T& pimpl<T>::operator*() { return *_pdata.get(); }

  } //!internal__
} //!stogeo
