// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// pimpl.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Sep  7 11:48:33 2015 Zhijin Li
// Last update Wed Feb 15 11:40:45 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_PIMPL_HH
# define STOGEO_PIMPL_HH

# include "stogeo/Utilities/utils.hh"


namespace stogeo
{
  namespace internal__
  {
    /// Generic pimpl.
    template<typename T> class pimpl
    {
    public:

      /// Default ctor.
      pimpl();

      /// Variadic forwarding ctor.
      template<typename ...Args, enable_if_all_t
               <!is_base_of_v<pimpl<T>,decay_t<Args> >()...>* = nullptr>
      explicit pimpl(Args &&...);

      /// Copy ctor.
      pimpl(const pimpl<T> &);

      /// Copy assignment.
      pimpl<T>& operator=(const pimpl<T> &);

      /// Move ctor. Defaulted.
      pimpl(pimpl<T> &&);

      /// Move assignment. Defaulted.
      pimpl<T>& operator=(pimpl<T> &&);

      /// Dtor.
      ~pimpl();

      const T* operator->() const;

      T* operator->();

      const T& operator*() const;

      T& operator*();

    private:

      std::unique_ptr<T> _pdata;
    };
  } //!internal__
} //!stogeo


# include "pimpl.hxx"
#endif //!STOGEO_PIMPL_HH
