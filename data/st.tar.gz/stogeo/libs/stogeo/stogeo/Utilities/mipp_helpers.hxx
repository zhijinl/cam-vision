// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// mipp_helpers.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun May  1 21:41:51 2016 Zhijin Li
// Last update Tue Jun 12 11:52:01 2018 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace utils
  {

    // =====================================================================
    template<typename EigVec1, typename EigVec2, typename ...Sizes,
             enable_if_all_t<is_eigen_v<EigVec1>(),
                             is_eigen_v<EigVec2>(),
                             eigen_rows_v<EigVec1>()==
                             sizeof...(Sizes)>*, typename Indx>
    inline auto make_cmn_domain(EigVec1 &&origin, EigVec2 &&spacing,
                                int border, Sizes ...sizes)
      -> cmn_domain_t<eigen_rows_v<EigVec1>()>
    {
      return detail::make_cmn_domain_impl(Indx(),origin,spacing,
                                          border,sizes...);
    }

    // =====================================================================
    template<typename EigVec1, typename EigVec2, typename EigVec3,
             enable_if_all_t<is_eigen_v<EigVec1>(),
                             is_eigen_v<EigVec2>(),
                             is_eigen_v<EigVec3>()>*, typename Indx>
    inline auto make_cmn_domain(EigVec1 &&origin, EigVec2 &&spacing,
                                EigVec3 &&sizes, int border)
      -> cmn_domain_t<eigen_rows_v<EigVec1>()>
    {
      return detail::make_cmn_domain_impl(Indx(),origin,spacing,
                                          sizes,border);
    }

    // =====================================================================
    template<typename BoundType, typename EigVec, enable_if_all_t
             <is_eigen_v<BoundType>(),
              is_eigen_v<EigVec>(),
              is_floating_point_v<eigen_val_t<BoundType> >()>*>
    inline auto make_cmn_domain(BoundType &&bound,
                                EigVec &&spacing,
                                int border)
      -> cmn_domain_t<eigen_rows_v<BoundType>()>
    {
      static_assert(eigen_cols_v<BoundType>()==2,
                    "ERROR: MAKE_CMN_DOMAIN EXPECTS A BOUNDING BOX.");

      return make_cmn_domain(bound.col(0),spacing,bound.col(1)-bound.col(0),
                             border);
    }

    // =====================================================================
    template<typename BoundType, typename EigVec, enable_if_all_t
             <is_eigen_v<BoundType>(),
              is_eigen_v<EigVec>(),
              is_integral_v<eigen_val_t<BoundType> >()>*>
    inline auto make_cmn_domain(BoundType &&bound,
                                EigVec &&spacing,
                                int border)
      -> cmn_domain_t<eigen_rows_v<BoundType>()>
    {
      static_assert(eigen_cols_v<BoundType>()==2,
                    "ERROR: MAKE_CMN_DOMAIN EXPECTS A BOUNDING BOX.");

      return make_cmn_domain(bound.col(0),spacing,
                             ((bound.col(1)-bound.col(0)).array()+1).matrix(),
                             border);
    }

    // =====================================================================
    template<typename BT, unsigned Dim,
             enable_if_t<is_eigen_v<BT>()>*>
    inline auto make_cmn_domain(BT &&bound, const cmn::Spacing<Dim> &spacing,
                                int border)
      -> cmn_domain_t<Dim>
    {
      static_assert(eigen_cols_v<BT>()==2,
                    "ERROR: MAKE_CMN_DOMAIN EXPECTS A BOUNDING BOX.");
      static_assert(eigen_rows_v<BT>()==Dim,
                    "ERROR: BOUNDING BOX AND SPACING DIM MISMATCH.");
      return detail::make_cmn_domain_impl(make_seq_t<Dim>(),bound,
                                          spacing,border);
    }

    // ===================================================================
    template<typename T, typename PT, int Dim, typename>
    auto make_cmn_domain(const shapes::Box<T,Dim> &box, PT &&spacing,
                         int border)
      -> cmn_domain_t<Dim>
    {
      return make_cmn_domain(box.bounding_box(),spacing,border);
    }

    // ===================================================================
    template<typename Shape, unsigned Dim>
    auto make_aligned_domain(Shape &&shape,
                             const cmn::abstract::Domain<Dim> &domain)
      -> std::pair<cmn_dpt_t<Dim>, cmn_domain_t<Dim> >
    {
      static_assert(is_stg_shape_v<Shape>(), "ERROR: EXPECT STOGEO SHAPE.");
      auto __dom = make_cmn_domain(std::forward<Shape>(shape).bounding_box(),
                                   domain.sp());
      auto __shift = align_domains(domain, __dom);
      return std::make_pair(__shift,__dom);
    }

    // ===================================================================
    template<unsigned Dim, typename ...Args>
    auto make_aligned_domain(const cmn::abstract::Domain<Dim> &domain,
                             Args ...args)
      -> std::pair<cmn_dpt_t<Dim>,cmn_domain_t<Dim> >
    {
      auto __dom = make_cmn_domain(std::forward<Args>(args)...);
      auto __shift = align_domains(domain, __dom);
      return std::make_pair(__shift,__dom);
    }

    // ===================================================================
    template<typename PT>
    inline auto make_spacing(PT &&pt) ->
      cmn::Spacing<eigen_rows_v<PT>()>
    {
      static_assert(eigen_colmajor_v<PT>(),
                    "ERROR: INPUT PT IS NOT COLMAJORED.");
      constexpr int __dim = eigen_rows_v<PT>();
      cmn::Spacing<__dim> __sp;
      for(auto __d = 0; __d < __dim; ++__d) __sp[__d] = pt(__d);
      return __sp;
    }

    // =====================================================================
    template<unsigned Dim>
    auto domain_center(const cmn::abstract::Domain<Dim> &domain)
      -> cmn_pt_t<Dim>
    {
      return detail::domain_center_impl(make_seq_t<Dim>(), domain);
    }

    // ===================================================================
    template<typename Scalar, unsigned Dim>
    auto domain_center_lu(const cmn::abstract::Domain<Dim> &domain)
      -> Eigen::Matrix<Scalar,Dim,1>
    {
      return detail::domain_center_lu_impl<Scalar>
        (make_seq_t<Dim>(), domain);
    }

    // =====================================================================
    template<typename Scalar, typename Left, typename Right,
             enable_if_all_t<is_eigen_v<Left>(), is_eigen_v<Right>()>*>
    Scalar comp_inner_prod(Left &&lhs, Right &&rhs)
    {
      return ((lhs.array())*(rhs.array())).sum();
    }

    // =====================================================================
    template<typename Scalar, typename Left, typename Right,
             enable_if_all_t<!is_eigen_v<Left>(), !is_eigen_v<Right>()>*>
    Scalar comp_inner_prod(Left &&lhs, Right &&rhs)
    {
      return cmn::geo::InnerProduct{}(lhs, rhs);
    }

    // ===================================================================
    template<typename T, unsigned Dim>
    auto spacing_to_pt(const cmn::Spacing<Dim> &spacing)
      -> Eigen::Matrix<T,Dim,1>
    {
      return detail::cmn_vec2eigen<T>(make_seq_t<Dim>(),spacing);
    }

    // ===================================================================
    template<typename BT, typename ET,
             enable_if_t<is_eigen_v<BT>()>*>
    inline auto make_cmn_fwditr(BT &&bound, ET &&spacing)
      -> cmn_fwditr_t<eigen_rows_v<BT>()>
    {
      static_assert(eigen_cols_v<BT>()==2,
                    "ERROR: MAKE_CMN_FWDITR EEXPECTS A BOUNDING BOX.");
      constexpr int __dim = eigen_rows_v<BT>();
      return cmn_fwditr_t<__dim>(make_cmn_domain(bound,spacing));
    }

    // =====================================================================
    template<typename ...TPS,
             enable_if_all_t<is_arithmetic_v<TPS>()...>*>
    inline auto make_cmn_pt(TPS ...args) -> cmn_pt_t<sizeof...(TPS)>
    {
      static_assert(seq_and_v<is_integral_v<TPS>()...>(),
                    "ERROR: MAKE_CMN_PT EXPECTS INTEGRAL TYPES.");
      return cmn_pt_t<sizeof...(TPS)>(args...);
    }

    // ===================================================================
    template<typename PT>
    cmn_pt_t<eigen_rows_v<PT>()> make_cmn_pt(PT &&pt)
    {
      static_assert(is_eigen_v<PT>() && eigen_cols_v<PT>()==1
                    && is_integral_v<eigen_val_t<PT> >(),
                    "ERROR: EXPECTS AND EIGEN INTEGRAL COLUMN VEC.");

      constexpr int __dim = eigen_rows_v<PT>();
      static_assert(__dim == 1 || __dim == 2 || __dim == 3,
                    "ERROR: CMN POINT MUST BE 1D, 2D OR 3D.");

      return detail::make_cmn_pt_impl(make_seq_t<__dim>{}, pt);
    }

    // ===================================================================
    template<unsigned Dim, typename PT>
    auto make_cmn_pt(PT &&pt, const cmn::abstract::Domain<Dim> &dom)
      -> cmn_pt_t<Dim>
    {
      static_assert(is_eigen_v<PT>() && eigen_cols_v<PT>()==1,
                    "ERROR: EXPECTS AND EIGEN COLUMN VEC.");
      static_assert(eigen_rows_v<PT>()==Dim,
                    "ERROR: POINT AND DOMAIN DIMENSION MISMATCH.");

      cmn_pt_t<Dim> __pos;
      for(unsigned __d = 0; __d < Dim; ++__d)
        __pos[__d] = std::round((pt(__d)-dom.originLU(__d))/dom.sp()[__d]);
      return __pos;
    }

    // ===================================================================
    template<unsigned Dim, typename Integral>
    auto cmn_ind_pos(Integral indx, const cmn::abstract::Domain<Dim> &dom)
      -> cmn_pt_t<Dim>
    {
      cmn_pt_t<Dim> __res;
      for(unsigned __d = 0; __d < Dim; ++__d)
      {
        int __stride = 1;
        for(unsigned __n = 0; __n < __d; ++__n) __stride *= dom[__n];
        __res[__d] = (indx/__stride) % dom[__d];
      }
      return __res;
    }

    // ===================================================================
    template<typename ET>
    int cmn_itr_ind(const cmn::abstract::FwdIterator<ET> &it)
    {
      constexpr int __dim = cmn_it_dim(ET);
      using __point_t = cmn_it_point_type(ET);
      int __res = __point_t(it)[0];

      for(auto __m = 1; __m < __dim; ++__m)
      {
        int __inner = 1;
        for(auto __n = 0; __n < __m; ++__n) __inner *= it.domain()[__n];
        __res += __point_t(it)[__m]*__inner;
      }
      return __res;
    }

    // ===================================================================
    template<typename T, typename ET>
    auto cmn_itr_pos(const cmn::abstract::FwdIterator<ET> &it)
      -> Eigen::Matrix<T,cmn_it_dim(ET),1>
    {
      constexpr int __dim = cmn_it_dim(ET);
      using __point_t = cmn_it_point_type(ET);

      Eigen::Matrix<T,cmn_it_dim(ET),1> __pos;
      for(auto __d = 0; __d < __dim; ++__d)
        __pos(__d) = static_cast<T>(it.domain().originLU(__d)+
                                    __point_t(it)[__d]*it.domain().sp()[__d]);
      return __pos;
    }

    // ===================================================================
    template<typename T, unsigned Dim, typename ...ITS>
    inline auto cmn_coord_pos(const cmn::abstract::Domain<Dim> &domain,
                              ITS ...coords)
      -> Eigen::Matrix<T,Dim,1>
    {
      return detail::cmn_coord_pos_impl<T>(make_seq_t<Dim>(),
                                           domain,coords...);
    }

    // ===================================================================
    template<typename T, typename PT, unsigned Dim>
    inline auto cmn_coord_pos(const cmn::abstract::Domain<Dim> &domain,
                              const cmn::abstract::Point<PT> &coord)
      -> Eigen::Matrix<T,Dim,1>
    {
      return detail::cmn_coord_pos_impl<T>(make_seq_t<Dim>(),
                                           domain,coord);
    }

    // ===================================================================
    template<typename Scalar, unsigned Dim, typename ...Coords>
    inline auto cmn_pos_to_center(const cmn::abstract::Domain<Dim> &domain,
                                  Coords ...coords)
      -> Eigen::Matrix<Scalar,Dim,1>
    {
      return detail::cmn_pos_to_center_impl<Scalar>(make_seq_t<Dim>(),
                                                    domain,coords...);
    }

    // ===================================================================
    template<typename Scalar, typename Point, unsigned Dim>
    inline auto cmn_pos_to_center(const cmn::abstract::Domain<Dim> &domain,
                                  const cmn::abstract::Point<Point> &coord)
      -> Eigen::Matrix<Scalar,Dim,1>
    {
      return detail::cmn_pos_to_center_impl<Scalar>(make_seq_t<Dim>(),
                                                    domain,coord);
    }

    // =====================================================================
    template<typename PointType, enable_if_all_t
             <is_eigen_v<PointType>(),
              is_integral_v<eigen_val_t<PointType> >()>*>
    auto to_dpoint(PointType &&pt) -> cmn_dpt_t<eigen_rows_v<PointType>()>
    {
      constexpr int __dim = eigen_rows_v<PointType>();

      cmn_dpt_t<__dim> __pt{};
      for(int __d = 0; __d < __dim; ++__d) __pt[__d] = pt(__d);
      return __pt;
    }

    // =====================================================================
    template<typename PointType, enable_if_t<!is_eigen_v<PointType>()>*>
    auto to_dpoint(PointType &&pt) -> cmn_dpt_t<cmn_dim(decay_t<PointType>)>
    {
      constexpr int __dim = cmn_dim(decay_t<PointType>);

      cmn_dpt_t<__dim> __pt{};
      for(int __d = 0; __d < __dim; ++__d) __pt[__d] = pt[__d];
      return __pt;
    }

    // =====================================================================
    template<typename PointType , typename DomainType, typename>
    auto to_discrete_pos_eigen(PointType &&pos, const DomainType &domain)
      -> Eigen::Matrix<int,cmn_domdim_v<DomainType>(),1>
    {
      constexpr int __dim = cmn_domdim_v<DomainType>();

      cmn_pt_t<__dim> __pos = make_cmn_pt(pos,domain);
      Eigen::Matrix<int,__dim,1> __res;
      for(int __d = 0; __d < __dim; ++__d) __res(__d) = __pos[__d];
      return __res;
    }

    // =====================================================================
    template<typename PointType , typename DomainType,
             enable_if_t<!is_eigen_v<PointType>()>*>
    auto to_discrete_pos(PointType &&pos, const DomainType &)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>
    {
      return std::forward<PointType>(pos);
    }

    // =====================================================================
    template<typename PointType , typename DomainType,
             enable_if_all_t
             <is_eigen_v<PointType>(),
              is_floating_point_v<eigen_val_t<PointType> >()>*>
    auto to_discrete_pos(PointType &&pos, const DomainType &domain)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>
    {
      return make_cmn_pt(std::forward<PointType>(pos), domain);
    }

    // =====================================================================
    template<typename PointType , typename DomainType,
             enable_if_all_t<is_eigen_v<PointType>(),
                             is_integral_v<eigen_val_t<PointType> >()>*>
    auto to_discrete_pos(PointType &&pos, const DomainType &domain)
      -> cmn_pt_t<cmn_domdim_v<DomainType>()>
    {
      constexpr int __dim = cmn_domdim_v<DomainType>();

      cmn_pt_t<__dim> __pos;
      for(unsigned __d = 0; __d < __dim; ++__d) __pos[__d] = pos(__d);
      return __pos;
    }

    // =====================================================================
    template<typename Scalar, typename PositionType, typename DomainType,
             typename ...Coords, enable_if_all_t<is_integral_v<Coords>()...>*>
    auto comp_pos_shift(PositionType &&src, const DomainType &domain,
                        Coords ...dst_coords)
      -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
    {
      constexpr int __dim = cmn_domdim_v<DomainType>();

      return detail::comp_pos_shift_impl<Scalar>
        ( make_seq<__dim>{}, std::forward<PositionType>(src),
          domain, dst_coords... );
    }

    // =====================================================================
    template<typename Scalar, typename PositionType, typename DomainType,
             typename PointType, enable_if_t<!is_integral_v<PointType>()>*>
    auto comp_pos_shift(PositionType &&src, const DomainType &domain,
                        PointType &&dst)
      -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
    {
      constexpr int __dim = cmn_domdim_v<DomainType>();

      return detail::comp_pos_shift_impl<Scalar>
        ( make_seq<__dim>{}, std::forward<PositionType>(src), domain, dst );
    }

    // ===================================================================
    template<typename ...TPS,
             enable_if_all_t<is_arithmetic_v<TPS>()...>*>
    inline auto make_cmn_dpt(TPS ...args) -> cmn_dpt_t<sizeof...(TPS)>
    {
      static_assert(seq_and_v<is_integral_v<TPS>()...>(),
                    "ERROR: MAKE_CMN_DPT EXPECTS INTEGRAL TYPES.");
      using __dpoint_t = cmn_dpt_t<sizeof...(TPS)>;
      return __dpoint_t(args...);
    }

    // ===================================================================
    template<typename PT1, typename PT2,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>()>*>
    auto comp_dpoint(PT1 &&src, PT2 &&dst) -> cmn_dpt_t<eigen_rows_v<PT1>()>
    {
      static_assert(is_integral_v<eigen_val_t<PT1> >() &&
                    is_integral_v<eigen_val_t<PT2> >(),
                    "ERROR: EXPECTS INTEGRAL VEC. USE EIGEN CAST.");
      static_assert((eigen_cols_v<PT1>() == 1) &&
                    (eigen_cols_v<PT2>() == 1),
                    "ERROR: EXPECTS EIGEN POINTS.");
      static_assert(eigen_rows_v<PT1>() ==
                    eigen_rows_v<PT2>(),
                    "ERROR: SRC AND DST DIM MISMATCH.");
      constexpr int __dim = eigen_rows_v<PT1>();

      cmn_pt_t<__dim> __dpt;
      for(auto __n = 0; __n < __dim; ++__n) __dpt[__n] = dst(__n)-src(__n);
      return __dpt;
    }

    // ===================================================================
    template<typename PT1, typename PT2, typename PT3,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>(),
                             is_eigen_v<PT3>()>*>
    auto comp_dpoint(PT1 &&src, PT2 &&dst, PT3 &&spacing)
      -> cmn_dpt_t<eigen_rows_v<PT1>()>
    {
      constexpr int __dim = eigen_rows_v<PT1>();

      static_assert((eigen_cols_v<PT1>() == 1) &&
                    (eigen_cols_v<PT2>() == 1) &&
                    (eigen_cols_v<PT3>() == 1),
                    "ERROR: COMP DPOINT EXPECTS EIGEN POINTS.");
      static_assert(eigen_rows_v<PT1>() == __dim &&
                    eigen_rows_v<PT2>() == __dim &&
                    eigen_rows_v<PT3>() == __dim,
                    "ERROR: SRC OR DST DIM MISMATCH.");

      cmn_dpt_t<__dim> __dpt;
      for(auto __n = 0; __n < __dim; ++__n)
      { __dpt[__n] = std::round((dst(__n)-src(__n))/spacing(__n)); }
      return __dpt;
    }

    // ===================================================================
    template<typename PT1, typename PT2, typename PT3, unsigned Dim,
             enable_if_all_t<is_eigen_v<PT1>(),
                             is_eigen_v<PT2>()>*>
    auto comp_dpoint(PT1 &&src, PT2 &&dst, const cmn::Spacing<Dim> &spacing)
      -> cmn_dpt_t<Dim>
    {
      static_assert((eigen_cols_v<PT1>() == 1) &&
                    (eigen_cols_v<PT2>() == 1),
                    "ERROR: COMP DPOINT EXPECTS EIGEN POINTS.");
      static_assert(eigen_rows_v<PT1>() == Dim &&
                    eigen_rows_v<PT2>() == Dim,
                    "ERROR: SRC OR DST DIM MISMATCH.");

      cmn_dpt_t<Dim> __dpt;
      for(unsigned __n = 0; __n < Dim; ++__n)
      { __dpt[__n] = std::round((dst(__n)-src(__n))/spacing[__n]); }
      return __dpt;
    }

    // ===================================================================
    template<unsigned Dim>
    auto align_domains(const cmn::abstract::Domain<Dim> &src,
                       cmn::abstract::Domain<Dim> &dst)
      -> cmn_dpt_t<Dim>
    {
      assert(src.sp() == dst.sp());

      cmn_dpt_t<Dim> __shift;
      for(unsigned __d = 0; __d < Dim; ++__d)
      {
        int delta_low = static_cast<int> // round down.
          ((dst.originLU(__d) - src.originLU(__d))/src.sp()[__d]);
        int delta_high = std::ceil       // round up.
          ((dst.originLU(__d)+dst[__d]*dst.sp()[__d]-
            src.originLU(__d))/src.sp()[__d]);

        dst[__d] = delta_high - delta_low;
        dst.origin(__d) = src.origin(__d)+delta_low;
        __shift[__d] = delta_low;
      }

      return __shift;
    }

    // ===================================================================
    template<unsigned Dim>
    auto domain_origin_shift(const cmn::abstract::Domain<Dim> &src,
                             const cmn::abstract::Domain<Dim> &dst)
      -> cmn_dpt_t<Dim>
    {
      cmn_dpt_t<Dim> __shift;
      for(unsigned __d = 0; __d < Dim; ++__d)
        __shift[__d] = std::round(dst.origin(__d)-src.origin(__d));
      return __shift;
    }

    // ===================================================================
    template<typename DT>
    bool domain_intersect(DT &&lhs, DT &&rhs)
    {
      constexpr int __dim = decay_t<DT>::dim;
      for(int __i = 0; __i < __dim; ++__i)
      {
        if( (lhs.originLU(__i) < rhs.originLU(__i)+rhs[__i]*rhs.sp()[__i]) &&
            (lhs.originLU(__i)+lhs[__i]*lhs.sp()[__i] > rhs.originLU(__i)) )
          continue;
        else
          return false;
      }
      return true;
    }

    // ===================================================================
    template<typename T, int Dim>
    auto make_bound(const cmn::abstract::Domain<Dim> &domain)
      -> Eigen::Matrix<T,Dim,2>
    {
      Eigen::Matrix<T,Dim,2> __bound;

      for(unsigned __d = 0; __d < Dim; ++__d)
      {
        __bound(__d,0) = domain.originLU(__d);
        __bound(__d,1) += (domain[__d]-1)*domain.sp()[__d];
      }
      return __bound;
    }

    // ===================================================================
    template<typename VT,
             enable_if_t<is_eigen_v<VT>()>*>
    auto vec2signal(VT &&vec) -> cmn::Signal<eigen_val_t<VT> >
    {
      static_assert(eigen_cols_v<VT>() == 1,
                    "ERROR: VEC2SIGNAL EXPECTS AN EIGEN VECTOR.");

      using __signal_t = cmn::Signal<eigen_val_t<VT> >;
      auto __res = __signal_t(vec.size());

      cmn_iter_type(__signal_t) __it(__res.domain());
      cmn_for_all(__it) __res[__it] = vec(cmn::Point1D(__it)[0]);

      return __res;
    }

    // ===================================================================
    template<typename T>
    Eigen::Matrix<T,Eigen::Dynamic,1> signal2vec(const cmn::Signal<T> &sig)
    {
      Eigen::Matrix<T,Eigen::Dynamic,1> __vec(sig.domain().card());
      cmn_iter_type(cmn::Signal<T>) __it_sig(sig.domain());

      cmn_for_all(__it_sig)
        __vec(cmn::Point1D(__it_sig)[0]) = sig[__it_sig];
      return __vec;
    }

    // ===================================================================
    template<typename T>
    Eigen::Matrix<T,Eigen::Dynamic,2> hist2mat(const mipp::Histogram<T> &hist)
    {
      Eigen::Matrix<T,Eigen::Dynamic,2> __mat(hist.domain().card(),2);
      cmn_iter_type(mipp::Histogram<T>) __it_hist(hist.domain());

      cmn_for_all(__it_hist)
        __mat(cmn::Point1D(__it_hist)[0],0) = static_cast<T>(hist[__it_hist]);
      // Note: Histo holds unsigned. static_cast to T for uniformity.
      __mat.col(1) = Eigen::Matrix<T,-1,1>::
        LinSpaced(hist.domain().card(),hist.domain().min(),hist.domain().max());
      return __mat;
    }

    namespace detail
    {
      // ===================================================================
      template<typename ET1, typename ET2, int... Indx, typename ...ITS>
      inline auto make_cmn_domain_impl(indx_seq<Indx...>,
                                       ET1 &&origin, ET2 &&spacing,
                                       int border, ITS ...sizes)
        -> cmn_domain_t<sizeof...(Indx)>
      {
        constexpr int __dim = eigen_rows_v<ET1>();
        static_assert(seq_and_v<is_integral_v<ITS>()...>(),
                      "ERROR: EXPECTS INTEGRAL TYPE SIZE.");
        static_assert(eigen_cols_v<ET1>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR ORIGIN.");
        static_assert(eigen_cols_v<ET2>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR SPACING.");
        static_assert(eigen_rows_v<ET2>()==__dim,
                      "ERROR: ORIGIN/SPACING DIMENSION MISMATCH.");
        static_assert(sizeof...(Indx)==__dim,
                      "ERROR: NUM OF INDICES DOES NOT MATCH DIMENSION .");
        return cmn_domain_t<__dim>((sizes)..., border, spacing(Indx)...,
                                   (origin(Indx)/spacing(Indx))...);
      }

      // ===================================================================
      template<typename ET1, typename ET2, typename ET3,
               enable_if_t<is_floating_point_v
                           <eigen_val_t<ET3> >()>*,
               int... Indx>
      inline auto make_cmn_domain_impl(indx_seq<Indx...>,
                                       ET1 &&origin, ET2 &&spacing,
                                       ET3 &&sizes, int border)
        -> cmn_domain_t<sizeof...(Indx)>
      {
        constexpr int __dim = eigen_rows_v<ET1>();
        static_assert(eigen_cols_v<ET1>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR ORIGIN.");
        static_assert(eigen_cols_v<ET2>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR SPACING.");
        static_assert(eigen_cols_v<ET3>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR SIZES.");
        static_assert(eigen_rows_v<ET2>()==__dim &&
                      eigen_rows_v<ET3>()==__dim,
                      "ERROR: SIZES/ORIGIN/SPACING  DIMENSION MISMATCH.");
        static_assert(sizeof...(Indx)==__dim,
                      "ERROR: NUMB OF INDICES DOES NOT MATCH DIMENSION .");
        return cmn_domain_t<__dim>((std::ceil(sizes(Indx)/spacing(Indx))+1)...,
                                   border, spacing(Indx)...,
                                   (origin(Indx)/spacing(Indx))...);
      }

      // ===================================================================
      template<typename ET1, typename ET2, typename ET3,
               enable_if_t<is_integral_v
                           <eigen_val_t<ET3> >()>*,
               int... Indx>
      inline auto make_cmn_domain_impl(indx_seq<Indx...>,
                                       ET1 &&origin, ET2 &&spacing,
                                       ET3 &&sizes, int border)
        -> cmn_domain_t<sizeof...(Indx)>
      {
        constexpr int __dim = eigen_rows_v<ET1>();
        static_assert(eigen_cols_v<ET1>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR ORIGIN.");
        static_assert(eigen_cols_v<ET2>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR SPACING.");
        static_assert(eigen_cols_v<ET3>()==1,
                      "ERROR: EXPECTS EIGEN VECS FOR SIZES.");
        static_assert(eigen_rows_v<ET2>()==__dim &&
                      eigen_rows_v<ET3>()==__dim,
                      "ERROR: SIZES/ORIGIN/SPACING  DIMENSION MISMATCH.");
        static_assert(sizeof...(Indx)==__dim,
                      "ERROR: NUM OF INDICES DOES NOT MATCH DIMENSION .");
        return cmn_domain_t<__dim>(sizes(Indx)..., border, spacing(Indx)...,
                                   (origin(Indx)/spacing(Indx))...);
      }

      // ===================================================================
      template<typename BT, unsigned Dim, int... Indx>
      auto make_cmn_domain_impl(indx_seq<Indx...>, BT &&bound,
                                const cmn::Spacing<Dim> &spacing,
                                int border)
        -> cmn_domain_t<sizeof...(Indx)>
      {
        return cmn_domain_t<Dim>((std::ceil((bound.col(1)-bound.col(0))(Indx)/
                                            spacing[Indx])+1)...,
                                 border, spacing[Indx]...,
                                 (bound.col(0)(Indx)/spacing[Indx])...);
      }

      // ===================================================================
      template<typename PT, int... Indx>
      auto make_cmn_pt_impl(indx_seq<Indx...>, PT &&point)
        -> cmn_pt_t<sizeof...(Indx)>
      {
        return cmn_pt_t<sizeof...(Indx)>(point(Indx)...);
      }

      // ==================================================================
      template<unsigned Dim, int... Indx>
      auto domain_center_impl(indx_seq<Indx...>,
                              const cmn::abstract::Domain<Dim> &dom)
        -> cmn_pt_t<Dim>
      {
        return cmn_pt_t<Dim>{(dom[Indx]/2)...};
      }

      // ==================================================================
      template<typename Scalar, unsigned Dim, int... Indx>
      auto domain_center_lu_impl(indx_seq<Indx...>,
                                 const cmn::abstract::Domain<Dim> &dom)
        -> cmn_pt_t<Dim>
      {
        return cmn_pt_t<Dim>
        {(dom.originLU(Indx) + dom[Indx]*dom.spacing()[Indx]/2.0)...};
      }

      // ===================================================================
      template<typename T, unsigned Dim, typename ...ITS, int ...Indx,
               typename>
      inline auto cmn_coord_pos_impl(indx_seq<Indx...>,
                                     const cmn::abstract::Domain<Dim> &domain,
                                     ITS ...coords) -> Eigen::Matrix<T,Dim,1>
      {
        static_assert(sizeof...(ITS)==Dim,
                      "ERROR: NUMB OF COORDS AND DOMAIN DIM MISMATCH");
        static_assert(is_integral_v<common_type_t<ITS...> >(),
                      "ERROR: EXPECTS INTEGRAL TYPES FOR SIZES.");

        return Eigen::Matrix<T,Dim,1>
        {(domain.originLU(Indx)+coords*domain.sp()[Indx])...};
      }

      // ===================================================================
      template<typename T, typename PT, unsigned Dim, int ...Indx>
      inline auto cmn_coord_pos_impl(indx_seq<Indx...>,
                                     const cmn::abstract::Domain<Dim> &domain,
                                     const cmn::abstract::Point<PT> &coord)
        -> Eigen::Matrix<T,Dim,1>
      {
        static_assert(cmn_dim(PT)==Dim,
                      "ERROR: COORDINATES AND DOMAIN DIM MISMATCH");

        return Eigen::Matrix<T,Dim,1>
        {(domain.originLU(Indx)+coord[Indx]*domain.sp()[Indx])...};
      }

      // ===================================================================
      template<typename Scalar, unsigned Dim, typename ...Coords,
               int ...Indx, typename>
      inline auto
      cmn_pos_to_center_impl(indx_seq<Indx...>,
                             const cmn::abstract::Domain<Dim> &domain,
                             Coords ...coords)
        -> Eigen::Matrix<Scalar,Dim,1>
      {
        static_assert(sizeof...(Coords)==Dim,
                      "ERROR: NUMB OF COORDS AND DOMAIN DIM MISMATCH");
        static_assert(is_integral_v<common_type_t<Coords...> >(),
                      "ERROR: EXPECTS INTEGRAL TYPES FOR SIZES.");

        return Eigen::Matrix<Scalar,Dim,1>
        { ((coords-domain[Indx]/2)*domain.sp()[Indx])... };
      }

      // ===================================================================
      template<typename Scalar, typename Point, unsigned Dim, int ...Indx>
      inline auto
      cmn_pos_to_center_impl(indx_seq<Indx...>,
                             const cmn::abstract::Domain<Dim> &domain,
                             const cmn::abstract::Point<Point> &coords)
        -> Eigen::Matrix<Scalar,Dim,1>
      {
        static_assert(cmn_dim(Point)==Dim,
                      "ERROR: COORDINATES AND DOMAIN DIM MISMATCH");

        return Eigen::Matrix<Scalar,Dim,1>
        { ((coords[Indx]-domain[Indx]/2)*domain.sp()[Indx])... };
      }

      // ===================================================================
      template<typename T, typename VT, int ...Indx>
      inline auto cmn_vec2eigen(indx_seq<Indx...>, VT &&vec)
        -> Eigen::Matrix<T,sizeof...(Indx),1>
      {
        return Eigen::Matrix<T,sizeof...(Indx),1>{vec[Indx]...};
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t
               <is_eigen_v<Position>(),
                is_floating_point_v<eigen_val_t<Position> >(),
                is_integral_v<Coords>()...>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( (dst_coords*domain.sp()[Indx]-
             (static_cast<Scalar>(src(Indx)) - domain.originLU(Indx)))... );
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t<is_eigen_v<Position>(),
                               is_integral_v<eigen_val_t<Position> >(),
                               is_integral_v<Coords>()...>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( ((dst_coords-src(Indx))*domain.sp()[Indx])... );
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename ...Coords, int ...Indx,
               enable_if_all_t<!is_eigen_v<Position>(),
                               is_integral_v<Coords>()...>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               Coords ...dst_coords)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( ((dst_coords-src[Indx])*domain.sp()[Indx])... );
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t
               <is_eigen_v<Position>(),
                is_floating_point_v<eigen_val_t<Position> >(),
                !is_integral_v<PointType>()>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( (dst[Indx]*domain.sp()[Indx] -
             (static_cast<Scalar>(src(Indx)) - domain.originLU(Indx)))... );
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t<is_eigen_v<Position>(),
                               is_integral_v<eigen_val_t<Position> >(),
                               !is_integral_v<PointType>()>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( ((dst[Indx]-src(Indx))*domain.sp()[Indx])... );
      }

      // =====================================================================
      template<typename Scalar, typename Position, typename DomainType,
               typename PointType, int ...Indx,
               enable_if_all_t<!is_eigen_v<Position>(),
                               !is_integral_v<PointType>()>*>
      auto comp_pos_shift_impl(indx_seq<Indx...>,
                               Position &&src,
                               const DomainType &domain,
                               PointType &&dst)
        -> Eigen::Matrix<Scalar,cmn_domdim_v<DomainType>(),1>
      {
        return make_eigen_pt<Scalar>
          ( ((dst[Indx]-src[Indx])*domain.sp()[Indx])... );
      }

    }

  }
}
