// ---------------------------------------------------------------------------
// Copyright (c) 2017 by General Electric Medical Systems
//
// tuple_hash.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Feb 28 00:08:01 2017 Zhijin Li
// Last update Tue Feb 28 00:09:57 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include <tuple>


namespace stogeo
{
  namespace utils
  {

    /// @brief Base case for tuple hash.
    ///
    /// Calls `std::hash` internally.
    ///
    template <typename Type> struct tuple_hash
    {
      std::size_t operator()(const Type &input) const
      {
        return std::hash<Type>()(input);
      }
    };

    /// @brief Combine new hashed value to existing one.
    ///
    /// @note See http://stackoverflow.com/questions/4948780.
    ///
    /// @param lhs: an existing hashed value.
    /// @param rhs: a new hashed value to be combined.
    ///
    template <class Type>
    void hash_combine(std::size_t& lhs, const Type &rhs)
    {
      lhs ^= stogeo::tuple_hash<Type>()(rhs) + 0x9e3779b9 + (lhs<<6) + (lhs>>2);
    }

    namespace detail
    {

      ///@{
      ///
      /// @brief Recursively hash each key in tuple, and combine them
      /// to a final value.
      ///
      template <class Tuple, std::size_t Indx=(std::tuple_size<Tuple>::value-1)>
      struct hash_value_impl
      {
        static void apply(std::size_t& seed, const Tuple &tuple)
        {
          hash_value_impl<Tuple,Indx-1>::apply(seed, tuple);
          hash_combine(seed, std::get<Indx>(tuple));
        }
      };

      template <class Tuple>
      struct hash_value_impl<Tuple,0>
      {
        static void apply(std::size_t& seed, Tuple const& tuple)
        {
          hash_combine(seed, std::get<0>(tuple));
        }
      };
      ///@}

    }

    /// @brief Hash a tuple of basic type keys.
    ///
    /// @note Types must expands to standard library defined hashable
    /// types.
    ///
    template <typename ...Types>
    struct tuple_hash<std::tuple<Types...> >
    {
      std::size_t operator()(std::tuple<Types...> const& tt) const
      {
        std::size_t seed = 0;
        detail::hash_value_impl<std::tuple<Types...> >::apply(seed, tt);
        return seed;
      }
    };

  }
}
