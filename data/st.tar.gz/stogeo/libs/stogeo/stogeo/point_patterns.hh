// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// point_patterns.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 18 17:28:47 2016 Zhijin Li
// Last update Fri Aug  5 17:48:55 2016 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_POINT_PATTERNS_HH
# define STOGEO_POINT_PATTERNS_HH

# include "PointPatterns/SimplePointPattern.hh"
# include "PointPatterns/MarkedPointPattern.hh"

#endif //!STOGEO_POINT_PATTERNS_HH
