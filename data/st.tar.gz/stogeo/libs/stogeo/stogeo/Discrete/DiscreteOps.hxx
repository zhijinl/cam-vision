// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// DiscreteOps.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue May 17 08:43:20 2016 Zhijin Li
// Last update Tue Dec 12 10:20:39 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace discrete
  {

    // =====================================================================
    template<typename CastType, typename T, typename Dom,
             enable_if_all_t<is_cmn_domain_v<Dom>(),
                             is_same_v<CastType,T>()>*>
    auto make_discrete_field(std::unique_ptr<T[]> data_ptr, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>
    {
      assert(!domain.border_inf(0) && "err: border must be zero.");
      assert(!domain.border_sup(0) && "err: border must be zero.");
      assert(!domain.border_inf(1) && "err: border must be zero.");
      assert(!domain.border_sup(1) && "err: border must be zero.");

      constexpr int __dim = cmn_domdim_v<Dom>();
      return detail::make_discrete_field_impl<CastType>
        (make_seq_t<__dim>(),std::move(data_ptr),std::forward<Dom>(domain));
    }

    // =====================================================================
    template<typename CastType, typename T, typename Dom,
             enable_if_all_t<is_cmn_domain_v<Dom>(),
                             !is_same_v<CastType,T>()>*>
    auto make_discrete_field(std::unique_ptr<T[]> data_ptr, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>
    {
      constexpr int __dim = cmn_domdim_v<Dom>();
      cmn_img_t<CastType,__dim> __field(domain);
      cmn_fwditr_t<__dim> __it(domain);

      cmn_for_all(__it) __field[__it] = data_ptr[utils::cmn_itr_ind(__it)];
      return __field;
    }

    // =====================================================================
    template<typename T, typename ImType>
    void make_discrete_field(std::unique_ptr<T[]> data_ptr,
                             cmn::abstract::Image<ImType> &im)
    {
      constexpr int __dim = cmn_dim(ImType);
      cmn_fwditr_t<__dim> __it(im.domain());
      cmn_for_all(__it) im[__it] = data_ptr[utils::cmn_itr_ind(__it)];
    }

    // =====================================================================
    template<typename CastType, typename T, typename Dom, typename>
    auto make_discrete_field(const std::vector<T> &data_vec, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>
    {
      assert( (data_vec.size() == domain.card() ) &&
              "vector size and domain cardinality mismatch.");
      constexpr int __dim = cmn_domdim_v<Dom>();
      cmn_img_t<CastType,__dim> __field(domain);
      cmn_fwditr_t<__dim> __it(domain);

      cmn_for_all(__it) __field[__it] = data_vec[utils::cmn_itr_ind(__it)];
      return __field;
    }

    // =====================================================================
    template<typename T, typename ImType, typename>
    void make_discrete_field(const std::vector<T> &data_vec,
                             cmn::abstract::Image<ImType> &im)
    {
      assert( (data_vec.size() == im.domain().card() ) &&
              "vector size and domain cardinality mismatch.");

      constexpr int __dim = cmn_dim(ImType);
      cmn_fwditr_t<__dim> __it(im.domain());
      cmn_for_all(__it) im[__it] = data_vec[utils::cmn_itr_ind(__it)];
    }

    // =====================================================================
    template<typename CastType, typename Value, int Dim, typename ...Args>
    auto make_discrete_field(const char *in_path, Args &&...domain_args)
      -> cmn_img_t<CastType,Dim>
    {
      auto __arr = stogeo::io::read_raw_to_array<Value>(std::string(in_path));
      auto __dom = utils::make_cmn_domain(std::forward<Args>(domain_args)...);

      assert(std::get<0>(__arr) == __dom.card() &&
             "arr size and domain cardinality must be the same");
      return make_discrete_field<CastType>
        ( std::move(std::get<1>(__arr)), __dom);
    }

    // =====================================================================
    template<typename E, typename Rule>
    inline int cmn_count_if(const cmn::abstract::Image<E> &field, Rule rule)
    {
      long __count = 0;
      cmn_iter_type(E) __it(field.domain());
      cmn_for_all(__it) if( rule(__it.point()) ) ++__count;

      return __count;
    }

    // =====================================================================
    template<typename Mark, typename PT>
    float overlap_ratio_lattice_cmn(int ind, PT &&spacing,
                                    const MarkedPointPattern<Mark> &mpp)
    {
      using __point_t = typename Mark::point_t;
      auto __ref_latt = mpp.mark(ind).template discrete<short>
        (std::forward<PT>(spacing));
      cmn_iter_type(decltype(__ref_latt)) __local_it(__ref_latt.domain());

      // Pre-filtering out unreachable ones.
      using __scalr_t = typename Mark::scalr_t;
      using __slice_t =
        typename traits::specs<MarkedPointPattern<Mark> >::slice_t;
      __slice_t __lv(mpp.n_elem());
      for(auto __l = 0; __l < mpp.n_elem(); ++__l)
      {
        __scalr_t __tmp_rad = mpp.mark(__l).enclosing_radius() +
          mpp.mark(ind).enclosing_radius();
        __point_t __tmp_dist = mpp.mark(__l).centre()-mpp.mark(ind).centre();
        __lv(__l) = __tmp_dist.transpose()*__tmp_dist < __tmp_rad*__tmp_rad;
      }

      int __n_total = 0;
      int __n_overlap = 0;
      __point_t __query_pt = __point_t::Zero();
      cmn_for_all(__local_it)
      {
        if( !__ref_latt[__local_it] )
        {
          __query_pt = utils::cmn_itr_pos<typename Mark::scalr_t>(__local_it);
          if( !mpp.out_of_bound(__query_pt) )
          { // Consider only pt inside mpp's obs_window.
            ++__n_total;
            if( std::find_if(std::begin(mpp.marks()),
                             std::end(mpp.marks()),
                             [&__query_pt,ind,&mpp,&__lv]
                             (const Mark &__gr)
                             {
                               return __lv(&__gr-&mpp.mark(0))
                                 && (&__gr != &mpp.mark(ind))
                                 && __gr.inside_test(__query_pt);
                             } )
                != std::end(mpp.marks()) ) ++__n_overlap;
          }
        }
      }
      return static_cast<float>(__n_overlap)/__n_total;
    }

    // =====================================================================
    template<typename Mark, typename E, typename Rule>
    float overlap_ratio_lattice(int ind, const cmn::abstract::Image<E> &mask,
                                const MarkedPointPattern<Mark> &mpp,
                                Rule val_rule)
    {
      // Pre-filtering out unreachable ones.
      using __scalr_t = typename Mark::scalr_t;
      using __point_t =
        typename traits::specs<decay_t<decltype(mpp)> >::point_t;
      using __slice_t =
        typename traits::specs<decay_t<decltype(mpp)> >::slice_t;
      constexpr int __dim = cmn_dim(E);

      __slice_t __lv(mpp.n_elem());
      for(auto __l = 0; __l < mpp.n_elem(); ++__l)
      {
        __scalr_t __tmp_rad = mpp.mark(__l).enclosing_radius() +
          mpp.mark(ind).enclosing_radius();
        __point_t __tmp_dist = mpp.mark(__l).centre()-mpp.mark(ind).centre();
        __lv(__l) = __tmp_dist.transpose()*__tmp_dist < __tmp_rad*__tmp_rad;
      }

      cmn_fwditr_t<__dim> __global_it(mask.domain());
      auto __local_dom = utils::make_cmn_domain(mpp.mark(ind).bounding_box(),
                                                mask.domain().sp());
      auto __shift = utils::align_domains(__global_it.domain(), __local_dom);
      cmn_fwditr_t<__dim> __local_it(__local_dom);
      // Note: align domains and define iterator afterwards.

      int __n_total = 0;
      int __n_overlap = 0;
      __point_t __query_pt = __point_t::Zero();
      cmn_for_all(__local_it)
      {
        auto __curr_pos = __local_it+__shift;
        if( mask.hold(__curr_pos) && val_rule(mask[__curr_pos]) )
        {
          __query_pt = utils::cmn_itr_pos<typename Mark::scalr_t>(__local_it);
          if( !mpp.out_of_bound(__query_pt) &&
              mpp.mark(ind).inside_test(__query_pt) )
          { // Consider only pt inside mpp's obs_window.
            ++__n_total;
            if( std::find_if(std::begin(mpp.marks()),
                             std::end(mpp.marks()),
                             [&__query_pt,ind,&mpp,&__lv]
                             (const Mark &__gr)
                             {
                               return __lv(&__gr-&mpp.mark(0))
                                 && (&__gr != &mpp.mark(ind))
                                 && __gr.inside_test(__query_pt);
                             } )
                != std::end(mpp.marks()) ) ++__n_overlap;
          }
        }
      }
      return static_cast<float>(__n_overlap)/__n_total;
    }

    // =====================================================================
    template<typename Mark, typename PT>
    float overlap_ratio_lattice(int ind,  PT &&spacing,
                                const MarkedPointPattern<Mark> &mpp)
    {
      // Pre-filtering out unreachable ones.
      using __scalr_t = typename Mark::scalr_t;
      using __point_t =
        typename traits::specs<decay_t<decltype(mpp)> >::point_t;
      using __slice_t =
        typename traits::specs<decay_t<decltype(mpp)> >::slice_t;

      __slice_t __lv(mpp.n_elem());
      for(auto __l = 0; __l < mpp.n_elem(); ++__l)
      {
        __scalr_t __tmp_rad = mpp.mark(__l).enclosing_radius() +
          mpp.mark(ind).enclosing_radius();
        __point_t __tmp_dist = mpp.mark(__l).centre()-mpp.mark(ind).centre();
        /// TODO: tmp point not necessary.
        __lv(__l) = __tmp_dist.transpose()*__tmp_dist < __tmp_rad*__tmp_rad;
      }

      auto __pair = utils::make_aligned_domain
        ( mpp.mark(ind),
          utils::make_cmn_domain(mpp.bounding_box(),std::forward<PT>(spacing)) );
      cmn_fwditr_t<Mark::dim> __local_it(std::get<1>(__pair));
      // Note: align domains and define iterator afterwards.

      int __n_total = 0;
      int __n_overlap = 0;
      __point_t __query_pt = __point_t::Zero();
      cmn_for_all(__local_it)
      {
        __query_pt = utils::cmn_itr_pos<typename Mark::scalr_t>(__local_it);
        if( !mpp.out_of_bound(__query_pt) &&
            mpp.mark(ind).inside_test(__query_pt) )
        { // Consider only pt inside mpp's obs_window.
          ++__n_total;
          if( std::find_if(std::begin(mpp.marks()),
                           std::end(mpp.marks()),
                           [&__query_pt,ind,&mpp,&__lv]
                           (const Mark &__gr)
                           {
                             return __lv(&__gr-&mpp.mark(0))
                               && (&__gr != &mpp.mark(ind))
                               && __gr.inside_test(__query_pt);
                           } )
              != std::end(mpp.marks()) ) ++__n_overlap;
        }
      }
      return static_cast<float>(__n_overlap)/__n_total;
    }

    // =====================================================================
    template<typename Mark>
    float overlap_ratio_lattice_hard(int ind, float resolution,
                                     const MarkedPointPattern<Mark> &mpp)
    {
      auto __count_total = 0;
      auto __count_overlap = 0;

      auto __n_x = static_cast<int>
        ((mpp.mark(ind).bounding_box()(0,1)-mpp.mark(ind).bounding_box()(0,0))
         /resolution)+1;
      auto __n_y = static_cast<int>
        ((mpp.mark(ind).bounding_box()(1,1)-mpp.mark(ind).bounding_box()(1,0))
         /resolution)+1;
      auto __n_z = static_cast<int>
        ((mpp.mark(ind).bounding_box()(2,1)-mpp.mark(ind).bounding_box()(2,0))
         /resolution)+1;

      // Pre-filtering out unreachable ones.
      using __scalr_t = typename Mark::scalr_t;
      using __slice_t = typename MarkedPointPattern<Mark>::slice_t;
      using __point_t = typename MarkedPointPattern<Mark>::point_t;
      __slice_t __lv(mpp.n_elem());
      for(auto __l = 0; __l < mpp.n_elem(); ++__l)
      {
        __scalr_t __tmp_rad = mpp.mark(__l).enclosing_radius() +
          mpp.mark(ind).enclosing_radius();
        __point_t __tmp_dist = mpp.mark(__l).centre()-mpp.mark(ind).centre();
        __lv(__l) = __tmp_dist.transpose()*__tmp_dist < __tmp_rad*__tmp_rad;
      }

      __point_t __coord = __point_t::Zero();
      __point_t __tmp_pt = __point_t::Zero();
      for(int __i = 0; __i < __n_x; ++__i)
      {
        for(int __j = 0; __j < __n_y; ++__j)
        {
          for(int __k = 0; __k < __n_z; ++__k)
          {
            __coord(0) = static_cast<typename Mark::scalr_t>(__i);
            __coord(1) = static_cast<typename Mark::scalr_t>(__j);
            __coord(2) = static_cast<typename Mark::scalr_t>(__k);
            __tmp_pt = mpp.mark(ind).bounding_box().col(0)+__coord*resolution;

            if( utils::in_bound(__tmp_pt,mpp.bounding_box()) &&
                mpp.mark(ind).inside_test(__tmp_pt) )
            {
              ++__count_total;
              if( std::find_if
                  (std::begin(mpp.marks()),std::end(mpp.marks()),
                   [ind,&__tmp_pt,&__lv,&mpp](const Mark &__gr)
                   {
                     return __lv(&__gr-&mpp.mark(0))&& (&__gr != &mpp.mark(ind))
                       && __gr.inside_test(__tmp_pt); } )
                  != std::end(mpp.marks()) ) ++__count_overlap;
            }
          }
        }
      }
      return static_cast<float>(__count_overlap)/__count_total;
    }

    // ===================================================================
    template<typename E>
    int comp_ncc(const cmn::abstract::Image<E> &field,
                 const mipp_ngbh_type(E) &ngbh)
    {
      int nb_cpnt = 0;
      cmn_fwd_iter_type(E) it(field.domain());
      cmn_for_all(it)
      {
        bool assigned = false;
        // Test hold for all locs in the neighborhood.
        for (int i = 0; i < ngbh.card(); ++i)
          if(field.hold(it+ngbh[i]))
          {
            if( (field[it]==field[it+ngbh[i]]) && !assigned )
              assigned = true;
          }
        if (!assigned) ++nb_cpnt;
      }
      return nb_cpnt;
    }

    // =====================================================================
    template<typename E, typename NumRule, typename DenomRule>
    float property_ratio(const cmn::abstract::Image<E> &field,
                         NumRule num_rule, DenomRule denom_rule)
    {
      long __total = 0;
      long __numerator = 0;
      cmn_iter_type(E) __it(field.domain());
      cmn_for_all(__it)
      {
        if( field.hold(__it.point()) && denom_rule(__it.point()) )
        {
          ++__total;
          if( num_rule(__it.point()) ) ++__numerator;
        }
      }
      return static_cast<float>(__numerator)/__total;
    }

    // =====================================================================
    template<typename E, typename Roi, typename NumRule, typename DenomRule,
             enable_if_any_t<is_stg_shape_v<Roi>(),
                             is_marked_patt_v<Roi>()>* = nullptr>
    float property_ratio(const cmn::abstract::Image<E> &field, Roi &&roi,
                         NumRule num_rule, DenomRule denom_rule)
    {
      using __scalr_t = typename decay_t<Roi>::scalr_t;
      using __point_t = typename decay_t<Roi>::point_t;
      // Note: align domains and define iterator afterwards.
      auto __pair = utils::make_aligned_domain(field.domain(),
                                               roi.bounding_box(),
                                               field.domain().sp());
      cmn_iter_type(E) __local_it(std::get<1>(__pair));
      long __total = 0;
      long __intersect = 0;
      __point_t __query_pt = __point_t::Zero();
      cmn_for_all(__local_it)
      {
        auto __curr_pos = __local_it+std::get<0>(__pair);
        __query_pt = utils::cmn_itr_pos<__scalr_t>(__local_it);
        if( field.hold(__curr_pos) && denom_rule(__curr_pos) &&
            roi.inside_test(__query_pt) )
        {
          ++__total;
          if( num_rule(__curr_pos) ) ++__intersect;
        }
      }
      return static_cast<float>(__intersect)/__total;
    }

    // =====================================================================
    template<typename T, typename E, typename Rule>
    auto field_mass_center(const cmn::abstract::Image<E> &field, Rule pos_rule)
      -> Eigen::Matrix<T,cmn_dim(E),1>
    {
      constexpr int __dim = cmn_dim(E);
      Eigen::Matrix<T,__dim,1> __centre = Eigen::Matrix<T,__dim,1>::Zero();

      long __n_pts = 0;
      cmn_fwditr_t<__dim> __it(field.domain());
      cmn_for_all(__it)
        if( pos_rule(__it.point()) )
        { ++__n_pts; __centre += utils::cmn_itr_pos<T>(__it); }
      __centre /= __n_pts;
      return __centre;
    }

    // =====================================================================
    template<typename T, typename E, typename Roi, typename Rule>
    auto field_mass_center(const cmn::abstract::Image<E> &field, Roi &&roi,
                           Rule pos_rule)
      -> Eigen::Matrix<T,cmn_dim(E),1>
    {
      static_assert(is_stg_shape_v<Roi>() || is_marked_patt_v<Roi>(),
                    "ERROR: A SHAPE OR GEO MARKED PATT IS EXPECTED.");
      constexpr int __dim = cmn_dim(E);
      Eigen::Matrix<T,__dim,1> __centre = Eigen::Matrix<T,__dim,1>::Zero();

      auto __pair = utils::make_aligned_domain(std::forward<Roi>(roi),
                                               field.domain());
      long __n_pts = 0;
      cmn_point_type(E) __curr_pt;
      cmn_fwditr_t<__dim> __it(std::get<1>(__pair));
      Eigen::Matrix<T,__dim,1> __curr_pos = Eigen::Matrix<T,__dim,1>::Zero();
      cmn_for_all(__it)
      {
        __curr_pt = __it+std::get<0>(__pair);
        if( field.hold(__curr_pt) && pos_rule(__curr_pt) )
        {
          __curr_pos = utils::cmn_itr_pos<T>(__it);
          if( roi.inside_test(__curr_pos) )
          { ++__n_pts; __centre += utils::cmn_itr_pos<T>(__it); }
        }
      }
      __centre /= __n_pts;
      return __centre;
    }

    // =====================================================================
    template<typename T, typename E, typename Rule=anything_t>
    auto field_spatial_moments(const cmn::abstract::Image<E> &field,
                               Rule pos_rule)
      -> std::tuple<long int, Eigen::Matrix<T,cmn_dim(E),1>,
                    Eigen::Matrix<T,cmn_dim(E),cmn_dim(E)> >
    {
      constexpr int __dim = cmn_dim(E);

      long __n_pts = 0;
      cmn_fwditr_t<__dim> __it(field.domain());
      Eigen::Matrix<T,__dim,1> __centre = Eigen::Matrix<T,__dim,1>::Zero();
      Eigen::Matrix<T,__dim,__dim> __mnt = Eigen::Matrix<T,__dim,__dim>::Zero();
      Eigen::Matrix<T,__dim,1> __curr_pos = Eigen::Matrix<T,__dim,1>::Zero();
      Eigen::Matrix<T,__dim,1> __delta = Eigen::Matrix<T,__dim,1>::Zero();
      cmn_for_all(__it)
        if( pos_rule(__it.point()) )
        {
          __curr_pos = utils::cmn_itr_pos<T>(__it);
          ++__n_pts; // Online update.
          __delta = __curr_pos-__centre;
          __centre += __delta/__n_pts;
          __mnt += __delta*((__curr_pos-__centre).transpose());
        }
      assert(__n_pts >= 2 && "cov matrix expects at least two elements.");
      __mnt /= (__n_pts-1);
      return std::make_tuple(__n_pts, __centre, __mnt);
    }

    // =====================================================================
    template<typename T, typename E, typename Roi, typename Rule=anything_t>
    auto field_spatial_moments(const cmn::abstract::Image<E> &field,
                               Roi &&roi, Rule pos_rule)
      -> std::tuple<long int, Eigen::Matrix<T,cmn_dim(E),1>,
                    Eigen::Matrix<T,cmn_dim(E),cmn_dim(E)> >
    {
      static_assert(is_stg_shape_v<Roi>() || is_marked_patt_v<Roi>(),
                    "ERROR: A SHAPE OR GEO MARKED PATT IS EXPECTED.");
      constexpr int __dim = cmn_dim(E);
      auto __pair = utils::make_aligned_domain(std::forward<Roi>(roi),
                                               field.domain());
      long __n_pts = 0;
      cmn_point_type(E) __curr_pt;
      cmn_fwditr_t<__dim> __it(std::get<1>(__pair));
      Eigen::Matrix<T,__dim,1> __delta = Eigen::Matrix<T,__dim,1>::Zero();
      Eigen::Matrix<T,__dim,1> __centre = Eigen::Matrix<T,__dim,1>::Zero();
      Eigen::Matrix<T,__dim,1> __curr_pos = Eigen::Matrix<T,__dim,1>::Zero();
      Eigen::Matrix<T,__dim,__dim> __mnt = Eigen::Matrix<T,__dim,__dim>::Zero();
      cmn_for_all(__it)
      {
        __curr_pt = __it+std::get<0>(__pair);
        if( field.hold(__curr_pt) && pos_rule(__curr_pt) )
        {
          __curr_pos = utils::cmn_itr_pos<T>(__it);

          if( roi.inside_test(__curr_pos) )
          {
            ++__n_pts; // Online update.
            __delta = __curr_pos-__centre;
            __centre += __delta/__n_pts;
            __mnt += __delta*((__curr_pos-__centre).transpose());
          }
        }
      }
      assert(__n_pts >= 2 && "cov matrix expects at least two elements.");
      __mnt /= (__n_pts-1);
      return std::make_tuple(__n_pts, __centre, __mnt);
    }

    // =====================================================================
    template<typename T, typename E, typename Rule>
    auto comp_legendre_ellipsoid(const cmn::abstract::Image<E> &field,
                                 Rule pos_rule)
      -> shapes::Ellipsoid<T,cmn_dim(E)>
    {
      return detail::__legendre_ellipsoid_impl
        (field_spatial_moments<T>(field, pos_rule));
    }

    // =====================================================================
    template<typename T, typename E, typename Roi, typename Rule>
    auto comp_legendre_ellipsoid(const cmn::abstract::Image<E> &field,
                                 Roi &&roi, Rule pos_rule)
      -> shapes::Ellipsoid<T,cmn_dim(E)>
    {
      return detail::__legendre_ellipsoid_impl
        (field_spatial_moments<T>(field, std::forward<Roi>(roi), pos_rule));
    }

    namespace detail
    {

      // =====================================================================
      template<typename Tuple> auto __legendre_ellipsoid_impl(Tuple &&mnts)
        -> shapes::Ellipsoid<eigen_val_t<decltype(std::get<1>(mnts))>,
                             eigen_rows_v<decltype(std::get<1>(mnts))>()>
      {
        using __scalr_t = eigen_val_t<decltype(std::get<1>(mnts))>;
        constexpr int __dim = eigen_rows_v<decltype(std::get<1>(mnts))>();

        Eigen::SelfAdjointEigenSolver<Eigen::Matrix<__scalr_t,__dim,__dim> >
          __decomp(std::get<2>(std::forward<Tuple>(mnts))*(__dim+2));

        Eigen::Matrix<__scalr_t,3*__dim-3,1> __ellip_param;
        __ellip_param.template segment<__dim>(0) =
          __decomp.eigenvalues().reverse().array().sqrt().matrix();

        if( __dim == 3 )
        { // Apply right hand rule if __dim == 3.
          Eigen::Matrix<__scalr_t,__dim,__dim> __tmp =
            __decomp.eigenvectors().rowwise().reverse();
          utils::apply_rhr(__tmp);
          // z vec is reversed if not aligned w/ x cross y.
          __ellip_param.template segment<2*__dim-3>(__dim) =
            utils::comp_rot_angles(__tmp);
        } else
        {
          __ellip_param.template segment<2*__dim-3>(__dim) =
            utils::comp_rot_angles(__decomp.eigenvectors().rowwise().reverse());
        }
        /// Two of the vectors (when __dim == 3) might be inverted.
        return shapes::Ellipsoid<__scalr_t,__dim>
          (std::get<1>(std::forward<Tuple>(mnts)),__ellip_param);
      }

      // =====================================================================
      template<typename CastType, typename T, typename Dom, int ...Indx>
      auto make_discrete_field_impl(indx_seq<Indx...>,
                                    std::unique_ptr<T[]> data_ptr,
                                    Dom &&domain)
        -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>
      {
        constexpr int __dim = cmn_domdim_v<Dom>();
        cmn_img_t<CastType,__dim>
          __field((domain[Indx])..., data_ptr.release());
        return __field;
      }

    } //!detail

  } //!discrete
} //!stogeo
