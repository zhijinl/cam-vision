// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// DiscreteOps.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 18 17:13:40 2016 Zhijin Li
// Last update Tue Dec 12 10:20:16 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_DISCRETEOPS_HH
# define STOGEO_DISCRETEOPS_HH

# include <iterator>
# include "Eigen/Eigenvalues"
# include "stogeo/core.hh"
# include "../Utilities/mipp_helpers.hh"
# include "stogeo/point_patterns.hh"
# include "mipp/core/Neighborhood3D.hh"


namespace stogeo
{
  namespace discrete
  {

    ///@{
    /// @brief Create a discrete field from a unique_ptr arr.
    ///
    /// Caller will lose the ownership. Note: USE STD::MOVE on input
    /// unique_ptr to transfer ownership. Border is set 0.
    ///
    /// @note An optimization is performed when the `CastType` and
    /// the data value type `T` is the same. In this case, the input
    /// `unique_ptr` array is **released and assigned directly** as
    /// the internal data array of the created cmn image or volume,
    /// **without copying the data**.
    ///
    /// @warning The optimization described above only accepts
    /// **domain with zero borders**.
    ///
    /// @param data_ptr: the input unique_ptr containing data array.
    /// @param domain: the domain. domain.card() == arr_length.
    /// @return The allocated cmn volume.
    ///
    template<typename CastType, typename T, typename Dom,
             enable_if_all_t<is_cmn_domain_v<Dom>(),
                             is_same_v<CastType,T>()>* = nullptr>
    auto make_discrete_field(std::unique_ptr<T[]> data_ptr, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>;

    template<typename CastType, typename T, typename Dom,
             enable_if_all_t<is_cmn_domain_v<Dom>(),
                             !is_same_v<CastType,T>()>* = nullptr>
    auto make_discrete_field(std::unique_ptr<T[]> data_ptr, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>;
    ///@}

    ///@{
    /// @brief Read an unique_ptr into a cmn Image or Volume.
    ///
    /// @param data_ptr: the input unique_ptr containing data array.
    /// @param im: the cmn Image or Volume object.
    ///
    template<typename T, typename ImType>
    void make_discrete_field(std::unique_ptr<T[]> data_ptr,
                             cmn::abstract::Image<ImType> &im);

    /// @brief Create a discrete field from an stl vector.
    ///
    /// The border is set to 0.
    ///
    /// @param data_vec: the input stl vector containing data array.
    /// @param domain: the domain. domain.card() == arr_length.
    /// @return The allocated cmn volume.
    ///
    template<typename CastType, typename T, typename Dom, typename =
             enable_if_all_t<is_cmn_domain_v<Dom>()> >
    auto make_discrete_field(const std::vector<T> &data_vec, Dom &&domain)
      -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>;

    /// @brief Read an stl vector into a cmn Image or Volume.
    ///
    /// @param data_vec: the input stl vector containing data array.
    /// @param im: the cmn Image or Volume object.
    ///
    template<typename T, typename ImType>
    void make_discrete_field(const std::vector<T> &data_vec,
                             cmn::abstract::Image<ImType> &im);

    /// @brief Create a cmn Image or Volume directly from an input
    /// path to a raw array.
    ///
    /// @param in_path: input path to a raw array.
    /// @param domain_args: variadic arguments to for
    /// `stogeo::utils::make_cmn_domain()`.
    /// @return Create cmn Signal, Image or Volume.
    ///
    template<typename CastType, typename Value, int Dim, typename ...Args>
    auto make_discrete_field(const char *in_path, Args &&...domain_args)
      -> cmn_img_t<CastType,Dim>;

    /// @brief Count in an cmn::ImageND pos satifying a value rule.
    ///
    /// @param field: the input cmn::Image of some dimension.
    /// @param val_rule: the rule on value to validate a count increment.
    /// Should be a functor / lambda taking cmn::Point -> return bool.
    /// @return Total number of elements.
    ///
    template<typename E, typename Rule>
    inline int cmn_count_if(const cmn::abstract::Image<E> &field,
                            Rule val_rule);

    /// @brief Compute overlap ratio of a querry mark in a marked point
    /// pattern.
    ///
    /// This is the cmn version. Allocate memory for discretize region
    /// arround the querry mark. Final overlap ratio is computed thru
    /// iterators.
    ///
    /// @param ind: index of the querry mark.
    /// @param spacing: desired cmn::Spacing for grid discretization.
    /// @param mpp: input marked point pattern.
    /// @return The computed overlap ratio.
    ///
    template<typename Mark, typename PT>
    float overlap_ratio_lattice_cmn(int ind, PT &&spacing,
                                    const MarkedPointPattern<Mark> &mpp);

    /// @brief Compute overlap ratio of a querry mark in a marked point
    /// pattern.
    ///
    /// This is the mask version. Allocate memory for discretize region
    /// arround the querry mark. Final overlap ratio is computed thru
    /// iterators.
    ///
    /// @param ind: index of the querry mark.
    /// @param mask: an input mask of type cmn::ImageND.
    /// @param mpp: input marked point pattern.
    /// @return The computed overlap ratio.
    ///
    template<typename Mark, typename E, typename Rule=is_zero_t>
    float overlap_ratio_lattice(int ind,
                                const cmn::abstract::Image<E> &mask,
                                const MarkedPointPattern<Mark> &mpp,
                                Rule val_rule=is_zero);

    /// @brief Compute overlap ratio of a querry mark in a marked point
    /// pattern.
    ///
    /// This is the hard coded version. Implemented only for Dim 3. Lattice
    /// iterating is done manually. there is no memory allocation. Performs
    /// better than MIPP version.
    ///
    /// @param ind: index of the querry mark.
    /// @param resolution: desired resolution for grid discretization.
    /// @param mpp: input marked point pattern.
    /// @return The computed overlap ration.
    ///
    template<typename Mark>
    float overlap_ratio_lattice_hard(int ind, float resolution,
                                     const MarkedPointPattern<Mark> &mpp);

    /// @brief Comp the number of connected component of a discrete
    /// field.
    ///
    /// Directly adopted from MIPP library.
    ///
    /// @param field: input discrete field (cmn::ImageND).
    /// @param ngbh: connectivity.
    /// @return: # of connected components.
    ///
    template<typename E>
    int comp_ncc(const cmn::abstract::Image<E> &field,
                 const mipp_ngbh_type(E) &ngbh=mipp::mk_halfc6());

    /// @brief Compute ratio of # of sites with diff properties.
    ///
    /// @param field: the input discrete field of type cmn::ImageND.
    /// @param num_rule: a functor / lambda specifying the rule for
    /// counting sites on numerator -> i.e. specifying properties of
    /// sites considered as valid counts on the numerator.
    /// @param denom_rule: a functor / a lambda specifying rule for
    /// counting sites on denominator -> i.e. specifying properties
    /// of sites that are considered as valid counts on denominator.
    /// Defaults to anything / site inside the discrete field.
    /// @return Numerator count / denominator count.
    ///
    template<typename E, typename NumRule, typename DenomRule=anything_t>
    float property_ratio(const cmn::abstract::Image<E> &field,
                         NumRule num_rule, DenomRule denom_rule=anything);

    /// @brief Comp ratio of # of sites inside the ROI & a discrete
    /// field, over the # of total sites inside the  discrete field.
    /// Extra constraint on both numerator & denominator can be added.
    ///
    /// The computation is done using alternating  global and local
    /// iterators. Global iterator's domain is that of the discrete
    /// field; local iterator's domain is that of the ROI.
    ///
    /// @param field: the input discrete filed. (cmn::ImageND).
    /// @param roi: could be a shape or a geometric pattern.
    /// @param num_rule: rules, a functor or a lambda specifying the
    /// necessary properties for a site being considered as a  valid
    /// count on the numerator. It should take a cmn::PointND -> and
    /// perform ops on pos specified by it -> returns bool. Defaults
    /// to anything inside the ROI & discrete field.
    /// @param denom_rule: rules, functor or a lambda specifying the
    /// necessary properties for a site being considered as a  valid
    /// count on the denominator. It should take a cmn::PointND  and
    /// perform ops on pos specified by it -> returns bool. Defaults
    /// to anything inside the discrete field.
    /// @return The numerator counts / denominator counts.
    ///
    template<typename E, typename Roi, typename NumRule,
             typename DenomRule=anything_t,
             enable_if_any_t<is_stg_shape_v<Roi>(),
                             is_marked_patt_v<Roi>()>* = nullptr>
    float property_ratio(const cmn::abstract::Image<E> &field,
                         Roi &&roi, NumRule num_rule,
                         DenomRule denom_rule=anything);

    /// @brief Compute the geographic mass center of a discrete field.
    ///
    /// @param field: input field. cmn::Image of ND.
    /// @param pos_rule: rule for count a site as valid for computation.
    /// Defaults to anything.
    /// @return An Eigen fix sized vector containing the mass center.
    ///
    template<typename T, typename E, typename Rule=anything_t>
    auto field_mass_center(const cmn::abstract::Image<E> &field,
                           Rule pos_rule=anything)
      -> Eigen::Matrix<T,cmn_dim(E),1>;

    /// ROI version of the previous.
    template<typename T, typename E, typename Roi, typename Rule=anything_t>
    auto field_mass_center(const cmn::abstract::Image<E> &field,
                           Roi &&roi, Rule pos_rule=anything)
      -> Eigen::Matrix<T,cmn_dim(E),1>;

    /// @brief Compute the first and second spatial moment of the field
    /// sites.
    ///
    /// First moment is the center of the mass of the field. The second
    /// moment is the covariance matrix of field sites, centered at the
    /// mass center and normalized by the field volume.
    ///
    /// @param field: input field. cmn::Image of ND.
    /// @param pos_rule: rule for count a site as valid for computation.
    /// Defaults to anything.
    /// @return A tuple of: 1) number of valid sites; 2) the first moment
    /// as an Eigen Dim x 1 vec. 3) the second moment as Eigen Dim x Dim.
    ///
    template<typename T, typename E, typename Rule=anything_t>
    auto field_spatial_moments(const cmn::abstract::Image<E> &field,
                               Rule pos_rule=anything)
      -> std::tuple<long int, Eigen::Matrix<T,cmn_dim(E),1>,
                    Eigen::Matrix<T,cmn_dim(E),cmn_dim(E)> >;

    /// ROI version of the previous.
    template<typename T, typename E, typename Roi, typename Rule=anything_t>
    auto field_spatial_moments(const cmn::abstract::Image<E> &field,
                               Roi &&, Rule pos_rule=anything)
      -> std::tuple<long int, Eigen::Matrix<T,cmn_dim(E),1>,
                    Eigen::Matrix<T,cmn_dim(E),cmn_dim(E)> >;

    /// Compute the Legendre ellipsoid of a discrete field.
    ///
    /// Legendre ellipsoid of a discrete field is based on second order
    /// centered & normalized moment matrix of the field, multiplied by
    /// a factor (Dim+2). The Legendre ellipsoid is the Eigen decomp of
    /// this matrix: axes dirs are eigenvectors, axes lengths are invert
    /// of eigenvalues.
    ///
    /// @param field: input field. cmn::Image of ND.
    /// @param pos_rule: rule for count a site as valid for computation.
    /// Defaults to anything.
    /// @return The computed legendre ellipsoid.
    ///
    template<typename T, typename E, typename Rule=anything_t>
    auto comp_legendre_ellipsoid(const cmn::abstract::Image<E> &field,
                                 Rule pos_rule=anything)
      -> shapes::Ellipsoid<T,cmn_dim(E)>;

    /// Compute the Legendre ellipsoid of a discrete field. ROI version.
    ///
    /// Legendre ellipsoid of a discrete field is based on second order
    /// centered & normalized moment matrix of the field, multiplied by
    /// a factor (Dim+2). The Legendre ellipsoid is the Eigen decomp of
    /// this matrix: axes dirs are eigenvectors, axes lengths are invert
    /// of eigenvalues.
    /// @param field: input field. cmn::Image of ND.
    /// @param roi: a stogeo::shape indicating the ROI where computation
    /// sites are constrained into.
    /// @param pos_rule: rule for count a site (inside the ROI) as valid
    /// for computation. Defaults to anything.
    /// @return The computed legendre ellipsoid.
    ///
    template<typename T, typename E, typename Roi, typename Rule=anything_t>
    auto comp_legendre_ellipsoid(const cmn::abstract::Image<E> &field,
                                 Roi &&roi, Rule pos_rule=anything)
      -> shapes::Ellipsoid<T,cmn_dim(E)>;

    namespace detail
    {
      /// @brief Implementation of Legendre ellipsoid computation.
      ///
      /// @param moments: the tuple containing n_sites, mass_center and 2nd
      /// order moment matrix.
      /// @return The compute Ellipsoid of approriate dimension.
      ///
      template<typename Tuple> auto __legendre_ellipsoid_impl(Tuple &&mnts)
        -> shapes::Ellipsoid<eigen_val_t<decltype(std::get<1>(mnts))>,
                             eigen_rows_v<decltype(std::get<1>(mnts))>()>;

      /// @brief Implementation of `make_discrete_field`.
      ///
      /// @param seq: an input integer sequence.
      /// @param data_ptr: the `std::unique_ptr` of input data.
      /// @param dom: the input domain.
      /// @return The created image / volume.
      ///
      template<typename CastType, typename T, typename Dom, int ...Indx>
      auto make_discrete_field_impl(indx_seq<Indx...> seq,
                                    std::unique_ptr<T[]> data_ptr,
                                    Dom &&domain)
        -> cmn_img_t<CastType,cmn_domdim_v<Dom>()>;

      /// @brief Implementation of `make_discrete_field`.
      ///
      /// @param seq: an input integer sequence.
      /// @param data_ptr: the `std::unique_ptr` of input data.
      /// @param im: the input / output image.
      ///
      template<typename T, typename ImType, int ...Indx>
      void make_discrete_field_impl(indx_seq<Indx...>,
                                    std::unique_ptr<T[]> data_ptr,
                                    cmn::abstract::Image<ImType> &im);
    }

  } //!discrete
} //!stogeo


# include "DiscreteOps.hxx"

#endif //!STOGEO_DISCRETEOPS_HH
