// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Lattice.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 17 09:06:48 2016 Zhijin Li
// Last update Sat Sep  9 18:55:17 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_LATTICE_HH
# define STOGEO_LATTICE_HH

# include "stogeo/utilities.hh"


namespace stogeo
{
  namespace discrete
  {

    template<typename Scalar, int Dim> class Lattice
    {
    public:

      using exact_t = Lattice<Scalar,Dim>;
      using bound_t = Eigen::Matrix<Scalar,Dim,2>;
      using count_t = point_dispatch_t<int,Dim>;
      using locat_t = point_dispatch_t<Scalar,Dim>;

      /// @brief Default constructor.
      Lattice() = default;

      /// @brief Construct a lattice system. With bounding box & floating
      /// point step sizes.
      ///
      /// @param bound: the input bounding box. An Eigen Dim x 2 matrix, with
      /// 1st column the lower-bound and 2nd column upper-bound of the system.
      /// @param steps: size of the step in each dimensional direction when
      /// doing lattice traversal. When Dim == 1, it is a scalar. When Dim
      /// >= 2, it is an Eigen Dim x 1 point.
      ///
      template<typename Bound, typename Steps,
               enable_if_t<is_floating_point_v
                           <scalar_dispatch_t<Steps> >()>* = nullptr>
      Lattice(Bound &&bound, Steps &&steps):
        _bound_box(std::forward<Bound>(bound)),
        _step_size(std::forward<Steps>(steps)),
        _side_size(utils::comp_bound_discrete_size(_bound_box,_step_size))
      {};

      ///@{
      /// @brief Construct a lattice system. With bounding box & floating
      /// point step sizes.
      ///
      /// @param bound: the input bounding box. An Eigen Dim x 2 matrix, with
      /// 1st column the lower-bound and 2nd column upper-bound of the system.
      /// @param sizes: integral size of the bounding box. When Dim == 1, it
      /// is an integer. When Dim >= 2, it is an Eigen Dim x 1 int point.
      ///
      template<typename Bound, typename Size,
               enable_if_all_t<Dim==1, is_integral_v<Size>()>* = nullptr>
      Lattice(Bound &&bound, Size size):
        _bound_box( std::forward<Bound>(bound) ),
        _step_size( (_bound_box(1)-_bound_box(0))/(size-1) ),
        _side_size( size ) {};

      template<typename Bound, typename Sizes,
               enable_if_all_t<Dim!=1, is_integral_v
                               <scalar_dispatch_t<Sizes> >()>* = nullptr>
      Lattice(Bound &&bound, Sizes &&sizes):
        _bound_box( std::forward<Bound>(bound) ),
        _step_size( (_bound_box.col(1)-_bound_box.col(0))/
                    ((sizes-1).template cast<Scalar>()) ),
        _side_size( std::forward<Sizes>(sizes) ) {};
      ///@}

      /// @brief Return const ref to the current traversal point position.
      ///
      /// @return The position (in physical length unit) of the traversal pt.
      ///
      const point_dispatch_t<Scalar,Dim>& pos() const
      { return _currn_pos; }

      ///@{
      /// @brief Get cardinality of the lattice system: i.e. number of
      /// location counts.
      ///
      /// @return The cardinality.
      ///
      template<int __dummy=Dim>
      enable_if_t<__dummy==1,int> card() const
      { return _side_size; }

      template<int __dummy=Dim>
      enable_if_t<__dummy!=1,int> card() const
      { return _side_size.prod(); }
      ///@}

      ///@{
      /// @brief Get the elementary volume of the lattice system: i.e.
      /// volume of each small lattice rectangle grid.
      ///
      /// @return The elementary volume.
      ///
      template<int __dummy=Dim>
      enable_if_t<__dummy==1,Scalar> elem_volume() const
      { return _step_size; }

      template<int __dummy=Dim>
      enable_if_t<__dummy!=1,Scalar> elem_volume() const
      { return _step_size.prod(); }
      ///@}

      /// @brief Const access the step-sizes of the lattice system.
      ///
      /// @return Const reference to the step size vec.
      ///
      const locat_t& step_size() const { return _step_size; }

      /// @brief Const access the discrete-sizes of the lattice system.
      ///
      /// @return Const reference to the side counts.
      ///
      const locat_t& discrete_size() const { return _side_size; }

      /// @brief Const access the bounding box of the lattice system.
      ///
      /// @return Const reference to the bounding box.
      ///
      const bound_t& bounding_box() const { return _bound_box; }

      /// @brief Set the step-sizes of the lattice system.
      ///
      /// @note This is the proper way to alter the step-size, since it will
      /// internally re-evaluate the integral side counts and reset the curr
      /// traversal position to the lower-bound of the lattice system.
      ///
      /// @param steps: the input new step-sizes.
      ///
      template<typename Steps> void set_step_size(Steps &&steps);

      /// @brief Set the bounding box of the lattice system.
      ///
      /// @note This is the proper way to alter the bounding box, since it will
      /// internally re-evaluate the integral side counts and reset the curr
      /// traversal position to the lower-bound of the lattice system.
      ///
      /// @param bound: the input new bounding_box.
      ///
      template<typename Bound> void set_bound(Bound &&bound);

      /// @brief Return const ref to the current traversal point coordinates.
      ///
      /// @return The coordinates (in integer) of the traversal pt.
      ///
      // const point_dispatch_t<Scalar,Dim>& coords() const
      // { return _curr_coords; }

      /// @brief Traversal all locations inside the lattice system. Perform
      /// operation specified by the functional handler at each traversal
      /// position.
      ///
      /// @note The unity of `locat_t` is the length unit. If integer behavor
      /// is desired, make a `Lattice` of `int`.
      ///
      /// @param handler: the input functional handler, could be a lambda or a
      /// functor. It is recommanded to write generic functor / lambda (if c++
      /// 14 is available), otherwise the input of functor should be const ref
      /// to locat_t.
      ///
      template<typename Func>
      void traverse(Func handler) const { __traverse<Dim,Func>(handler); };

      /// @brief Produce a discrete field using current bounding and setp size
      /// and a specific handler used to generate value for each lattice site.
      ///
      /// @param handler: the input functional handler, could be a lambda or a
      /// functor. It is recommanded to write generic functor / lambda (if c++
      /// 14 is available), otherwise the input of functor should be const ref
      /// to locat_t.
      /// @return The generate discrete field with dimension `Dim`.
      ///
      template<typename ValueType, typename Func>
      cmn_img_t<ValueType,Dim> yield(Func handler) const;

    private:

      /// @brief This implements traversal for any loop > 1 case using
      /// recursion.
      ///
      /// This function is for internal usage. This function handles Dim > 1.
      /// @param handler: the input functional handler.
      ///
      template<int Loop, typename Func,
               enable_if_all_t<Loop!=1,Dim!=1>* = nullptr>
      void __traverse(Func handler) const;

      /// @brief This specialize recursive traversal for the first loop.
      ///
      /// This function is for internal usage. This function handles Dim > 1.
      /// @param handler: the input functional handler.
      ///
      template<int Loop, typename Func,
               enable_if_all_t<Loop==1,Dim!=1>* = nullptr>
      void __traverse(Func handler) const;

      /// @brief This specialize the traversal for Dim == 1.
      ///
      /// This function is for internal usage.
      /// @param handler: the input functional handler.
      ///
      template<int Loop, typename Func,
               enable_if_all_t<Loop==1,Dim==1>* = nullptr>
      void __traverse(Func handler) const;

      bound_t         _bound_box; //!< Physical boudning box in length units.
      locat_t         _step_size; //!< Step size of each trav step in all dir.
      count_t         _side_size; //!< Discrete counts of the lattice system.
      mutable locat_t _currn_pos; //!< Pos in length units of current traversal.

    };

  }
}


# include "Lattice.hxx"
#endif
