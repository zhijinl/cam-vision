// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Lattice.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 17 23:05:41 2016 Zhijin Li
// Last update Sat Sep  9 19:08:54 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace discrete
  {

    // =====================================================================
    template<typename Scalar, int Dim> template<typename Steps>
    void Lattice<Scalar,Dim>::set_step_size(Steps &&steps)
    {
      _step_size = std::forward<Steps>(steps);
      _currn_pos = _bound_box.col(0);
      utils::comp_bound_discrete_size(_bound_box, _step_size);
    }

    // =====================================================================
    template<typename Scalar, int Dim> template<typename Bound>
    void Lattice<Scalar,Dim>::set_bound(Bound &&bound)
    {
      _bound_box = std::forward<Bound>(bound);
      _currn_pos = _bound_box.col(0);
      utils::comp_bound_discrete_size(_bound_box, _step_size);
    }

    // =====================================================================
    template<typename Scalar, int Dim>
    template<typename ValueType, typename Func>
    cmn_img_t<ValueType,Dim> Lattice<Scalar,Dim>::yield(Func handler) const
    {
      cmn_img_t<ValueType,Dim> __field
        (utils::make_cmn_domain(_bound_box, _step_size));
      cmn_fwditr_t<Dim> __it(__field.domain());

      cmn_for_all(__it)
        __field[__it] = handler(utils::cmn_itr_pos<Scalar>(__it));
      return __field;
    }

    // =====================================================================
    template<typename Scalar, int Dim>
    template<int Loop, typename Func, enable_if_all_t<Loop!=1,Dim!=1>*>
    void Lattice<Scalar,Dim>::__traverse(Func handler) const
    {
      /// TODO: parallelize me!
      for(int __n = 0; __n < _side_size(Loop-1); ++__n)
      {
        _currn_pos(Loop-1) = _bound_box(Loop-1,0)+__n*_step_size(Loop-1);
        __traverse<Loop-1,Func>(handler);
      }
    }

    // =====================================================================
    template<typename Scalar, int Dim>
    template<int Loop, typename Func, enable_if_all_t<Loop==1,Dim!=1>*>
    void Lattice<Scalar,Dim>::__traverse(Func handler) const
    {
      for(int __n = 0; __n < _side_size(0); ++__n)
      {
        _currn_pos(0) = _bound_box(0,0)+__n*_step_size(0);
        handler(_currn_pos);
      }
    }

    // =====================================================================
    template<typename Scalar, int Dim>
    template<int Loop, typename Func, enable_if_all_t<Loop==1,Dim==1>*>
    void Lattice<Scalar,Dim>::__traverse(Func handler) const
    {
      for(int __n = 0; __n < _side_size; ++__n)
      {
        _currn_pos = _bound_box(0)+__n*_step_size;
        handler(_currn_pos);
      }
    }

  } //discrete
} //!stogeo
