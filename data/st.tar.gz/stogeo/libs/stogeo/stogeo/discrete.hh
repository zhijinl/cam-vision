// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// discrete.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 18 18:08:20 2016 Zhijin Li
// Last update Fri Aug  5 14:26:14 2016 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_DISCRETE_HH
# define STOGEO_DISCRETE_HH

# include "core.hh"
# include "Discrete/DiscreteOps.hh"

#endif //!STOGEO_DISCRETE_HH
