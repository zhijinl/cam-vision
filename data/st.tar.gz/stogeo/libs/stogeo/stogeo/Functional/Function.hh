// ---------------------------------------------------------------------------
// Copyright (c) 2018 by General Electric Medical Systems
//
// Function.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri Aug 31 17:19:35 2018 Zhijin Li
// Last update Fri Aug 31 17:56:55 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_FUNCTION_HH
# define STOGEO_FUNCTION_HH


namespace stogeo
{
  namespace detail
  {

    /// @brief Class for generic functions.
    ///
    /// @param Func: template parameter indicating type
    /// of the input function object.
    ///
    template<typename Func> class __function
    {
    public:

      ///@{
      /// @brief Default contructor, copy/move constructor
      /// and assignment operators.
      ///
      __function() = default;

      ___function(const __function &lhs) = default;

      ___function(__function &&lhs) = default;

      __function& operator=(const __function &lhs) = default;

      __function& operator=(__function &&lhs) = default;
      ///@}

      /// @brief Constructor.
      ///
      /// @param func: the input functional object.
      ///
      template<typename Input>
      explict __function(Input &&func):
        _func( std::forward<Input>(func) ) {};

      /// @brief
      template<typename ...Args>
      auto operator(Args &&...args)() -> decltype(_func())
      { return _func( std::forward<Args>(args)... )}

    private:
      Func _func{[](){}};
    };

  }

  namespace utils
  {

    template<typename Func>
    auto make_function(Func &&func)
      -> stogeo::detail::__function<std::decay_t<Func> >
    {
      return stogeo::detail::__function<std::decay_t<Func> >
        (std::forward<Func>(func));
    }

    template<typename Func, typename ...Args>
    auto apply(Func &&func, Args &&...args) -> decltype(func())
    {
      return func( std::forward<Args>(args)... );
    }

  }
}


# include "Function.hxx"
#endif
