// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MarkedPointPattern.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jan 13 17:01:33 2016 Zhijin Li
// Last update Wed Oct 11 16:19:22 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_MARKEDPOINTPATTERN_HH
# define STOGEO_MARKEDPOINTPATTERN_HH

# include "patternsbase.hh"
# include "SimplePointPattern.hh"
# include "../PointProcesses/Intensity.hh"
# include "../PointProcesses/PoissonPP.hh"


namespace stogeo
{
  // Fwd decl.
  template<typename PScalr, int PDim=0, typename MScalr=void, int MDim=0>
  class MarkedPointPattern;

  // Fwd decl.
  namespace pps
  { template<typename T, int, typename Intensity=T> class PoissonPP; }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::MarkedPointPattern<Mark>`
    /// class: the **marked point pattern with geometric marks**.
    ///
    template<typename Mark> struct specs<MarkedPointPattern<Mark> >
    {
      static constexpr int dim          =          traits::specs<Mark>::dim;
      static constexpr int mark_dim     =     traits::specs<Mark>::n_params;
      static constexpr stg_ids stg_id   =             stg_ids::STOGEO_MKPAT;
      typedef typename Mark::scalr_t                                scalr_t;
      typedef Mark                                                  pmark_t;
      typedef variant<shapes::Box<scalr_t,Mark::dim>,
                             shapes::Sphere<scalr_t,Mark::dim>,
                             shapes::Ellipsoid<scalr_t,Mark::dim>,
                             shapes::Rectangle<scalr_t,Mark::dim> > obswd_t;
      typedef Eigen::Matrix<scalr_t,Mark::dim,1>                    point_t;
      typedef Eigen::Matrix<scalr_t,Eigen::Dynamic,1>               vectr_t;
      typedef Eigen::Matrix<scalr_t,Mark::dim,Eigen::Dynamic>       matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>                  slice_t;
      typedef Eigen::Matrix<scalr_t,Eigen::Dynamic,Eigen::Dynamic>  dymmt_t;
      typedef Eigen::Matrix<scalr_t,Mark::dim,2>                    bound_t;
      typedef typename specs<pmark_t>::vpack_t                      vpack_t;
      typedef typename specs<pmark_t>::mpack_t                      mpack_t;
      typedef typename specs<pmark_t>::parmt_t                      parmt_t;
      typedef std::vector<pmark_t,alloc_dispatch_t<pmark_t> >       mkset_t;
      typedef alloc_dispatch_t<pmark_t>                             alloc_t;
    };

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::MarkedPointPattern`
    /// class: the **marked point pattern with arithmetic marks**.
    ///
    template<typename PScalr, int PDim, typename MScalr, int MDim>
    struct specs<MarkedPointPattern<PScalr,PDim,MScalr,MDim> >
    {
      static constexpr int dim      =                                  PDim;
      static constexpr int mark_dim =                                  MDim;
      static const stg_ids stg_id   =                 stg_ids::STOGEO_MKPAT;
      typedef PScalr                                                scalr_t;
      typedef MScalr                                                msclr_t;
      typedef variant<shapes::Box<scalr_t,PDim>,
                             shapes::Sphere<scalr_t,PDim>,
                             shapes::Ellipsoid<scalr_t,PDim>,
                             shapes::Rectangle<scalr_t,PDim> >      obswd_t;
      typedef Eigen::Matrix<scalr_t,PDim,1>                         point_t;
      typedef pmark_dispatch_t<MScalr,MDim>                         pmark_t;
      typedef Eigen::Matrix<scalr_t,Eigen::Dynamic,1>               vectr_t;
      typedef Eigen::Matrix<msclr_t,Eigen::Dynamic,1>               mkvec_t;
      typedef Eigen::Matrix<scalr_t,PDim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>                  slice_t;
      typedef Eigen::Matrix<scalr_t,Eigen::Dynamic,Eigen::Dynamic>  dymmt_t;
      typedef Eigen::Matrix<scalr_t,PDim,2>                         bound_t;
      typedef Eigen::Matrix<msclr_t,MDim,Eigen::Dynamic>            mkset_t;
    };

  }


  /// @ingroup group_rpatt
  ///
  /// @brief Random point patterns with geometric Marks.
  ///
  /// A **geometric marked point pattern** contains `stogeo::shapes` elements
  /// randomly placed inside an observation window.
  ///
  /// @warning
  /// 1. The shapes are internally stored inside an STL `vector`, so the center
  ///    points of the shapes are **not stored contiguously**. Therefore calling
  ///    the `stogeo::MarkedPointPattern<Mark>::pts()` will **create a temporary,
  ///    instead of returning a reference**.
  /// 2. Hwen used with the STL containers, Eigen's fix sized matrices &&
  ///    vectors necessitate an **extra `allocator_type` argument**. This will
  ///    affect the constructor taking a STL `vector` of shapes, since extra
  ///    `allocator_type` also need to be passed. **Each stogeo::shapes class
  ///    (and any other classes when it is necessary) offers a type alias for
  ///    this purpose, called: `alloc_t`.
  ///
  /// @param Mark: the type of `stogeo::shapes` used as the marks.
  ///
  template<typename Mark> class MarkedPointPattern<Mark>
    : public abstract::patternsbase<MarkedPointPattern<Mark> >
  {
    static_assert(is_stg_shape_v<Mark>(),
                  "ERROR: THIS SPECIALIZATION EXPECTS GEOMETRIC MARKS.");
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    using exact_t                 =        MarkedPointPattern<Mark>;
    using specs_t                 =          traits::specs<exact_t>;
    using scalr_t                 =       typename specs_t::scalr_t;
    using point_t                 =       typename specs_t::point_t;
    using vectr_t                 =       typename specs_t::vectr_t;
    using matrx_t                 =       typename specs_t::matrx_t;
    using slice_t                 =       typename specs_t::slice_t;
    using obswd_t                 =       typename specs_t::obswd_t;
    using bound_t                 =       typename specs_t::bound_t;
    using pmark_t                 =       typename specs_t::pmark_t;
    using vpack_t                 =       typename specs_t::vpack_t;
    using mpack_t                 =       typename specs_t::mpack_t;
    using parmt_t                 =       typename specs_t::parmt_t;
    using alloc_t                 =       typename specs_t::alloc_t;
    using mkset_t                 =       typename specs_t::mkset_t;

    using parnt_t                 = abstract::patternsbase<exact_t>;
    friend                                                  parnt_t;

    static constexpr int dim      =        traits::specs<Mark>::dim;
    static constexpr int mark_dim =   traits::specs<Mark>::n_params;

    //------- Inherited interfaces.

    using parnt_t::                                          window;
    using parnt_t::                                          n_elem;
    using parnt_t::                                          centre;
    using parnt_t::                                          volume;
    using parnt_t::                                       translate;
    using parnt_t::                                    bounding_box;
    using parnt_t::                                    out_of_bound;

    using parnt_t::                                          append;
    using parnt_t::                                          remove;
    using parnt_t::                                         slicing;
    using parnt_t::                                        thinning;
    using parnt_t::                                       constrain;
    using parnt_t::                                      set_window;

    //------- Ctors.

    /// @brief Constructor.
    ///
    /// Allocates memory for n_elem number of elements.
    ///
    /// @warning even when input n_elem is non-zero, after the construction
    /// n_elem() always returns zero. Internally a reserve is called on std::
    /// vector, it preallocates memeory for n_elem elements, but it does not
    /// alter the real size.
    /// @param n_elem: number of element to pre-alloc memory for. Default to 0.
    ///
    MarkedPointPattern(int n_elem=0) { _pmarks_pac.reserve(n_elem); };

    /// @brief Constructor.
    ///
    /// Init w/ observation window and pre-allocate number n_elem of elements.
    /// The n_elem is defaulted to 0.
    ///
    /// @warning even when input n_elem is non-zero, after the construction
    /// n_elem() always returns zero. Internally a reserve is called on std::
    /// vector, it preallocates memeory for n_elem elements, but it does not
    /// alter the real size.
    /// @param obs_window: the observation window of the marked point pattern.
    /// Should be any valid geometric shape.
    /// @param n_elem: number of element to pre-alloc mem for. Default to 0.
    ///
    template<typename WT, enable_if_t<is_stg_shape_v<WT>()>* = nullptr>
    MarkedPointPattern(WT &&obs_window, int n_elem=0):
      abstract::patternsbase<exact_t>(std::forward<WT>(obs_window))
    { _pmarks_pac.reserve(n_elem); };

    /// @brief Constructor.
    ///
    /// Init w/ observation window and pmarks' matrix representation. The mat
    /// reprez is a matrix of size M x N elems, where M is size of a mark's
    /// param vec (including centre) and N is the numb of marks.
    ///
    /// @param obs_widnow: the observation window of the marked point pattern.
    /// Should be any valid geometric shape.
    /// @param mpack: the matrix representation of all marks' params.
    ///
    template<typename WT, typename MPT,
             enable_if_all_t<is_eigen_v<MPT>(),is_stg_shape_v<WT>()>* = nullptr>
    MarkedPointPattern(WT &&obs_window, MPT &&mpack);

    /// @brief Constructor.
    ///
    /// Init by a std::vector of marks.
    /// @warning this should be an obscure usage: STL vector should be given
    /// Eigen's aligned_allocator, due to alignment issue of Eigen with STL.
    ///
    /// @param obs_widnow: the observation window of the marked point pattern.
    /// Should be any valid geometric shape.
    /// @param marks_vec: an std::vector<pmark_t,alloc_t>. The alloc_t can be
    /// retrieved from class typedef.
    ///
    template<typename WT, typename GVT,
             enable_if_all_t<is_stl_vector_of_v<GVT,pmark_t,alloc_t>(),
                             is_stg_shape_v<WT>()>* = nullptr>
    MarkedPointPattern(WT &&obs_window, GVT &&marks_vec);

    /// @brief Default ctor.
    MarkedPointPattern() = default;

    /// @brief Default copy ctors.
    MarkedPointPattern(const exact_t &rhs) = default;

    /// @brief Default move ctor.
    MarkedPointPattern(exact_t &&rhs) = default;

    /// @brief Default copy assignment operator.
    MarkedPointPattern& operator=(const exact_t &rhs) = default;

    /// @brief Default move assignment operator.
    MarkedPointPattern& operator=(exact_t &&rhs) = default;

    //------- Class specific funcs.

    /// @brief Return marks centers as a matrix.
    ///
    /// @warning It constructs a new matrix. The inconsistency is because
    /// for geometric marked point pattern, the marks (shapes)
    /// are stored inside an std::vector.
    ///
    /// @return An Eigen matrix of dim x n_elem.
    ///
    matrx_t pts() const;

    /// @brief Non-const access stl::vector of all marks.
    ///
    /// @warning due to Eigen's alignment issue, the stl vector does
    /// not use default allocator -> it uses Eigen's aligned allocator
    ///
    /// @return Reference to std::vector<pmark_t,alloc_t>.
    ///
    mkset_t& marks() { return _pmarks_pac; };

    /// @brief Const accessor.
    ///
    /// @warning that due to Eigen's alignment issue, the stl vector does
    /// not use default allocator -> it uses Eigen's aligned allocator
    ///
    /// @return Const reference to std::vector<pmark_t,alloc_t>.
    ///
    const mkset_t& marks() const { return _pmarks_pac; };

    /// @brief Return a vector representation of shape of some index.
    ///
    /// @param indx: the input index.
    /// @return An Eigen fixed sized vector of proper dimension containing
    /// the center corrdinates and parameters of the shape of index `indx`.
    ///
    vpack_t vpack(int indx) const { return _pmarks_pac[indx].vpack(); };

    /// @brief Return all mark (shape) params as a matrix (i.e. center coords
    /// are excluded).
    ///
    /// @warning It constructs a new matrix. The inconsistency is due to the
    /// fact that for geometric marked point pattern. The elements (shapes)
    /// are stored inside an std::vector.
    /// @return An Eigen matrix of size shape::n_params x Dynamic containing
    /// all shape parameters.
    ///
    parmt_t mark_params() const;

    /// @brief Access point of querry indx.
    ///
    /// @param ind: the input query index.
    /// @return Reference to point / shape centre of index ind.
    ///
    point_t& pt(int ind) { return _pmarks_pac[ind].centre(); }

    /// @brief Const access point of querry indx.
    ///
    /// @param ind: the input query index.
    /// @return Const reference to point / shape centre of index ind.
    ///
    const point_t& pt(int ind) const { return _pmarks_pac[ind].centre(); }

    /// @brief Access mark of querry indx.
    ///
    /// @param ind: the input query index.
    /// @return Reference to mark of index ind.
    ///
    pmark_t& mark(int ind) { return _pmarks_pac[ind]; };

    /// @brief Const accessor of mark of query index.
    ///
    /// @param ind: the input query index.
    /// @return Const reference to mark of index ind.
    ///
    const pmark_t& mark(int ind) const { return _pmarks_pac[ind]; };

    /// @brief Pack all marks into a matrix representation.
    ///
    /// @return An Eigen matrix of Some x n_elem representing
    /// all marks' parameters in a whole.
    ///
    mpack_t mpack() const;

    /// @brief Test if a pt falls inside the pattern.
    ///
    /// @param pt: input point aka. Eigen dim x 1 vec.
    /// @return `true` if inside, otherwise `false`.
    ///
    template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                          eigen_rows_v<PT>()==Mark::dim,
                                          eigen_cols_v<PT>()==1>* = nullptr>
    bool inside_test(PT &&pt) const;

    /// @brief Inside test for a matrix of points.
    ///
    /// @param mat: input matrix. Eigen dim x N (Dynamic).
    /// @return A slice vector: Eigen<bool,Dynamic,1> lv. Each elem
    /// in lv represents if point of that index falls inside.
    ///
    template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                          eigen_rows_v<MT>()==Mark::dim,
                                          eigen_cols_v<MT>()!=1>*
             = nullptr>
    slice_t inside_test(MT &&mat) const;

    /// @brief Inside test for a matrix of points. Another API.
    ///
    /// @param mat: input matrix. Eigen dim x N (Dynamic).
    /// @param slice: a slice vector: Eigen<bool,N,1> lv. Each elem
    /// in lv represents if point of that index falls inside.
    ///
    template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                          eigen_rows_v<MT>()==Mark::dim>*
             = nullptr>
    void inside_test(MT &&mat, slice_t &slice) const;

    /// @brief Discretization under given reolution.
    ///
    /// Produces an Image of dimension dim. Discretization is done inside
    /// pattn's obser_window: ImSize = WindwSize/resolution. Elems inside
    /// the are assigned in_val, ouside assigned out_val. Needs explicit
    /// template argument if neither in_val nor out_val is specified.
    ///
    /// @param resolution: desired resolution: Eigen dim x 1 vec.
    /// @param in_val: value assigned to elems inside the pattern
    /// @param out_val: value assigned to elems outside the pattern.
    /// @return A cmn::Image of dimension dim.
    ///
    template<typename VT, typename PT,
             typename = enable_if_t<is_eigen_v<PT>()> >
    cmn_img_t<VT,Mark::dim> discrete(PT &&resolution,
                                     VT in_val=0,
                                     VT out_val=1) const;

    /// @brief Discretization under given reolution. Spacing version
    ///
    /// Produces an Image of dimension dim. Discretization is done inside
    /// an input domain. Elems inside the pattn filled with in_val ouside
    /// with out_val. Needs explicit template argument, if neither in_val
    /// nor out_val is specified.
    ///
    /// @param dom: input domain where the discrete field lies in.
    /// @param in_val: value assigned to elems inside the pattern
    /// @param out_val: value assigned to elems outside the pattern.
    /// @return A cmn::Image of dimension dim.
    ///
    template<typename VT>
    cmn_img_t<VT,Mark::dim> discrete(const cmn_domain_t<Mark::dim> &dom,
                                     VT in_val=0, VT out_val=1) const;

    /// @brief Compute overlap ration of query mark.
    ///
    /// This version computes the overlap ratio of an element with other
    /// elements via uniform random sampling. It count the ratio of number
    /// of samples falling inside the intersections and the number of those
    /// falling inside only curr shape. It is faster than lattice search,
    /// but no exact result is garanteed (depends on sample intensity).
    ///
    /// @param ind: the input query index of the mark, whose overlap ratio
    /// is to be calculated.
    /// @param intensity: controls avg number of sampling points in unit
    /// volume.
    /// @return The computed overlap ratio.
    ///
    float overlap_ratio_mcmc(int ind, float intensity) const;

    /// @brief Compute overlap ration of query mark.
    ///
    /// This version computes the overlap ratio of an element with other
    /// elements via lattice searching. It discretizes the current shape and
    /// count the ratio of number of discrete positions falling inside the
    /// intersections and the number of those falling inside only curr shape.
    /// It is slower than MCMC method, but the result is more accurate.
    ///
    /// @param ind: the input query index of the mark, whose overlap ratio
    /// is to be calculated.
    /// @param resolution: desired resolution controlling grid spacing. An
    /// Eigen point (vector of dim x 1).
    ///
    template<typename PT> float overlap_ratio_lattice(int ind,
                                                      PT &&resolution) const;

    /// @brief Read from a text file.
    ///
    /// @param data_path: the string data_path.
    /// @param enable_log: print on console info if enabled. Defaults to true.
    /// @return `*this`.
    ///
    exact_t& read_from(const std::string &data_path, bool enable_log=true);

    /// @brief Write to a text file.
    ///
    /// @param data_path: string, path for writing.
    /// @param precision: number of digits, defaults to 18.
    /// @param enable_log: print on console info if enabled. Defaults to true.
    ///
    void write_to(const std::string &data_path,
                  int precision=18,
                  bool enable_log=true) const;

  private:

    //------- Implementations.

    /// @brief Return the current number of element.
    ///
    /// @return The current number of elements in the pattern.
    ///
    int n_elem_impl() const { return _pmarks_pac.size(); }

    /// @brief Translate all the element by a displacement vector.
    ///
    /// @param pt: a pt specifying the tranlation. An Eigen point.
    /// @return `*this`.
    ///
    template<typename Point,
             typename = enable_if_t<is_eigen_v<Point>()> >
    exact_t& translate_impl(Point &&pt) const;

    /// @brief Implmentation of append element.
    ///
    /// @param mark: a mark to append to the curr pattern. A stogeo
    /// shape object.
    /// @return `*this`.
    ///
    template<typename GT, typename = enable_if_t <is_stg_shape_v<GT>()> >
    exact_t& append_impl(GT &&mark);

    /// @brief Implementation of variadic version of append and element.
    ///
    /// @param pars: parameters for any of the constructor for curr
    /// element type. However they must all be dterministic. Random
    /// variables will be rejected.
    /// @return `*this`.
    ///
    template<typename... PTS,
             typename = enable_if_all_t <(!is_stg_distr_v<PTS>())...,
                                         (!is_stg_shape_v<PTS>())...,
                                         (!is_stg_distr_v<PTS>())...> >
    exact_t& append_impl(PTS &&...pars);

    /// @brief Implmentation of remove element.
    ///
    /// @param ind the index of the element to remove.
    /// @return `*this`.
    ///
    exact_t& remove_impl(int ind);

    /// @brief Implmentation of slicing.
    ///
    /// @param lv: a logical (boolean) vector, std::vector of Eigen
    /// vector indicating which element to keep or discard.
    /// @param keep_val: optional bool value indicating which value
    /// means an element is to keep. Default to true.
    /// @return `*this`.
    ///
    template<typename Slice> exact_t& slicing_impl(Slice &&lv,
                                                   bool keep_val=true);

    /// @brief Indepedent thinning with fixed retaining probability.
    ///
    /// @param pr: the retaintion probability value.
    /// @return `*this`.
    ///
    exact_t& thinning_impl(float pr);

    /// @brief Functional version of thinning.
    ///
    /// @param retain_pr: the retain probability function. Should
    /// be a function taking const pmark_t & and returns value in
    /// (0,1): a probability.
    /// @return `*this`.
    ///
    template<typename RetainPr,
             typename = enable_if_t<!is_arithmetic_v<RetainPr>() > >
    exact_t& thinning_impl(RetainPr );

    /// @brief Marked point functional constraining. Can be treated as a
    /// thinning with binary retaining probability 0 or 1.
    ///
    /// Remove a marked point if it does not satisfy the constrain
    /// in the input Rule. the input Rules act on each elements of
    /// of the point pattern, which is a shape (pmark_t).
    ///
    /// @param rule: two functional objects specifying the rule for
    /// constraint. Taking const pmark_t & and return bool.
    /// @return `*this`.
    ///
    template<typename Rule> exact_t& constrain_impl(Rule);

    using parnt_t::_obs_window; //!< The observation window shape variant.
    mkset_t        _pmarks_pac; //!< An STL `vector` or shapes.
  };


  /// @ingroup group_rpatt
  ///
  /// @brief Random point patterns with arithmetic marks.
  ///
  /// @note This class stores point matrix / vector and marks both inside
  /// Eigen structures. So calling the `stogeo::MarkedPointPattern::pts()`
  /// and `stogeo::MarkedPointPattern::marks()` methods both returns
  /// references.
  ///
  /// @param PScalr: data type for scalar used for data points.
  /// @param PDim: dimension of the points.
  /// @param MScalr: data type for mark's value.
  /// @param MDim: dimension of the marks, i.e. number of marks for each
  /// point.
  ///
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  class MarkedPointPattern
    : public abstract::ptsbase<MarkedPointPattern<PScalr,PDim,MScalr,MDim> >
  {
    static_assert(is_arithmetic_v<MScalr>(),
                  "ERROR: THIS SPECIALIZATION EXPECTS A SCALAR.");
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    using exact_t                 = MarkedPointPattern<PScalr,PDim,MScalr,MDim>;
    using specs_t                 =          traits::specs<exact_t>;
    using scalr_t                 =       typename specs_t::scalr_t;
    using msclr_t                 =       typename specs_t::msclr_t;
    using point_t                 =       typename specs_t::point_t;
    using pmark_t                 =       typename specs_t::pmark_t;
    using vectr_t                 =       typename specs_t::vectr_t;
    using mkvec_t                 =       typename specs_t::mkvec_t;
    using matrx_t                 =       typename specs_t::matrx_t;
    using slice_t                 =       typename specs_t::slice_t;
    using obswd_t                 =       typename specs_t::obswd_t;
    using bound_t                 =       typename specs_t::bound_t;
    using mkset_t                 =       typename specs_t::mkset_t;

    using super_t                 =      abstract::ptsbase<exact_t>;
    using parnt_t                 = abstract::patternsbase<exact_t>;
    friend                                                  parnt_t;
    friend                                                  super_t;

    static constexpr int dim      =                            PDim;
    static constexpr int mark_dim =                            MDim;

    //------- Inherited interfaces.

    using parnt_t::                                          window;
    using parnt_t::                                          n_elem;
    using parnt_t::                                          centre;
    using parnt_t::                                          volume;
    using parnt_t::                                       translate;
    using parnt_t::                                    bounding_box;
    using parnt_t::                                    out_of_bound;

    using parnt_t::                                          append;
    using parnt_t::                                          remove;
    using parnt_t::                                         slicing;
    using parnt_t::                                        thinning;
    using parnt_t::                                      set_window;

    using super_t::                                              pt;
    using super_t::                                             pts;
    using super_t::                                         closest;
    using super_t::                                         masking;
    using super_t::                                         exclude;
    using super_t::                                        restrict;
    using super_t::                                       constrain;

    //------- @brief Constructor.

    /// @brief Constructor.
    ///
    /// Init w/ observation window and pre-allocate number n_elem of elements.
    /// The n_elem is defaulted to 0.
    /// @warning calling n_elem() after construction returns the input n_elem.
    /// This is since internal storage for arithmetic marks and pts are Eigen
    /// matrics. The will get resized.
    /// @param obs_window: the observation window of the simple point pattern.
    /// Should be any valid geometric shape.
    /// @param n_elem: number of element to pre-alloc mem for. Default to 0.
    ///
    template<typename WT, enable_if_t<is_stg_shape_v<WT>()>* = nullptr>
    MarkedPointPattern(WT &&obs_window, int n_elem=0):
      abstract::ptsbase<exact_t>(std::forward<WT>(obs_window),n_elem),
      _pmarks_pac(_pmarks_pac.rows(), n_elem) {};

    /// @brief Constructor.
    ///
    /// Initialize with a window and a point matrix.
    ///
    /// @param: obs_window: the observation window of the simple point pattern.
    /// Should be any valid geometric shape.
    /// @param pts_matrix: an Eigen Dim x n_elem matrix containning points to
    /// be copied into the point pattern.
    ///
    template<typename WT, typename PMT, typename MMT,
             enable_if_all_t<is_eigen_v<PMT>(), is_stg_shape_v<WT>()>* = nullptr>
    MarkedPointPattern(WT &&obs_window, PMT &&pts_matrix, MMT &&mks_matrix):
      abstract::ptsbase<exact_t>(std::forward<WT>(obs_window),
                                 std::forward<PMT>(pts_matrix)),
      _pmarks_pac(std::forward<MMT>(mks_matrix)) {};

    /// @brief Default constructor.
    MarkedPointPattern() = default;

    /// @brief Default copy ctors.
    MarkedPointPattern(const exact_t &rhs) = default;

    /// @brief Default move ctor.
    MarkedPointPattern(exact_t &&rhs) = default;

    /// @brief Default copy assignment operator.
    MarkedPointPattern& operator=(const exact_t &rhs) = default;

    /// @brief Default move assignment operator.
    MarkedPointPattern& operator=(exact_t &&rhs) = default;

    /// @brief Non-const access matrix of all marks.
    ///
    /// @return reference to the mark matrix.
    ///
    mkset_t& marks() { return _pmarks_pac; };

    /// @brief Const accessor.
    ///
    /// @return const reference to the mark matrix.
    ///
    const mkset_t& marks() const { return _pmarks_pac; };

    /// @brief Access mark of querry indx.
    ///
    /// @param ind: the input query index.
    /// @return reference to mark of index ind.
    ///
    decltype(mkset_t().col(int())) mark(int ind)
    { return _pmarks_pac.col(ind); };

    /// @brief Const accessor of mark of query index.
    ///
    /// @param ind: the input query index.
    /// @return const reference to mark of index ind.
    ///
    decltype(add_const_t<mkset_t>().col(int())) mark(int ind) const
    { return _pmarks_pac.col(ind); };

    /// @brief Read from a text file.
    exact_t& read_from(const std::string &, bool enable_log=true);

    /// @brief Write to a text file.
    void write_to(const std::string &, int precision=18,
                  bool enable_log=true) const;

  private:

    using super_t::   n_elem_impl;
    using super_t::  closest_impl;
    using super_t::translate_impl;

    /// @brief Append elements: pt & mark to end of pattern.
    ///
    /// @param pt: a point to append.
    /// @param mk: associated mark to append.
    /// @return `*this`.
    ///
    template<typename PT, typename MT,
             typename = enable_if_all_t<eigen_rows_v<PT>()==PDim,
                                        eigen_rows_v<MT>()==MDim,
                                        eigen_cols_v<PT>()==1,
                                        eigen_cols_v<MT>()==1> >
    exact_t& append_impl(PT &&pt, MT &&mk);

    /// Remove and element with certain index.
    ///
    /// @param ind: The index of the element to remove.
    /// @return `*this`.
    ///
    exact_t& remove_impl(int ind);

    /// @brief Implmentation of slicing.
    ///
    /// @param lv: a logical (boolean) vector, std::vector of Eigen
    /// vector indicating which element to keep or discard.
    /// @param keep_val: optional bool value indicating which value
    /// means an element is to keep. Default to true.
    /// @return `*this`.
    ///
    template<typename Slice> exact_t& slicing_impl(Slice &&lv,
                                                   bool keep_val=true);

    /// @brief Indepedent thinning with fixed retaining probabilities.
    ///
    /// @param pr: the retaintion probability value.
    /// @return `*this`.
    ///
    exact_t& thinning_impl(float pr) { return super_t::thinning_impl(pr); }

    /// @brief Functional version of thinning.
    ///
    /// @param retain_pr: the retain probability functions. Should
    /// be a function taking const point_t& and const pmark_t& and
    /// returns (0,1). Since callees are results from mat.col(i)
    /// it is recommanded to write functors with templated params,
    /// or generic lambdas (C++14) to avoid evaluating the Eiegn's
    /// expression mat.col(i) to a temporary col vector.
    /// @return `*this`.
    ///
    template<typename RetainPr,
             typename = enable_if_all_t<!is_arithmetic_v<RetainPr>()> >
    exact_t& thinning_impl(RetainPr retain_pr);

    /// @brief Marked point functional constraining. Can be treated
    /// as a thinning with binary retaining probability 0 or 1.
    ///
    /// Remove a marked point if it does not satisfy the constrain
    /// in the input Rule. the input Rules act on each elements of
    /// of the point pattern, which are 1) point_t & 2) pmakr_t.
    ///
    /// @param rule: a functional object specifying the rule for
    /// constraint. Taking const ref to point_t and pmark_t.
    /// @return `*this`.
    ///
    template<typename Rule> exact_t& constrain_impl(Rule rule);

    using parnt_t::_obs_window; //!< Observation window, a shape or variant.
    matrx_t        _pts_matrix; //!< Storing points, an Eigen matrix.
    mkset_t        _pmarks_pac; //!< Storing point marks, an Eigen Matrix.
  };

} //!stogeo


# include "MarkedPointPattern.hxx"
#endif //!STOGEO_MARKEDPOINTPATTERN_HH
