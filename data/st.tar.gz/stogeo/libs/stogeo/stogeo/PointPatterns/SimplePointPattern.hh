// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// SimplePointPattern.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Jan 12 23:40:02 2016 Zhijin Li
// Last update Tue Sep 26 14:41:26 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_SIMPLEPOINTPATTERN_HH
# define STOGEO_SIMPLEPOINTPATTERN_HH

# include "patternsbase.hh"


namespace stogeo
{
  // Fwd decl.
  template<typename T, int Dim> class SimplePointPattern;

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::SimplePointPattern`
    /// class.
    ///
    template<typename T, int Dim> struct specs<SimplePointPattern<T,Dim> >
    {
      static constexpr int dim    =                              Dim;
      static const stg_ids stg_id =            stg_ids::STOGEO_SPPAT;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef T                                              scalr_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef Eigen::Matrix<T,Dim,2>                         bound_t;
    };
  }

  namespace abstract
  {
    /// @ingroup group
    ///
    /// @brief The base class for patterns holding a pts matrix inside.
    ///
    /// @param EXACT: type of the derived class inheriting from it.
    ///
    template<typename EXACT> class ptsbase: public patternsbase<EXACT>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            =                           EXACT;
      using specs_t            =          traits::specs<exact_t>;
      using scalr_t            =       typename specs_t::scalr_t;
      using point_t            =       typename specs_t::point_t;
      using vectr_t            =       typename specs_t::vectr_t;
      using matrx_t            =       typename specs_t::matrx_t;
      using slice_t            =       typename specs_t::slice_t;
      using obswd_t            =       typename specs_t::obswd_t;
      using bound_t            =       typename specs_t::bound_t;

      using internal__::                    root__<EXACT>::exact;
      using parnt_t            = abstract::patternsbase<exact_t>;
      friend parnt_t;

      static constexpr int dim =                    specs_t::dim;

    protected:

      using parnt_t::                                     n_elem;
      using parnt_t::                                    slicing;

      /// @brief Ctor.
      ///
      /// Init w/ observation window and pre-allocate number n_elem of elements.
      /// The n_elem is defaulted to 0.
      ///
      /// @param obs_window: the observation window of the simple point pattern.
      /// Should be any valid geometric shape.
      /// @param n_elem: number of element to pre-alloc mem for. Default to 0.
      ///
      template<typename WT, enable_if_t<is_stg_shape_v<WT>()>* = nullptr>
      ptsbase(WT &&obs_window, int n_elem=0):
        abstract::patternsbase<exact_t>(std::forward<WT>(obs_window)),
        _pts_matrix(matrx_t(_pts_matrix.rows(),n_elem)) {};

      /// @brief Ctor.
      ///
      /// Initialize with a window and a point matrix.
      ///
      /// @param: obs_window: the observation window of the simple point pattern.
      /// Should be any valid geometric shape.
      /// @param pts_matrix: an Eigen dim x n_elem matrix containning points to
      /// be copied into the point pattern.
      ///
      template<typename WT, typename MT,
               enable_if_all_t<is_eigen_v<MT>(), is_stg_shape_v<WT>()>* = nullptr>
      ptsbase(WT &&obs_window, MT &&pts_matrix):
        abstract::patternsbase<exact_t>(std::forward<WT>(obs_window)),
        _pts_matrix(std::forward<MT>(pts_matrix)) {};

      /// @brief Default constructor.
      ptsbase() = default;

      /// @brief Default copy ctors.
      ptsbase(const ptsbase &rhs) = default;

      /// @brief Default move ctor.
      ptsbase(ptsbase &&rhs) = default;

      /// @brief Default copy assignment operator.
      ptsbase& operator=(const ptsbase &rhs) = default;

      /// @brief Default move assignment operator.
      ptsbase& operator=(ptsbase &&rhs) = default;

      /// @brief Access underlying point matrix.
      ///
      /// @return Reference to the points matrix.
      ///
      matrx_t& pts(){ return _pts_matrix; }

      /// @brief Const access underlying point matrix.
      ///
      /// @return Const reference to the points matrix.
      ///
      const matrx_t& pts() const{ return _pts_matrix; }

      /// @brief Access a point.
      ///
      /// @warning For efficiency purpose, this function return an
      /// Eigen **expression to a column of the point matrix**.
      /// Converting to a column vector will create a temporary obj.
      ///
      /// @return Expression object representing a column of the
      /// point matrix.
      ///
      decltype(matrx_t().col(int())) pt(int ind)
      { return(_pts_matrix.col(ind)); }

      /// @brief Const access a point.
      ///
      /// @warning For efficiency purpose, this function return an
      /// Eigen **expression to a column of the point matrix**.
      /// Converting to a column vector will create a temporary obj.
      ///
      /// @return Const expression object representing a column of
      /// the point matrix.
      ///
      decltype(add_const_t<matrx_t>().col(int())) pt(int ind) const
      { return(_pts_matrix.col(ind)); }

      /// @brief Return the index of the nearest element to the
      /// querry pt.
      ///
      /// @return Index of the closest point to the query point.
      ///
      std::ptrdiff_t closest(const point_t &pt) const
      { return closest_impl(pt); };

      /// @brief Binary masking
      ///
      /// Mask a point pattern using a cmn::ImageND, following spec
      /// val_rule: val_rule determines which points to KEEP. deflt
      /// to is_zero: keep points falling inside image's zero value
      /// regions.
      ///
      /// @param mask: a cmn::ImageND used as input mask.
      /// @param val_rule: a functional object specifying rule for
      /// points to KEEP. Defaulted to is_zero.
      /// @return `*this`. The modified simple point pattern.
      ///
      template<typename E, typename Rule=is_zero_t>
      exact_t& masking(const cmn::abstract::Image<E> &mask,
                       Rule val_rule=is_zero);

      /// @brief Point thinning using geometric constrain.
      ///
      /// Remove points falling outside of the geometric shape or
      /// marked point pattern.
      ///
      /// @param constrain: a geometric shape or a marked point pat.
      /// @return `*this`. The modified simple point pattern.
      ///
      template<typename GT> exact_t& restrict(GT &&constrain);

      /// @brief Point thinning using geometric constrain.
      ///
      /// Remove points falling inside of the geometric shape or
      /// marked point pattern.
      ///
      /// @param constrain: a geometric shape or a marked point pat.
      /// @return `*this`. The modified simple point pattern.
      ///
      template<typename GT> exact_t& exclude(GT &&constrain);

      // ------> Default implementations.

      /// @brief Return number of elements in current point pattern.
      ///
      /// @return The current number of elements.
      ///
      int n_elem_impl() const { return _pts_matrix.cols(); };

      /// @brief Translate all points by a input displacement vec.
      ///
      /// @param vec: the input displacement point.
      /// @return *this.
      ///
      template<typename Point,
               typename = enable_if_t<is_eigen_v<Point>()> >
      exact_t& translate_impl(Point &&vec) const;

      std::ptrdiff_t closest_impl(const point_t &) const;

      /// @brief Implmentation of append element.
      ///
      /// @param pt: an input point to append.
      /// @return `*this`.
      ///
      template<typename PT, typename =
               enable_if_all_t<is_eigen_v<PT>(), eigen_cols_v<PT>()==1> >
      exact_t& append_impl(PT &&pt);

      /// @brief Implementation of append taking arithmetics.
      ///
      /// @param args: arithmetics representing coordiantes of the
      /// point to append.
      /// @return `*this`.
      ///
      template<typename ...Args,
               typename = enable_if_all_t<is_arithmetic_v<Args>()...> >
      exact_t& append_impl(Args ...args);

      /// @brief Implmentation of remove element.
      ///
      /// @param ind: index of the point to remove.
      /// @return `*this`.
      ///
      exact_t& remove_impl(int ind);

      /// @brief Implementation of independent thinning.
      ///
      /// @param pr: the retaintion probability.
      /// @return `*this`.
      ///
      exact_t& thinning_impl(double );

      //------- Attributes.

      using parnt_t::_obs_window;
      matrx_t        _pts_matrix;
    };

  }


  /// @ingroup group_rpatt
  ///
  /// @brief Class for Simple Point Pattern.
  ///
  /// Class allowing operations on simple point patterns, including
  /// construction, query, linear transformation, various thinning,
  /// functional operation and I/O operations. It internally holds
  /// a dynamic `Eigen` point matrix.
  ///
  /// @param T: the scalar type of data points.
  /// @param Dim: the dimension.
  ///
  template<typename T, int Dim > class SimplePointPattern:
    public abstract::ptsbase<SimplePointPattern<T,Dim> >
  {
  public:
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW

    using exact_t            =       SimplePointPattern<T,Dim>;
    using specs_t            =          traits::specs<exact_t>;
    using scalr_t            =       typename specs_t::scalr_t;
    using point_t            =       typename specs_t::point_t;
    using vectr_t            =       typename specs_t::vectr_t;
    using matrx_t            =       typename specs_t::matrx_t;
    using slice_t            =       typename specs_t::slice_t;
    using obswd_t            =       typename specs_t::obswd_t;
    using bound_t            =       typename specs_t::bound_t;

    using super_t            = abstract::     ptsbase<exact_t>;
    using parnt_t            = abstract::patternsbase<exact_t>;
    friend                                             parnt_t;
    friend                                             super_t;

    static constexpr int dim =                             Dim;

    //------- Ctors.

    /// @brief Ctor.
    ///
    /// Init w/ observation window and pre-allocate number n_elem of elements.
    /// The n_elem is defaulted to 0.
    ///
    /// @param obs_window: the observation window of the simple point pattern.
    /// Should be any valid geometric shape.
    /// @param n_elem: number of element to pre-alloc mem for. Default to 0.
    ///
    template<typename WT, enable_if_t<is_stg_shape_v<WT>()>* = nullptr>
    SimplePointPattern(WT &&obs_window, int n_elem=0):
      abstract::ptsbase<exact_t>(std::forward<WT>(obs_window),n_elem) {};

    /// @brief Ctor.
    ///
    /// Initialize with a window and a point matrix.
    ///
    /// @param: obs_window: the observation window of the simple point pattern.
    /// Should be any valid geometric shape.
    /// @param pts_matrix: an Eigen Dim x n_elem matrix containning points to
    /// be copied into the point pattern.
    ///
    template<typename WT, typename MT,
             enable_if_all_t<is_eigen_v<MT>(), is_stg_shape_v<WT>()>* = nullptr>
    SimplePointPattern(WT &&obs_window, MT &&pts_matrix):
      abstract::ptsbase<exact_t>(std::forward<WT>(obs_window),
                                 std::forward<MT>(pts_matrix)) {};

    /// @brief Default ctor. A unit box with 0 pts.
    SimplePointPattern() = default;

    /// @brief Default copy ctors.
    SimplePointPattern(const exact_t &) = default;

    /// @brief Default move ctor.
    SimplePointPattern(exact_t &&) = default;

    /// @brief Default copy assignment operator.
    SimplePointPattern& operator=(const exact_t &) = default;

    /// @brief Default move assignment operator.
    SimplePointPattern& operator=(exact_t &&) = default;

    //------- Inherited interfaces.

    using parnt_t::        window;
    using parnt_t::        n_elem;
    using parnt_t::        centre;
    using parnt_t::        volume;
    using parnt_t::     translate;
    using parnt_t::  bounding_box;
    using parnt_t::  out_of_bound;

    using parnt_t::        append;
    using parnt_t::        remove;
    using parnt_t::       slicing;
    using parnt_t::      thinning;
    using parnt_t::    set_window;
    using parnt_t::     constrain;

    using super_t::            pt;
    using super_t::           pts;
    using super_t::       closest;
    using super_t::       masking;
    using super_t::       exclude;
    using super_t::      restrict;

    /// @brief Read from a text file.
    ///
    /// @param path: the input path. A `std::string`.
    /// @param enable_log: whether to enable log.
    /// @return `*this`.
    ///
    exact_t& read_from(const std::string &path, bool enable_log=true);

    /// @brief Write to a text file.
    ///
    /// @param path: the input path. A `std::string`.
    /// @param precision: precision for floating point writing.
    /// @param enable_log: whether to enable log.
    ///
    void write_to(const std::string &path, int precision=18,
                  bool enable_log=true) const;

  private:

    using super_t::   n_elem_impl;
    using super_t::   append_impl;
    using super_t::   remove_impl;
    using super_t::  closest_impl;
    using super_t:: thinning_impl;
    using super_t::translate_impl;

    /// @brief Implmentation of slicing.
    template<typename Slice> exact_t& slicing_impl(Slice &&,
                                                   bool keep_val=true);

    /// @brief Functional version of thinning.
    ///
    /// @param retain_pr: the retain probability function. Should
    /// be a function taking const point_t & and returning (0,1).
    /// Since callees are results from mat.col(i) it's recommanded
    /// to write functors with templated params or generic lambdas
    /// (C++14) to avoid evaluating the Eiegn's expr mat.col(i) to
    /// a temporary col vector.
    /// @return `*this`. The modified simple point pattern;
    ///
    template<typename RetainPr,
             typename = enable_if_t<!is_arithmetic_v<RetainPr>()> >
    exact_t& thinning_impl(RetainPr );

    /// @brief Point conatraining using functional constrain. It can be
    /// treated as a thinning with a retain pr either 0 or 1.
    ///
    /// Remove a point if it does not satisfy the constrain spec
    /// by the input Rule. the input Rule act on each element of
    /// of the point pattern, which is of type point_t.
    ///
    /// @param rule: a functional object specifying the rule for
    /// constraint.
    /// @return `*this`. the modified simple point pattern.
    ///
    template<typename Rule> exact_t& constrain_impl(Rule );

    using parnt_t::   _obs_window;
    using super_t::   _pts_matrix;
  };

}


# include "SimplePointPattern.hxx"
#endif
