// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// SimplePointPattern.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Jan 12 23:41:53 2016 Zhijin Li
// Last update Sun Nov 20 17:25:37 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace abstract
  {

    // =====================================================================
    template<typename EXACT> template<typename E, typename Rule>
    auto ptsbase<EXACT>::masking(const cmn::abstract::Image<E> &mask,
                                 Rule val_rule) -> exact_t&
    {
      static_assert(cmn_dim(E) == dim, "ERROR: MASK AND PATTERN DIM MISMATCH.");
      slice_t lv(n_elem());
      for(auto __n = 0; __n < n_elem(); ++__n)
      {
        auto __curr_pos = utils::make_cmn_pt(_pts_matrix.col(__n),mask.domain());
        lv(__n) = mask.hold(__curr_pos) && val_rule(mask[__curr_pos]);
      }
      return slicing(lv);
    }

    // =====================================================================
    template<typename EXACT> template<typename GT>
    auto ptsbase<EXACT>::restrict(GT &&shape) -> exact_t&
    {
      static_assert(is_stg_shape_v<GT>() || is_marked_patt_v<GT>(),
                    "ERROR: EXPECTS A SHPAE OR A GEOMETRIC PATTERN.");
      auto __lv = shape.inside_test(_pts_matrix);
      return slicing(__lv);
    }

    // =====================================================================
    template<typename EXACT> template<typename GT>
    auto ptsbase<EXACT>::exclude(GT &&shape) -> exact_t&
    {
      static_assert(is_stg_shape_v<GT>() || is_marked_patt_v<GT>(),
                    "ERROR: EXPECTS A SHPAE OR A GEOMETRIC PATTERN.");
      slice_t lv(n_elem());
      shape.inside_test(_pts_matrix,lv);
      return slicing(lv, false);
    }

    // =====================================================================
    template<typename EXACT> template<typename Point, typename>
    auto ptsbase<EXACT>::translate_impl(Point &&vec) const
      -> exact_t&
    {
      _pts_matrix.colwise() += std::forward<Point>(vec);
      return exact();
    }

    // =====================================================================
    template<typename EXACT>
    std::ptrdiff_t ptsbase<EXACT>::closest_impl(const point_t &pt) const
    {
      std::ptrdiff_t ind;
      ((_pts_matrix.colwise()-pt).colwise().norm()).minCoeff(&ind);

      assert(ind >= 0 && ind < n_elem());
      return ind;
    }

    // =====================================================================
    template<typename EXACT> template<typename PT, typename>
    auto ptsbase<EXACT>::append_impl(PT &&pt) -> exact_t&
    {
      _pts_matrix.conservativeResize(_pts_matrix.rows(),_pts_matrix.cols()+1);
      _pts_matrix.col(_pts_matrix.cols()-1) = std::forward<PT>(pt);
      return exact();
    }

    // =====================================================================
    template<typename EXACT> template<typename ...Args, typename>
    auto ptsbase<EXACT>::append_impl(Args ...args) -> exact_t&
    {
      static_assert(sizeof...(Args) == dim,
                    "ERROR: NUMBER OF ARGS SHOULD MATCH THE DIMENSION.");
      _pts_matrix.conservativeResize(_pts_matrix.rows(),_pts_matrix.cols()+1);
      _pts_matrix.col(_pts_matrix.cols()-1) = point_t{args...};
      return exact();
    }

    // =====================================================================
    template<typename EXACT>
    auto ptsbase<EXACT>::remove_impl(int ind) -> exact_t&
    {
      utils::remove_elem(_pts_matrix, ind);
      return exact();
    }

    // =====================================================================
    template<typename EXACT>
    auto ptsbase<EXACT>::thinning_impl(double pr) -> exact_t&
    {
      slice_t lv(n_elem());
      rnd::Bernoulli trial(pr);
      for(int c = 0; c < n_elem(); ++c) { lv(c) = trial.draw(); }
      return slicing(lv);
    }

  } //!abstract


  // =====================================================================
  template<typename T, int Dim >
  auto SimplePointPattern<T,Dim>::read_from(const std::string &read_path,
                                            bool enable_log) -> exact_t&
  {
    try{
      _pts_matrix = io::read_text_to_mat<T,Dim>(read_path,enable_log);
    } catch (const err::exception &e)
    { std::cerr << e.what(); }
    return *this;
  }

  // =====================================================================
  template<typename T, int Dim >
  void SimplePointPattern<T,Dim>::write_to(const std::string &save_path,
                                           int precision,
                                           bool enable_log) const
  {
    try{
      io::write_mat_to_text(save_path,_pts_matrix,precision,enable_log);
    } catch (const err::exception &e)
    { std::cerr << e.what(); }
  }

  // =====================================================================
  template<typename T, int Dim > template<typename Slice>
  auto SimplePointPattern<T,Dim>::slicing_impl(Slice &&lv, bool keep_val)
    -> exact_t&
  {
    utils::logical_slice(_pts_matrix,std::forward<Slice>(lv),keep_val);
    return *this;
  }

  // =====================================================================
  template<typename T, int Dim >
  template<typename RetainPr, typename>
  auto SimplePointPattern<T,Dim>::thinning_impl(RetainPr pr_func) -> exact_t&
  {
    slice_t lv(n_elem()); /// Do not use auto deduction.
    rnd::RUniform<float> trial(0.0,1.0);

    for(int c = 0; c < n_elem(); ++c)
    { lv(c) = (trial.draw() <= pr_func(_pts_matrix.col(c))); }

    return slicing(lv);
  }

  // =====================================================================
  template<typename T, int Dim > template<typename Rule>
  auto SimplePointPattern<T,Dim>::constrain_impl(Rule rule) -> exact_t&
  {
    slice_t lv(n_elem());
    for(int c = 0; c < n_elem(); ++c) { lv(c) = (rule(_pts_matrix.col(c))); }

    return slicing(lv);
  }

} //!stogeo
