// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// patternsbase.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Jan 12 13:51:03 2016 Zhijin Li
// Last update Tue Feb  6 14:49:30 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_PATTERNSBASE_HH
# define STOGEO_PATTERNSBASE_HH

# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "stogeo/geometry.hh"
# include "../Utilities/io.hh"
# include "../Utilities/mipp_helpers.hh"


namespace stogeo
{
  namespace abstract
  {

    /// @defgroup group_rpatt Random Point Patterns
    ///
    /// @brief Classes for containers of randomly distributed points with
    /// possible additional marks.
    ///
    /// Two types of random point patterns are distinguished in `StoGeo`:
    /// 1. **stogeo::SimplePointPattern**: where only data points are stored
    ///    without additional marks.
    /// 2. **stogeo::MarkedPointPattern** and **stogeo::MarkedPointPattern<Mark>**:
    ///    where data points are stored together with their marks.
    ///

    /// @ingroup group_rpatt
    ///
    /// @brief The base class for all random point patterns.
    ///
    /// @param EXACT: type of the derived class inheriting from it.
    ///
    template<typename EXACT>
    class patternsbase: public internal__::root__<EXACT>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using specs_t =      traits::specs<EXACT>;
      using scalr_t = typename specs_t::scalr_t;
      using point_t = typename specs_t::point_t;
      using vectr_t = typename specs_t::vectr_t;
      using matrx_t = typename specs_t::matrx_t;
      using bound_t = typename specs_t::bound_t;
      using obswd_t = typename specs_t::obswd_t;
      using internal__::   root__<EXACT>::exact;

    protected:

      //------- Interfaces.

      int n_elem() const { return exact().n_elem_impl(); }

      /// Access the observation widnow. Needs explicit template arg.
      template<typename WT> WT & window();

      /// Access the observation window. const. Needs explicit template arg.
      template<typename WT> const WT & window() const;

      /// Access window, return the stored variant.
      obswd_t& window() { return _obs_window; };

      /// Const access window, return the stored variant.
      const obswd_t& window() const { return _obs_window; };

      /// Get the observation window volume.
      scalr_t volume() const
      { return boost::apply_visitor(var::comp_volume<scalr_t>(),_obs_window); }

      /// Return the bounnding box of the observation window.
      bound_t bounding_box() const
      { return boost::apply_visitor(var::get_bounding_box<bound_t>(),
                                    _obs_window); }

      /// Get the observation window centre.
      const point_t& centre() const { return(_obs_window.centre()); }

      /// @brief Test if a querry pt is inside the bounding window.
      ///
      /// @param pt: the query point.
      /// @return True if the query point **is out of bound**.
      ///
      template<typename Point,
               typename = enable_if_t<is_eigen_v<Point>()> >
      bool out_of_bound(Point &&pt) const;

      //------- Operations on points and marks (element-wise).

      /// Set/alternate the observation window.
      template<typename WT, typename = enable_if_t<is_stg_shape_v<WT>()> >
      EXACT& set_window(WT &&);

      /// Translate all points.
      template<typename Point,
               typename = enable_if_t<is_eigen_v<Point>()> >
      EXACT& translate(Point &&pt)
      { return exact().translate_impl(std::forward<Point>(pt)); };

      /// Append element.
      template<typename... TPS> EXACT& append(TPS &&...elem)
      { return exact().append_impl(std::forward<TPS>(elem)...); };

      /// Thinnings.
      template<typename... TPS> EXACT& thinning(TPS &&...rules)
      { return exact().thinning_impl(std::forward<TPS>(rules)...); };

      /// Remove an element.
      EXACT& remove(int ind) { return exact().remove_impl(ind); };

      /// @brief Point pattern thinning using functional constrain.
      ///
      /// Remove an elem if it does not satisfy the constrain spec
      /// by the input `Rules`. The type of the `Rules` is
      /// determined by type of point pattern.
      ///
      /// @param rule: functional objs specifying the rules. Input
      /// types are determined acording to diff point pattern elem
      /// type.
      /// @return: the modified point pattern.
      ///
      template<typename ...Rules> EXACT& constrain(Rules ...rules)
      { return exact().constrain_impl(rules...); };

      /// Matlab type logical slicing of elements.
      template<typename Slice, typename = enable_if_any_t
               <is_eigen_v<Slice>(), is_stl_vector_of_v<Slice,bool>()> >
      EXACT& slicing(Slice &&lv, bool keep_val=true)
      { return exact().slicing_impl(lv, keep_val); };

      //------- Ctors & dtor.

      /// Ctor. Protected to prevent instantiation.
      template<typename WT, enable_if_t<is_stg_shape_v<WT>()>* = nullptr>
      patternsbase(WT &&);

      /// Default ctor.
      patternsbase() = default;

      /// Dflt copy ctors.
      patternsbase(const patternsbase &) = default;

      /// Dflt move ctor.
      patternsbase(patternsbase &&) = default;

      /// Dflt copy assignment operator.
      patternsbase& operator=(const patternsbase &) = default;

      /// Dflt move assignment operator.
      patternsbase& operator=(patternsbase &&) = default;

      //------- Class attributes.

      obswd_t _obs_window;
    };

  } //!abstract
} //!stogeo


# include "patternsbase.hxx"
#endif //!STOGEO_PATTERNSBASE_HH
