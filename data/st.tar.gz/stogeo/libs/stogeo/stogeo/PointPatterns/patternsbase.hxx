// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// patternsbase.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Jan 12 17:27:27 2016 Zhijin Li
// Last update Sun Nov 20 17:29:13 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace abstract
  {
    // =====================================================================
    template<typename EXACT>
    template<typename WT, enable_if_t<is_stg_shape_v<WT>()>*>
    patternsbase<EXACT>::patternsbase(WT &&obs_window):
      _obs_window(std::forward<WT>(obs_window))
    {
      // Note: boost visitation cannot be used in static_assert contxt yet.
      assert( !boost::apply_visitor(var::is_rnd_shape(),_obs_window) );
    };

    // =====================================================================
    template<typename EXACT> template<typename Point, typename>
    bool patternsbase<EXACT>::out_of_bound(Point &&pt) const
    {
      return !boost::apply_visitor
        (var::inside_test<scalr_t,EXACT::dim>(std::forward<Point>(pt)),
         _obs_window);
    }

    // =====================================================================
    template<typename EXACT> template<typename WT, typename>
    auto patternsbase<EXACT>::set_window(WT &&window) -> EXACT&
    {
      _obs_window = std::forward<WT>(window);
      return exact();
    }

    // =====================================================================
    template<typename EXACT> template<typename WT>
    WT & patternsbase<EXACT>::window()
    {
      static_assert(is_stg_shape_v<WT>(),
                    "ERROR: WINDOW TYPE SHOULD BE STOGEO_SHAPE.");
      return boost::get<WT>(_obs_window);
    }

    // =====================================================================
    template<typename EXACT> template<typename WT>
    const WT & patternsbase<EXACT>::window() const
    {
      static_assert(is_stg_shape_v<WT>(),
                    "ERROR: WINDOW TYPE SHOULD BE STOGEO_SHAPE.");
      return boost::get<WT>(_obs_window);
    }

  } //!abstract
} //!stogeo
