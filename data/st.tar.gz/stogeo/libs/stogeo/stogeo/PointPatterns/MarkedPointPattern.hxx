// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MarkedPointPattern.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Jan 14 16:39:50 2016 Zhijin Li
// Last update Thu Sep  7 18:43:52 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  // =====================================================================
  template<typename Mark>
  template<typename WT, typename MPT,
           enable_if_all_t<is_eigen_v<MPT>(),is_stg_shape_v<WT>()>*>
  MarkedPointPattern<Mark>::MarkedPointPattern(WT &&window, MPT &&mpack):
    abstract::patternsbase<exact_t>(std::forward<WT>(window))
  {
    _pmarks_pac.reserve(mpack.cols());
    for(auto __c = 0; __c < mpack.cols(); ++__c)
      _pmarks_pac.emplace_back(mpack.col(__c));
  };

  // =====================================================================
  template<typename Mark>
  template<typename WT, typename GVT, enable_if_all_t
           <is_stl_vector_of_v
            <GVT, typename traits::specs<MarkedPointPattern<Mark> >::pmark_t,
             typename traits::specs<MarkedPointPattern<Mark> >::alloc_t>(),
            is_stg_shape_v<WT>()>*>
  MarkedPointPattern<Mark>::MarkedPointPattern(WT &&window, GVT &&marks):
    abstract::patternsbase<exact_t>(std::forward<WT>(window)),
    _pmarks_pac(std::forward<GVT>(marks))
  {
    for(std::size_t __g = 0; __g < marks.size(); ++__g)
      assert(marks[__g].ready() && "shape not ready, forgot to roll?");
  };

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::pts() const -> matrx_t
  {
    matrx_t __pts(Mark::dim,n_elem());
    for(auto __n = 0; __n < n_elem(); ++__n)
      __pts.col(__n) = _pmarks_pac[__n].centre();
    return __pts;
  }

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::mark_params() const -> parmt_t
  {
    parmt_t __params(eigen_rows_v<parmt_t>(),n_elem());
    for(auto __n = 0; __n < n_elem(); ++__n)
      __params.col(__n) = _pmarks_pac[__n].param();
    return __params;
  }

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::mpack() const -> mpack_t
  {
    mpack_t __mpack(eigen_rows_v<mpack_t>(),n_elem());
    for(auto __n = 0; __n < n_elem(); ++__n)
      __mpack.col(__n) = _pmarks_pac[__n].vpack();
    return __mpack;
  }

  // =====================================================================
  template<typename Mark>
  template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                        eigen_rows_v<PT>()==Mark::dim,
                                        eigen_cols_v<PT>()==1>*>
  bool MarkedPointPattern<Mark>::inside_test(PT &&pt) const
  {
    return std::find_if(_pmarks_pac.begin(),_pmarks_pac.end(),
                        [&pt](const pmark_t &__mk)
                        { return __mk.inside_test(pt); } )
      != _pmarks_pac.end();
  }

  // =====================================================================
  template<typename Mark>
  template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                        eigen_rows_v<MT>()==Mark::dim>*>
  void MarkedPointPattern<Mark>::inside_test(MT &&mat, slice_t &lv) const
  {
#pragma omp parallel for
    for(int __n = 0; __n < mat.cols(); ++__n)
    { lv(__n) = inside_test(std::forward<MT>(mat).col(__n)); }
  }

  // =====================================================================
  template<typename Mark>
  template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                        eigen_rows_v<MT>()==Mark::dim,
                                        eigen_cols_v<MT>()!=1>*>
  auto MarkedPointPattern<Mark>::inside_test(MT &&mat) const
    -> slice_t
  {
    slice_t __lv(mat.cols());
    inside_test(std::forward<MT>(mat),__lv);
    return __lv;
  }

  // =====================================================================
  template<typename Mark> template<typename VT, typename PT, typename>
  cmn_img_t<VT,Mark::dim> MarkedPointPattern<Mark>::discrete(PT &&resolution,
                                                             VT in_val,
                                                             VT out_val) const
  {
    static_assert(eigen_rows_v<PT>()==Mark::dim,
                  "ERROR: SPACING DIMENSION MISMATCH.");
    static_assert(eigen_cols_v<PT>()==1,
                  "ERROR: EXPECTS AN EIGEN VEC FOR SPACING.");
    static_assert(is_floating_point_v<eigen_val_t<PT> >(),
                  "ERROR: SPACING MUST BE FLOATING TYPE.");
    return discrete( utils::make_cmn_domain(bounding_box(),resolution),
                     in_val, out_val );
  }

  // =====================================================================
  template<typename Mark> template<typename VT>
  auto MarkedPointPattern<Mark>::discrete(const cmn_domain_t<Mark::dim> &dom,
                                          VT in_val, VT out_val)
    const -> cmn_img_t<VT,Mark::dim>
  {
    cmn_img_t<VT,Mark::dim> __bin_img(dom);
    __bin_img.assign(out_val);

#pragma omp parallel for
    for(auto __i = 0; __i < n_elem(); ++__i)
    {
      auto __pair = utils::make_aligned_domain
        (__bin_img.domain(), _pmarks_pac[__i].bounding_box(), dom.sp());
      cmn_fwditr_t<Mark::dim> __local_it(std::get<1>(__pair));

      cmn_for_all(__local_it)
      {
        auto curr_pos = __local_it+std::get<0>(__pair);
        if( __bin_img.hold(curr_pos) && (__bin_img[curr_pos]==out_val) )
          // Order not interchangeable: otherwise may segfault.
          __bin_img[curr_pos] = _pmarks_pac[__i].inside_test
            (utils::cmn_itr_pos<scalr_t>(__local_it))?in_val:out_val;
      }
    }
    return __bin_img;
  }

  // =====================================================================
  template<typename Mark>
  float MarkedPointPattern<Mark>::overlap_ratio_mcmc(int ind,
                                                     float intensity) const
  {
    auto __tmp_pat = pps::PoissonPP<scalr_t,Mark::dim>
      (pps::Intensity<scalr_t>{intensity}).draw(_pmarks_pac[ind]);
    __tmp_pat.constrain( [this](const point_t &__pt)
                         { return utils::in_bound(__pt,bounding_box()); } );
    // Some marks may reach out of the bounding box.

    auto __count_overlap = 0;
    for(int __c = 0; __c < __tmp_pat.n_elem(); ++__c)
      if( std::find_if(_pmarks_pac.begin(),_pmarks_pac.end(),
                       [__c,ind,&__tmp_pat,this](const pmark_t &__mk)
                       { return (&__mk != &_pmarks_pac[ind])
                           && __mk.inside_test(__tmp_pat.pt(__c)); } )
          != _pmarks_pac.end() )
        ++__count_overlap;
    return __count_overlap/static_cast<float>(__tmp_pat.n_elem());
  }

  // =====================================================================
  template<typename Mark> template<typename PT>
  float MarkedPointPattern<Mark>::overlap_ratio_lattice (int ind,
                                                         PT &&resolution) const
  {
    auto __local_grid = _pmarks_pac[ind].template discrete<short>
      (std::forward<PT>(resolution));
    cmn_iter_type(decltype(__local_grid)) __local_it(__local_grid.domain());

    slice_t __lv(n_elem());
    for(auto __l = 0; __l < n_elem(); ++__l)
    {

      scalr_t __radius = _pmarks_pac[__l].enclosing_radius()+
        _pmarks_pac[ind].enclosing_radius();
      __lv(__l) = ((_pmarks_pac[__l].centre()-_pmarks_pac[ind].centre()).
                   array().square().sum() < __radius*__radius);
    }

    long __n_total = 0;
    long __n_overlap = 0;
    point_t __query_pt = point_t::Zero();
    cmn_for_all(__local_it)
    {
      if( !__local_grid[__local_it] )
      {
        __query_pt = utils::cmn_itr_pos<scalr_t>(__local_it);
        if( !out_of_bound(__query_pt) )
        {
          ++__n_total;
          if( std::find_if
              (std::begin(_pmarks_pac),std::end(_pmarks_pac),
               [__query_pt,ind,&__lv,&__local_it,this](const pmark_t &mk)
               {
                 return __lv(&mk-&_pmarks_pac[0]) && (&mk != &_pmarks_pac[ind])
                   && mk.inside_test(__query_pt);
               } ) != std::end(_pmarks_pac) )
            ++__n_overlap;
        }
      }
    }
    return static_cast<float>(__n_overlap)/__n_total;
  }

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::read_from(const std::string &path,
                                           bool enable_log) -> exact_t&
  {
    mpack_t __mat;
    try{
      __mat = stogeo::io::read_text_to_mat<scalr_t,Mark::dim+Mark::n_params>
        (path,enable_log);
    } catch(const err::exception &e)
    { std::cerr << e.what() << std::endl; }

    (*this) = std::move(exact_t(_obs_window,__mat));
    return *this;
  }

  // =====================================================================
  template<typename Mark>
  void MarkedPointPattern<Mark>::write_to(const std::string &path,
                                          int precision,
                                          bool enable_log) const
  {
    try{
      stogeo::io::write_mat_to_text(path,mpack(),precision,enable_log);
    } catch (const err::exception &e)
    { std::cerr << e.what() << std::endl; }
  }

  // =====================================================================
  template<typename Mark> template<typename Point, typename>
  auto MarkedPointPattern<Mark>::translate_impl(Point &&pt) const
    -> exact_t&
  {
    for(auto __g = 0; __g < n_elem(); ++__g)
      _pmarks_pac[__g].move_to(_pmarks_pac[__g].centre()+pt);
  }

  // =====================================================================
  template<typename Mark>
  template<typename GT, typename>
  auto MarkedPointPattern<Mark>::append_impl(GT &&mark) -> exact_t&
  {
    assert(mark.ready() && "shape not ready, forgot to roll?");
    _pmarks_pac.emplace_back(mark.centre(),mark.param());
    return *this;
  }

  // =====================================================================
  template<typename Mark>
  template<typename... PTS, typename>
  auto MarkedPointPattern<Mark>::append_impl(PTS &&...pars) -> exact_t&
  {
    _pmarks_pac.emplace_back(std::forward<PTS>(pars)...);
    return *this;
  }

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::remove_impl(int ind) -> exact_t&
  {
    utils::remove_elem(_pmarks_pac, ind);
    return *this;
  }

  // =====================================================================
  template<typename Mark> template<typename Slice>
  auto MarkedPointPattern<Mark>::slicing_impl(Slice &&lv, bool keep_val)
    -> exact_t&
  {
    utils::logical_slice(_pmarks_pac,std::forward<Slice>(lv),keep_val);
    return *this;
  }

  // =====================================================================
  template<typename Mark>
  auto MarkedPointPattern<Mark>::thinning_impl(float pr) -> exact_t&
  {
    slice_t __lv(n_elem());
    rnd::Bernoulli __trial(pr);
    for(int __c = 0; __c < n_elem(); ++__c) { __lv(__c) = __trial.draw(); }
    return slicing(__lv);
  }

  // =====================================================================
  template<typename Mark>
  template<typename RetainPr, typename>
  auto MarkedPointPattern<Mark>::thinning_impl(RetainPr pr_func) -> exact_t&
  {
    slice_t __lv(n_elem());

    rnd::RUniform<float> trial(0.0,1.0);
    for(int __c = 0; __c < n_elem(); ++__c)
      __lv(__c) = (trial.draw() <= pr_func(_pmarks_pac[__c]));
    return slicing(__lv);
  }

  // =====================================================================
  template<typename Mark> template<typename Rule>
  auto MarkedPointPattern<Mark>::constrain_impl(Rule rule) -> exact_t&
  {
    slice_t __lv(n_elem());
    for(int __c = 0; __c < n_elem(); ++__c)
      __lv(__c) = rule(_pmarks_pac[__c]);
    return slicing(__lv);
  }


  // =====================================================================
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  template<typename PT, typename MT, typename>
  auto MarkedPointPattern<PScalr,PDim,MScalr,MDim>::append_impl(PT &&pt,
                                                                MT &&mk)
    -> exact_t&
  {
    super_t::append_impl(std::forward<PT>(pt));

    _pmarks_pac.conservativeResize(MDim, _pmarks_pac.cols()+1);
    _pmarks_pac.col(_pmarks_pac.cols()-1) = std::forward<MT>(mk);
    return *this;
  }

  // =====================================================================
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  auto MarkedPointPattern<PScalr,PDim,MScalr,MDim>::remove_impl(int ind)
    -> exact_t&
  {
    super_t::remove_impl(ind);

    utils::remove_elem(_pmarks_pac, ind);
    return *this;
  }

  // =====================================================================
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  template<typename Slice>
  auto MarkedPointPattern<PScalr,PDim,MScalr,MDim>::slicing_impl(Slice &&lv,
                                                                 bool keep_val)
    -> exact_t&
  {
    super_t::slicing_impl(std::forward<Slice>(lv),keep_val);
    utils::logical_slice(_pmarks_pac,std::forward<Slice>(lv),keep_val);
    return *this;
  }

  // =====================================================================
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  template<typename RetainPr, typename>
  auto MarkedPointPattern<PScalr,PDim,MScalr,MDim>::thinning_impl(RetainPr func)
    -> exact_t&
  {
    slice_t __lv(n_elem()); /// Do not use auto deduction.
    rnd::RUniform<float> trial(0.0,1.0);

    for(int __c = 0; __c < n_elem(); ++__c)
      __lv(__c) = (trial.draw() <= func(_pts_matrix.col(__c),
                                        _pmarks_pac.col(__c)));
    return slicing(__lv);
  }

  // =====================================================================
  template<typename PScalr, int PDim, typename MScalr, int MDim>
  template<typename Rule>
  auto MarkedPointPattern<PScalr,PDim,MScalr,MDim>::constrain_impl(Rule rule)
    -> exact_t&
  {
    slice_t __lv(n_elem());
    for(int __c = 0; __c < n_elem(); ++__c)
      __lv(__c) = rule(_pts_matrix.col(__c), _pmarks_pac.col(__c));
    return slicing(__lv);
  }

} //!stogeo
