// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// core.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Sep 30 10:38:37 2015 Zhijin Li
// Last update Fri Aug  5 15:58:39 2016 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_CORE_HH
# define STOGEO_CORE_HH

# include "Core/roots.hh"
# include "Core/defs.hh"
# include "Core/meta.hh"
# include "Core/visitors.hh"

#endif //!STOGEO_CORE_HH
