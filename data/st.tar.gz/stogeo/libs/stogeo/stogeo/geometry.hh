// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// geometry.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 18 17:27:15 2016 Zhijin Li
// Last update Fri Aug  5 14:29:23 2016 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_GEOMETRY_HH
# define STOGEO_GEOMETRY_HH

# include "Shapes/Box.hh"
# include "Shapes/Sphere.hh"
# include "Shapes/Ellipsoid.hh"
# include "Shapes/Rectangle.hh"

#endif //!STOGEO_GEOMETRY_HH
