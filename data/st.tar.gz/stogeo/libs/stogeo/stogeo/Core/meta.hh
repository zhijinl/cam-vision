// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// meta.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jan  4 11:48:05 2016 Zhijin Li
// Last update Fri Oct 13 09:47:23 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_META_HH
# define STOGEO_META_HH

# include <tuple>
# include <type_traits>
# include "defs.hh"


namespace stogeo
{

  /// @defgroup group_meta Meta-Programming Utilities
  ///
  /// @brief Utilities for **Meta-Programming** using StoGeo:
  /// - Compile-time computation.
  /// - SFINAE friendly interfaces.
  /// - Type detection, manipulation & transformation.
  ///
  /// SFINAE helpers + enable_if utils are recommanded to be used for
  /// **type constraint of templated functions**. It is extremely
  /// powerfull and helps you to write efficient code using `Eigen`
  /// expressions. However the syntaxes can be very verbose.
  ///
  /// Large part of this code base will be re-written when C++XX
  /// `Concepts` are available.
  ///

  /// @ingroup group_meta
  /// @brief Get size of a static c-style array at compile-time.
  ///
  /// @param AR: the input array.
  ///
  template<typename AR, int N>
  constexpr int c_arr_size(AR (&)[N]) noexcept { return N; }


  /// @brief Check if a pack of types is non-empty
  ///
  /// @param Types: an input pack pf types.
  /// @return True if the pack contains at least one type.
  ///
  template<typename ...Types>
  constexpr bool not_empty() { return sizeof...(Types) > 0; }

  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Alias for ::type as in C++14
  ///
  /// These are wrappers for standard type traits.
  ///
  template <typename... Ts> using void_t = void;
  template<bool B, class T, class F >
  using conditional_t = typename std::conditional<B,T,F>::type;
  template<bool B, typename T=void>
  using enable_if_t = typename std::enable_if<B,T>::type;
  template<typename T>
  using remove_cv_t = typename std::remove_cv<T>::type;
  template<typename T>
  using remove_reference_t = typename std::remove_reference<T>::type;
  template<typename T>
  using decay_t = typename std::decay<T>::type;
  template<typename LT, typename RT>
  using is_same_t = typename std::is_same<LT,RT>::type;
  template<typename BT, typename DT>
  using is_base_of_t = typename std::is_base_of<decay_t<BT>,decay_t<DT> >::type;
  template<typename T>
  using add_const_t = typename std::add_const<T>::type;
  template<typename T>
  using is_arithmetic_t = typename std::is_arithmetic<decay_t<T> >::type;
  template<typename... TS>
  using common_type_t = typename std::common_type<TS...>::type;
  template<typename T>
  using is_floating_point_t =
    typename std::is_floating_point<decay_t<T> >::type;
  template<typename T>
  using is_bool_t = enable_if_t<std::is_same<decay_t<T>,bool>::value>;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief constexpr function _v for type_traits.
  ///
  /// Will be replaced by C++14variable templates.
  ///
  template<typename T> constexpr bool is_integral_v()
  { return std::is_integral<decay_t<T> >::value; }
  template<typename T> constexpr bool is_floating_point_v()
  { return std::is_floating_point<decay_t<T> >::value; }
  template<typename BT, typename DT> constexpr bool is_base_of_v()
  { return std::is_base_of<decay_t<BT>,decay_t<DT> >::value; }
  template<typename T, typename U> constexpr bool is_same_v()
  { return std::is_same<decay_t<T>,decay_t<U> >::value; }
  template<typename T> constexpr bool is_arithmetic_v()
  { return std::is_arithmetic<decay_t<T> >::value; }
  template<typename InputType> constexpr bool is_bool_v()
  { return is_same_v<decay_t<InputType>,bool>(); }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is an `Eigen` data structure.
  ///
  /// @note To check if an expression produces an Eigen type, it **uses
  /// the fact that Eigen structures have** `RealScalar` **typedef**.
  ///
  /// @param T: an input type.
  /// @return True if the input type is an `Eigen` data structure.
  ///
  template <typename T> struct __has_realscalar
  {
    template<typename> friend constexpr bool is_eigen_v();
  private:
    template <typename T1> static typename T1::RealScalar check(int);
    template <typename...> static void check(...);
    //< Note: ellipsis is always the last of overload resolution.
    static const bool value = !std::is_void<decltype(check<T>(0))>::value;
  };

  template<typename T> constexpr bool is_eigen_v()
  { return __has_realscalar<decay_t<T> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input data structure can be accessed of its
  /// elements throught the `()` (parenthesis) operator.
  ///
  /// @param T: an input type.
  /// @return True if the input type is parentable.
  ///
  template <typename T, typename ...TS> struct __has_paren
  {
    template<typename...> friend constexpr bool is_parentable_v();
  private:
    template <typename T1, typename ...TS1>
    static decltype(std::declval<T1>()(std::declval<TS1>()...)) check(int);
    template <typename...> static void check(...);
    //< Note: ellipsis is always the last of overload resolution.
    static const bool value = !std::is_void<decltype(check<T,TS...>(0))>::value;
  };

  template<typename T, typename ...TS> constexpr bool is_parentable_v()
  { return __has_paren<decay_t<T>,decay_t<TS>...>::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input data structure can be accessed of its
  /// elements throught the `[]` (bracket) operator.
  ///
  /// @param T: an input type.
  /// @return True if the input type is bracketable.
  ///
  template <typename T, typename AT> struct __has_bracket
  {
    template<typename,typename> friend constexpr bool is_bracketable_v();
  private:
    template <typename T1, typename AT1>
    static decltype(std::declval<T1>()[std::declval<AT1>()]) check(int);
    template <typename...> static void check(...);
    //< Note: ellipsis is always the last of overload resolution.
    static const bool value = !std::is_void<decltype(check<T,AT>(0))>::value;
  };

  template<typename T, typename AT> constexpr bool is_bracketable_v()
  { return __has_bracket<decay_t<T>,decay_t<AT> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input structure has the `dim` traits property.
  ///
  /// @param T: an input type.
  /// @return True if the `dim` property exists in the input type's traits.
  ///
  template <typename T> struct __has_dim
  {
    template<typename> friend constexpr bool has_dim_v();
  private:
    template <typename T1> static decltype(traits::specs<T1>::dim) check(int);
    template <typename...> static void check(...);
    //< Note: ellipsis is always the last of overload resolution.
    static const bool value = !std::is_void<decltype(check<T>(0))>::value;
  };

  template<typename T> constexpr bool has_dim_v()
  { return __has_dim<decay_t<T> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief `enable_if_all_t` and `enable_if_any_t`.
  ///
  /// Multiple version of enable_if: this emulates
  /// C++17 `std::conjunction` and `std::disjunction`.
  ///
  /// @note They behaves exactly as their names indicate:
  /// `enable_if_all` bails out **right after the first false argument it
  /// encounters**, while `enable_if_any` bails out **right after the first
  /// true argument it encounters**.
  ///
  /// For `seq_and_v` and `seq_or_v`:
  /// @param Bs: a sequence of `bool`s.
  /// @return Logical AND | OR on the bool sequence, respectively.
  ///
  /// For `enable_if_all_t` and `enable_if_any_t`:
  /// @param Bs: a sequence of `bool`s.
  /// @return `void` if the logical AND | OR stands, respectively.
  ///
  template<bool...> struct seq_or: std::false_type {};
  template<bool...> struct seq_and: std::true_type {};
  template<bool B1, bool... Bs>
  struct seq_or<B1,Bs...>:
    conditional_t<B1,std::true_type,seq_or<Bs...> > {};
  template<bool B1, bool... Bs>
  struct seq_and<B1,Bs...>:
    conditional_t<B1,seq_and<Bs...>,std::false_type> {};

  template<bool... Bs> constexpr bool seq_and_v()
  { return seq_and<Bs...>::value; }
  template<bool... Bs> constexpr bool seq_or_v()
  { return seq_or<Bs...>::value; }

  template<bool... Bs>
  using enable_if_any = std::enable_if<seq_or<Bs...>::value>;
  template<bool... Bs>
  using enable_if_all = std::enable_if<seq_and<Bs...>::value>;
  template<bool... Bs>
  using enable_if_any_t = typename enable_if_any<Bs...>::type;
  template<bool... Bs>
  using enable_if_all_t = typename enable_if_all<Bs...>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief This creates a compile-time integer sequence starting
  /// from 0 to (N-1).
  ///
  /// Complexity: `log(N)`, reference:
  /// http://stackoverflow.com/questions/17424477/implementation-
  /// c14-make-integer-sequence
  ///
  /// @param N: number of indices to generate.
  /// @return A compile-time integer sequence from 0 to (N-1).
  ///
  template<class T>
  using Invoke = typename T::type;

  template<int...>
  struct indx_seq{ using type = indx_seq; };

  template<class S1, class S2> struct concat;
  template<int... I1, int... I2>
  struct concat<indx_seq<I1...>, indx_seq<I2...> >
    : indx_seq<I1..., (sizeof...(I1)+I2)...> {};

  template<class S1, class S2>
  using Concat = Invoke<concat<S1, S2> >;

  template<int N> struct make_seq;
  template<int N> using GenSeq = Invoke<make_seq<N> >;

  template<int N>
  struct make_seq : Concat<GenSeq<N/2>,GenSeq<N-N/2> > {};

  template<> struct make_seq<0> : indx_seq<>{};
  template<> struct make_seq<1> : indx_seq<0>{};

  template<int N> using make_seq_t = typename make_seq<N>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve dimension of an input structure.
  ///
  /// Fails to compile if `dim` property is not available in the
  /// structure's type traits.
  ///
  /// @param T: an input type.
  /// @return An int indicating the dimension of the input structure.
  ///
  template<typename T, bool cond=has_dim_v<T>()> struct stg_dim_t {};
  template<typename T> struct stg_dim_t<T,false>
  { static constexpr int value = -1; };

  template<typename T> struct stg_dim_t<T,true>
  { static constexpr int value = traits::specs<decay_t<T> >::dim; };

  template<typename T, typename ...Args>
  struct stg_dim_t<variant<T,Args...>,false>
  { static constexpr int value = stg_dim_t<T>::value; };

  template<typename T> constexpr int stg_dim_v()
  { return stg_dim_t<decay_t<T> >::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrive `RealScalar` type, compile-time nrows & compile-time
  /// ncols from input Eigen expr.
  ///
  /// Retrives `RealScalar`, `RowsAtCimpileTime`, `ColsAtCimpileTime` from
  /// an input Eigen structure.
  ///
  /// @warning Undefined for structs that are not Eigen. Call will fail in
  /// this case.
  ///
  /// @param ET: an input structure type for the test.
  /// @return
  /// - The `RealScalar` for `eigen_val_t`.
  /// - The `RowsAtCimpileTime` for `eigen_rows_v`.
  /// - The `ColsAtCimpileTime` for `eigen_cols_v`.
  ///
  template<typename ET> using eigen_val_t = typename decay_t<ET>::RealScalar;
  template<typename ET, typename = enable_if_t<is_eigen_v<ET>()> >
  constexpr int eigen_rows_v() { return decay_t<ET>::RowsAtCompileTime; }
  template<typename ET, typename = enable_if_t<is_eigen_v<ET>()> >
  constexpr int eigen_cols_v() { return decay_t<ET>::ColsAtCompileTime; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen colmajored: return false if
  /// not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen column-majored struct,
  /// false otherwise. Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool eigen_colmajor_v() { return  !decay_t<ET>::IsRowMajor; }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool eigen_colmajor_v() { return  false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check size of an input structure matches the given value if
  /// it is Eigen. Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @param Rows: the input number of rows for the test.
  /// @param Rows: the input number of cols for the test.
  /// @return True if the input type is an Eigen struct, with
  /// `RowsAtCompileTime` == Rows && `ColsAtCompileTime` == Cols. Returns
  /// false if the structure is not an Eigen type.
  ///
  template<typename ET, int Rows, int Cols,
           enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool eigen_size_is_v()
  { return (eigen_rows_v<ET>()==Rows) && (eigen_cols_v<ET>()==Cols); }
  template<typename ET, int Rows, int Cols,
           enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool eigen_size_is_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input structure is an Eigen dynamic row vector.
  /// Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen dynamic row vector, i.e.
  /// `RowsAtCompileTime` == 1 && `ColsAtCompileTime` == -1, Returns false if
  /// the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_row_vec_v()
  { return (eigen_rows_v<ET>()==1) && (eigen_cols_v<ET>()==-1); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_row_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input structure is an Eigen dynamic row vector.
  /// Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen dynamic col vector, i.e.
  /// `ColsAtCompileTime` == 1 && `RowsAtCompileTime` == -1, Returns false if
  /// the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_col_vec_v()
  { return (eigen_rows_v<ET>()==-1) && (eigen_cols_v<ET>()==1); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_col_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check size of an input structure is an Eigen dynamic vector.
  /// Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen dynamic vector (row or col
  /// ordered), i.e. `RowsAtCompileTime` == 1 && `ColsAtCompileTime` == -1,
  /// or `RowsAtCompileTime` == -1 && `ColsAtCompileTime` == 1. Returns false
  /// if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_vec_v()
  {
    return is_eigen_dynamic_row_vec_v<ET>() ||
      is_eigen_dynamic_col_vec_v<ET>();
  }

  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check size of an input structure is an Eigen dynamic matrix.
  /// Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen dynamic matrix (row or col
  /// ordered), i.e. `RowsAtCompileTime` > 1 && `ColsAtCompileTime` == -1,
  /// or `RowsAtCompileTime` == -1 && `ColsAtCompileTime` > 1, or
  /// `RowsAtCompileTime` == -1 && `ColsAtCompileTime` == -1. Returns false
  /// if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_mat_v()
  {
    return ( (eigen_rows_v<ET>()>1) && (eigen_cols_v<ET>()==-1) ) ||
      ( (eigen_rows_v<ET>()==-1) && (eigen_cols_v<ET>()>1) ) ||
      ( (eigen_rows_v<ET>()==-1) && (eigen_cols_v<ET>()==-1) );
  }

  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_dynamic_mat_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fixed size: return false
  /// if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized vector / matrix:
  /// i.e. both Cols and Rows are compile-time fixed constants. Returns
  /// false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_size_v()
  { return (eigen_rows_v<ET>() != Eigen::Dynamic) &&
      (eigen_cols_v<ET>() != Eigen::Dynamic); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_size_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fixed matrix: return false
  /// if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix matrix: i.e. both
  /// `RowsAtCompileTime` and `ColsAtCompileTime` are > 1. Returns false
  /// if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_mat_v()
  { return (eigen_rows_v<ET>() > 1) && (eigen_cols_v<ET>() > 1); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_mat_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fixed col vec: return false
  /// if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized col vector: i.e.
  /// both Cols and Rows are compile-time fixed constants and Cols == 1.
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_col_vec_v()
  { return is_eigen_fixed_size_v<ET>() && (eigen_cols_v<ET>() == 1); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_col_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fixed row vec: return false
  /// if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized row vector: i.e.
  /// both Cols and Rows are compile-time fixed constants and Rows == 1.
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_row_vec_v()
  { return is_eigen_fixed_size_v<ET>() && (eigen_rows_v<ET>() == 1); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_row_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fixed vec of any ordering:
  /// return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized vector: i.e. both
  /// Cols and Rows are compile-time fixed constants and one of Rows / Cols
  /// is 1. Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_vec_v()
  { return is_eigen_fixed_row_vec_v<ET>() || is_eigen_fixed_col_vec_v<ET>(); }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_fixed_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fix sized or dynamic matrix:
  /// return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized or dynamic matrix
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_mat_v()
  {
    return is_eigen_fixed_mat_v<ET>() || is_eigen_dynamic_mat_v<ET>();
  }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_mat_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input structure is an Eigen row vector, dynamic or
  /// fixed. Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen row vector, dynamic or fixed.
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_row_vec_v()
  {
    return is_eigen_dynamic_row_vec_v<ET>() ||
      is_eigen_fixed_row_vec_v<ET>();
  }

  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_row_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input structure is an Eigen row vector dynamic or
  /// fixed. Return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen col vector, dynamic or fixed
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_col_vec_v()
  {
    return is_eigen_dynamic_col_vec_v<ET>() ||
      is_eigen_fixed_col_vec_v<ET>();
  }

  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_col_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input struct is Eigen fix sized or dynamic vector:
  /// return false if not Eigen.
  ///
  /// @param ET: an input structure type for the test.
  /// @return True if the input type is an Eigen fix sized or dynamic vector
  /// Returns false if the structure is not an Eigen type.
  ///
  template<typename ET, enable_if_t<is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_vec_v()
  {
    return is_eigen_fixed_vec_v<ET>() || is_eigen_dynamic_vec_v<ET>();
  }
  template<typename ET, enable_if_t<!is_eigen_v<ET>()>* = nullptr>
  constexpr bool is_eigen_vec_v() { return false; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve & mutate fields of Eigen structures.
  ///
  /// @param M: input Eigen structure.
  /// @param Row: integer number of rows.
  /// @param Col: integer number of cols.
  /// @return
  /// - `eigen_mat_t` is used to retrieve the `Matrix` type structure from
  ///   a valid Eigen expression.
  /// - `mutate_row_t` and `mutate_col_t` are used to alter in compile-time
  ///   the `RowsAtCompileTime` and `ColsAtCompileTime` of an Eigen Matrix
  ///   structure. **It need to be used with `Matrix` types, not any
  ///   expression**. The recommanded way of use it to **wrap an expression
  ///   with `eigen_mat_t`**, then pass the result to `mutate_row_t` and
  ///   `mutate_col_t`.
  /// - `mutate_val_t` is defined for any Eigen expressions and also for STL
  ///   `vector`s. It is not required that an Eigen `Matrix` is passed, since
  ///   internally it will wrap the given expression to a `Matrix` type.
  ///
  template<typename M, bool cond=is_eigen_v<M>()> struct __to_mat {};
  template<typename M> struct __to_mat<M,true>
  { using type = Eigen::Matrix<eigen_val_t<M>,eigen_rows_v<M>(),
                               eigen_cols_v<M>()>; };
  template<typename M> struct __to_mat<M,false> { using type = void; };
  template<typename M> using eigen_mat_t =
    typename __to_mat<decay_t<M> >::type;

  // Alter scalr_type/nrows/ncols of an Eigen expression.
  template<typename M, typename T> struct __mutate_val { using type = void; };
  template<typename M, int Row> struct __mutate_row { using type = void; };
  template<typename M, int Col> struct __mutate_col { using type = void; };

  template<typename T0, typename T, int Row, int Col>
  struct __mutate_val<Eigen::Matrix<T0,Row,Col>,T>
  { using type = Eigen::Matrix<T,Row,Col>; };
  template<typename T, int Row0, int Row, int Col>
  struct __mutate_row<Eigen::Matrix<T,Row0,Col>,Row>
  { using type = Eigen::Matrix<T,Row,Col>; };
  template<typename T, int Row, int Col0, int Col>
  struct __mutate_col<Eigen::Matrix<T,Row,Col0>,Col>
  { using type = Eigen::Matrix<T,Row,Col>; };

  template<typename M, int Row>
  using mutate_row_t = typename __mutate_row<eigen_mat_t<M>,Row>::type;
  template<typename M, int Col>
  using mutate_col_t = typename __mutate_col<eigen_mat_t<M>,Col>::type;

  // Value mutator is also specialized for STL::vector.
  template<typename M, typename T, bool cond=is_eigen_v<M>()>
  struct mutate_val {};
  template<typename M, typename T> struct mutate_val<M,T,true>
  { using type = typename __mutate_val<eigen_mat_t<M>,T>::type; };
  template<typename T0, typename T, typename Alloc>
  struct mutate_val<std::vector<T0,Alloc>,T,false>
  { using type = std::vector<T>; };
  template<typename M, typename T> struct mutate_val<M,T,false>
  { using type = void; };

  template<typename M, typename T>
  using mutate_val_t = typename mutate_val<M,T>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Rotation matrix size dispatch.
  ///
  /// @warning **N** is not dimension, but **the number of rotation angles.**
  ///
  /// Dimension 1 will be dispatched to an Eigen fixed matrix of size 2 x 2.
  /// Dimension 3 will be dispatched to an Eigen fixed matrix of size 3 x 3.
  /// @param Val: type of scalar used for rotation matrix.
  /// @param N: number of rotation angles.
  /// @return The dispatched fix-sized rotation matrix.
  ///
  template<typename Val,int N>
  struct __rot_dispatcher { using type = void; };
  template<typename Val> struct __rot_dispatcher<Val,1>
  { using type = Eigen::Matrix<Val,2,2>; };
  template<typename Val> struct __rot_dispatcher<Val,3>
  { using type = Eigen::Matrix<Val,3,3>; };

  template<typename Val, bool cond=is_eigen_v<Val>()>
  struct rotmat_dispatch {};
  template<typename Val> struct rotmat_dispatch<Val,true>
  {
    using type = typename __rot_dispatcher
      <eigen_val_t<Val>,eigen_rows_v<Val>()>::type;
  };

  template<typename Val>
  struct rotmat_dispatch<Val,false> { using type = void; };
  template<typename Val>
  using rotmat_dispatch_t = typename rotmat_dispatch<Val>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Value type dispatch for STL containers & Eigen.
  ///
  /// @param Struct: an input structure type from Eigen or STL.
  /// @param cond: not required, for dispatch purpose.
  /// @return The data type of elements inside the input structure.
  ///
  template<typename Struct, bool cond=is_eigen_v<Struct>()>
  struct value_dispatch {};
  template<typename Struct> struct value_dispatch<Struct, true>
  { using type = eigen_val_t<Struct>; };
  template<typename Struct> struct value_dispatch<Struct, false>
  { using type = typename Struct::value_type; };

  template<typename Struct>
  using value_dispatch_t =
    typename value_dispatch<decay_t<Struct> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Accessor dispatch for Eigen and STL containers.
  ///
  /// Generic interface wrapping both operator () for Eigen structures
  /// and operator [] for STL container (`std::vector` notably).
  ///
  /// @param cont: the input container or Eigen structure whose value
  /// will be accessed.
  /// @param args: integeral index / indices.
  /// @return Const reference to value in the container or Eigen struct
  /// indexed by the input index / indices.
  ///
  struct value_at_t
  {
    constexpr value_at_t() {};

    template<typename Struct, typename ...Args,
             enable_if_t<is_eigen_v<Struct>()>* = nullptr>
    auto operator()(Struct &&cont, Args ...args)
      const -> decltype(cont(args...))
    { return std::forward<Struct>(cont)(args...); }

    template<typename Struct, enable_if_t
             <!is_eigen_v<Struct>()>* = nullptr>
    auto operator()(Struct &&cont, std::size_t arg)
      const -> decltype(cont[arg])
    { return std::forward<Struct>(cont)[arg]; }
  };
  constexpr value_at_t value_at{};
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Dispatch for kernel smooth estimator band-width
  ///
  /// When Dim == 1, it dispatches to a scalar. When Dim > 1, it dispatches
  /// to an Eigen fixed matrix of size Dim x Dim.
  ///
  /// @param Scalar: the input scalar type for floating-point computations.
  /// @param Dim: the input dimension.
  ///
  template<typename Scalar, int Dim> struct bandwidth_dispatch
  { using type = Eigen::Matrix<Scalar,Dim,Dim>; };
  template<typename Scalar> struct bandwidth_dispatch<Scalar,1>
  { using type = Scalar; };

  template<typename Scalar, int Dim>
  using bandwidth_dispatch_t = typename bandwidth_dispatch<Scalar,Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check if an input type's ID matches the argument.
  ///
  /// @param T: an input type.
  /// @param id: an input `StoGeo` `std::ids` enum object.
  /// @return True if the ID of `T` matches `id`.
  ///
  /// @sa `stogeo::stg::ids`
  ///
  template<typename T, stg_ids id>
  constexpr bool stg_id_is_v()
  {
    return traits::specs<decay_t<T> >::stg_id == id;
  }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is a StoGeo distribution.
  ///
  /// @param T: the input type.
  /// @return True when the input type is a StoGeo distribution.
  ///
  template<typename T> constexpr bool is_stg_distr_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_RNDVR>(); }


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is a StoGeo symmetric distribution.
  ///
  /// @param T: the input type.
  /// @return True is the input type is a StoGeo symmetric distribution.
  ///
  template<typename T> constexpr bool is_symmetric_distr_v()
  {
    return is_stg_distr_v<T>() &&
      traits::specs<decay_t<T> >::is_symmetric;
  }


  ///@{
  ///
  /// @brief Check if an input type is a variant of an input
  /// `StoGeo` ID.
  ///
  /// @note A `variant` containing **at least one**
  /// matched type **dispatches also to true**. This is because
  /// old `variant` implementations append `void_` types
  /// after variant's argument list, **if the AND logical is
  /// used, a variant will never dispatch to true
  /// even if all variant arguments match the input ID.
  ///
  /// @param T: the input type.
  /// @param id: a `StoGeo` ID.
  ///
  /// @sa `stg_ids`.
  ///
  template<typename T, stg_ids id> struct is_variant_of
  { static const bool value = false; };

  template<typename ...Args, stg_ids id>
  struct is_variant_of<variant<Args...>, id>
  {
    // A variant containing at least one matched ID is
    // considered true.
    static const bool value =
      seq_or_v<(stg_id_is_v<Args,id>())...>();
  };

  template<typename T, stg_ids id>
  constexpr bool is_variant_of_v()
  { return is_variant_of<decay_t<T>, id>::value; }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Detect if an input structure is a `stogeo::shapes` or
  /// variant.
  ///
  /// @note A `boost::variant` containing **at least one** `stogeo::shapes`
  /// **dispatches also to true**. Notice that some old `boost::variant`
  /// implementations append `void_` types after variant's argument list,
  /// **if the AND logical is used, a variant will never dispatch to true
  /// even if all variant arguments are of `stogeo::shapes` types.
  ///
  /// @param T: an input type.
  /// @return True if the input is a `stogeo::shapes` type or a variant
  /// of it.
  ///
  template<typename T>
  constexpr bool is_stg_shape_v()
  {
    return stg_id_is_v<T,stg_ids::STOGEO_SHAPE>() ||
      is_variant_of_v<T,stg_ids::STOGEO_SHAPE>();
  }

  template<typename T> constexpr bool is_shape_nonvariant_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_SHAPE>(); }

  template<typename T> constexpr bool is_shape_variant_v()
  { return is_variant_of_v<T,stg_ids::STOGEO_SHAPE>(); }
  ///@}


  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is a StoGeo marked point pattern.
  ///
  /// @param T: the input type.
  /// @return True is the input type is a StoGeo marked point pattern.
  ///
  template<typename T> constexpr bool is_marked_patt_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_MKPAT>(); }


  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is a StoGeo kernel.
  ///
  /// @param T: the input type.
  /// @return True is the input type is a StoGeo kernel.
  ///
  template<typename T> constexpr bool is_stg_kernel_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_KERNL>(); }


  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is a StoGeo support.
  ///
  /// @param T: the input type.
  /// @return True is the input type is a StoGeo support.
  ///
  template<typename T> constexpr bool is_stg_support_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_SUPPR>(); }

  /// @ingroup group_meta
  ///
  /// @brief Detect if an input type is an STL vector with specific element
  /// type and allocator type.
  ///
  /// @param Element: the element's type, i.e. `value_type` of the vector.
  /// @param Allocator: the allocator's type. Defaults to the standard
  /// `allocator_type` of `std::vector`.
  /// @return True is the input type is an STL vector with specific element
  /// type and allocator type.
  ///
  template<typename Struct, typename Element,
           typename Allocator = typename std::vector<Element>::allocator_type>
  constexpr bool is_stl_vector_of_v()
  { return is_same_v<decay_t<Struct>, std::vector<Element,Allocator> >(); }


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve scalar type of a `stogeo::shape` type or its variant.
  ///
  /// @param T: an input type. A `stogeo::shapes` or a `variant` of
  /// `stogeo::shapes`.
  /// @return Type of scalar used in the input.
  ///
  template<typename ...T> struct stg_shape_scalr { using type = void; };
  template<typename First, typename ...Args>
  struct stg_shape_scalr<variant<First,Args...> >
  {
    using type = typename First::scalr_t;
  };
  template<typename T>
  using stg_shape_scalr_t = typename stg_shape_scalr<decay_t<T> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve the bounding box type of a `stogeo::shapes` or its
  /// variant.
  ///
  /// @param T: an input type. A `stogeo::shapes` or a `variant` of
  /// `stogeo::shapes`.
  /// @return The type of the bounding box, which is an Eigen fix-sized
  /// matrix of size Dim x 2.
  ///
  template<typename ...T> struct stg_shape_bound {using type = void; };
  template<typename First, typename ...Args>
  struct stg_shape_bound<variant<First,Args...> >
  {
    using type = typename First::bound_t;
  };
  template<typename T>
  using stg_shape_bound_t = typename stg_shape_bound<decay_t<T> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Retrieve the dimension of a `stogeo::shapes` or its variant.
  ///
  /// @param T: an input type. A `stogeo::shapes` or a `variant` of
  /// `stogeo::shapes`.
  /// @return The dimension of the input.
  ///
  template<typename ...T> struct stg_shape_dim
  { static constexpr int value = 0; };
  template<typename First, typename ...Args>
  struct stg_shape_dim<variant<First,Args...> >
  {
    static constexpr int value = First::dim;
  };
  template<typename T> constexpr int stg_shape_dim_v()
  { return stg_shape_dim<decay_t<T> >::value; }


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Dispatch for scalar value type based on input.
  ///
  /// When the input is an Eigen structure, it dispatches to the
  /// `RealScalar` typedef. When the input is an arithmetic, it dispatches
  /// to the type of the input itself.
  ///
  /// @param T: an input type.
  /// @return The dispatched scalar type.
  ///
  template<typename MT,
           bool cond1=is_eigen_v<MT>(), bool cond2=is_arithmetic_v<MT>()>
  struct scalar_dispatch { using type = void; };
  template<typename MT> struct scalar_dispatch<MT,true,false>
  { using type = eigen_val_t<MT>; };
  template<typename MT> struct scalar_dispatch<MT,false,true>
  { using type = MT; };

  template<typename T>
  using scalar_dispatch_t = typename scalar_dispatch<decay_t<T> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Dispatch for point type depending on input dimension &
  /// scalar type.
  ///
  /// When Dim == 1, the point type is simply the input scalar type.
  /// When Dim > 1, the point type is an Eigen column vector of size Dim
  /// x 1, with input `Scalar` type.
  ///
  /// @param Scalar: input scalar type.
  /// @param Dim: the dimension.
  /// @return The dispatch point type.
  ///
  template<typename Scalar, int Dim> struct point_dispatch
  { using type = Eigen::Matrix<Scalar,Dim,1>; };
  template<typename Scalar> struct point_dispatch<Scalar,1>
  { using type = Scalar; };

  template<typename Scalar, int Dim>
  using point_dispatch_t = typename point_dispatch<Scalar,Dim>::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Dispatch for bounding box types on input Eigen structure
  /// of point elements.
  ///
  /// @note The following rules are used:
  /// 1. When a matrix type is passed. It assumes that it is **column
  /// ordered**, meaning that each column represents a point element. The
  /// bounding box type is for column elements in this case. And it will
  /// dispatch to an Eigen matrix of size `RowsAtCompileTime` x 2.
  /// 2. When a **dynamic vector** type is passed, it **does not** assume
  /// the order of elements, meaning that either a column or a row vector
  /// can be passed, and they will both be dispatched as Eigen point with
  /// size 1 x 2. **It is the only exception when order does no matter.**
  /// 3. When a **fix sized row vector** type is passed, it acts the same
  /// as for matrices. For example, a fix sized vector of size 1 x 10 will
  /// dispatch to a bound of size 1 x 2, since it is considered as 10 one-
  /// dimensional elements.
  /// 4. When a **fix sized col vector** type is passed, it dispatches to
  /// `void`. That's because a fix sized col vector represents one single
  /// element, and bounding box for a single vector is not well defined.
  ///
  /// @param MT: an input structure type for the test.
  /// @param cond1: defaulted, for specialization purpose.
  /// @param cond2: defaulted, for specialization purpose.
  /// @return The dispatched bounding_box type:
  /// 1. When it's a matrix: `RowsAtCompileTime` x 2.
  /// 2. When it's a dynamic vector: Eigen 1 x 2 point.
  /// 3. When it's a fix sized vector: `void`.
  ///
  template<typename MT,
           bool cond0=is_eigen_v<MT>(),
           bool cond1=is_eigen_fixed_col_vec_v<MT>(),
           bool cond2=is_eigen_dynamic_vec_v<MT>()>
  struct bound_dispatch {};

  // For non-Eigen structures
  template<typename MT, bool cond1, bool cond2>
  struct bound_dispatch<MT,false,cond1,cond2> { using type = void; };

  // For fixed size col vectors.
  template<typename MT, bool cond> struct bound_dispatch<MT,true,true,cond>
  { using type = void; };

  // This case is for dynamic vectors.
  template<typename MT> struct bound_dispatch<MT,true,false,true>
  { using type = Eigen::Matrix<eigen_val_t<MT>,1,2>; };

  // This case is for Matrices or fix sized row vectors.
  template<typename MT> struct bound_dispatch<MT,true,false,false>
  { using type = Eigen::Matrix<eigen_val_t<MT>,eigen_rows_v<MT>(),2>; };

  template<typename MT>
  using bound_dispatch_t = typename bound_dispatch<decay_t<MT> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Dispatch for Eigen::aligned_allocator.
  ///
  /// This function retrieves the appropriate allocator type for an input
  /// structure. The rationale is, for any structures containing **fix sized
  /// Eigen types**, the usage with **STL containers** need to be passed
  /// alone with `Eigen::aligned_allocator` for alignment reasons.
  ///
  /// @param T: input type for the test.
  /// @param cond: defaulted, for specialzation purpose.
  /// @return `Eigen::aligned_allocator<T>` if
  /// 1. T has the traits `need_align` set to `true`.
  /// 2. Or T is an Eigen fix sized structure itself.
  ///
  template<typename T,
           bool cond = (is_stg_shape_v<T>() || is_eigen_fixed_size_v<T>())>
  struct alloc_dispatch
    : public std::conditional<cond, Eigen::aligned_allocator<decay_t<T> >,
                              std::allocator<decay_t<T> > > {};
  template<typename T> using alloc_dispatch_t =
    typename alloc_dispatch<decay_t<T> >::type;
  ///@}


  ///@(
  /// @brief Dispatch for **structural dimension** on input structure type.
  ///
  /// The **structural dimension** is the dimension of the domain represented
  /// by an Eigen structure. For example, an Eigen matrix of size 3 x Dynamic
  /// has structural dimension 3, each column represents a 3-dimensional elem.
  ///
  /// @note The following rules are used for dimension dispatch:
  /// 1. If a scalar type is given, then it leads to 1.
  /// 2. If an Eigen **dynamic** row or col vector is given, it leads to 1.
  /// This means a dynamic vector contains an **ensemble of 1D elements**.
  /// 3. If an Eigen **fix sized** col or row vector is used, it leads to
  /// `RowsAtCompileTime`. For example, a vector of size 3 x 1 represents a 3
  /// dimensional element. A vector of size 1 x 3, represents **three
  /// 1-dimensional elements**.
  /// 4. If an Eigen Matrix, whether fixed or dynamic  is given, it leads to
  /// `RowsAtCompileTime`. This means that the matrix **must be column ordered**,
  /// each column represnts a Dim-dimensional element.
  ///
  /// @param T: the input structure type.
  /// @return The structure dimension.
  ///
  template<typename T, enable_if_t<is_arithmetic_v<T>()>* = nullptr>
  constexpr int dim_dispatch_v() { return 1; }

  template<typename T, enable_if_t<is_eigen_dynamic_vec_v<T>()>* = nullptr>
  constexpr int dim_dispatch_v() { return 1; }

  template<typename T, enable_if_t<is_eigen_fixed_vec_v<T>()>* = nullptr>
  constexpr int dim_dispatch_v() { return eigen_rows_v<T>(); }

  template<typename T, enable_if_t<is_eigen_mat_v<T>()>* = nullptr>
  constexpr int dim_dispatch_v() { return eigen_rows_v<T>(); }
  ///@}

  ///@{
  /// @brief Dispatch for STL container and Eigen matrix.
  ///
  /// When the input is an Eigen expression, it dispatches to the an Eigen
  /// matrix transformed from the input expression using corresponding nRows,
  /// nCols and scalar type. When the input is an STL container, it dispatches
  /// to the input type itself.
  ///
  /// @warning No constraint is enforced on the input type being an STL
  /// container. So any non container, non Eigen type will also dispatch to
  /// itself.
  ///
  /// @param T: the input type.
  /// @return The dispatched container type.
  ///
  template<typename T, bool cond = is_eigen_v<T>()>
  struct container_dispatch: public std::conditional<cond,eigen_mat_t<T>,T> {};
  template<typename T> using container_dispatch_t =
    typename container_dispatch<decay_t<T> >::type;
  ///@}


  ///@ingroup group_meta
  /// @brief Dispatchers for arithmetic marks for marked point patterns
  /// and prcoesses.
  ///
  /// For 1-dimensional case, it dispatches to the scalar type itself. For
  /// dimension > 1, it dispatches to an Eigen Dim x 1 point (fix-sized vec).
  ///
  /// @param MScalr: the input mark scalar type.
  /// @param MDim: the mark's dimension.
  /// @return The dispatched point type.
  ///
  template<typename MScalr, int MDim> using pmark_dispatch_t =
    typename std::conditional
    <MDim==1, MScalr, Eigen::Matrix<MScalr,MDim,1> >::type;


  /// @ingroup group_meta
  ///
  /// @brief Dispatchers for arithmetic mark distribution for arithmetic
  /// marked point process.
  ///
  /// For 1-dimensional case, it dispatches to the input distribution itself.
  /// For dimension > 1, it dispatches to a `std::array` of the input
  /// distribution with size == Dim.
  ///
  /// @param Distr: the input distribution.
  /// @param MDim: the dimension of the marks.
  /// @return The dispatched mark distribution type.
  ///
  template<typename Distr, int MDim> using mdist_dispatch_t =
    typename std::conditional<MDim==1,Distr,std::array<Distr,MDim> >::type;


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Check for the type of an input intensity intensity.
  ///
  /// @param T: the input intensity type.
  /// @return
  /// - `is_scalr_inten_v()` returns true for an input arithmetic type or
  ///   StoGeo arithmetic intensity type.
  /// - `is_scalr_funct_v()` returns true for StoGeo functional intensity
  ///   types.
  /// - `is_intensity_v` returns true for either scalar intensity or
  ///   functional intensity.
  ///
  template<typename T> constexpr bool is_scalr_inten_v()
  {
    return stg_id_is_v<T,stg_ids::STOGEO_SCLR_INTEN>() ||
      is_arithmetic_v<decay_t<T> >();
  }

  template<typename T> constexpr bool is_funct_inten_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_FUNC_INTEN>(); }

  template<typename T> constexpr bool is_intensity_v()
  {
    return is_scalr_inten_v<T>() || is_arithmetic_v<T>() ||
      is_funct_inten_v<T>();
  }
  ///@}


  ///@{
  ///@ingroup group_meta
  ///
  /// @brief Check the category of the input point process type.
  ///
  /// @note A `boost::variant` containing **at least one** point process
  /// **dispatches also to true**. Notice that some old `boost::variant`
  /// implementations append `void_` types after variant's argument list,
  /// **if the AND logical is used, a variant will never dispatch to true
  /// even if all variant arguments are of point process types.
  ///
  /// @param T: the input point process type.
  /// @return
  /// - `is_simple_pp_v()` returns true for simple point process types.
  /// - `is_marked_pp_v()` returns true for marked point process types.
  /// - `is_stg_pprc_v()` returns true for any point process types.
  ///
  template<typename T> constexpr bool is_simple_pp_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_PPROC>(); }

  template<typename T> constexpr bool is_marked_pp_v()
  { return stg_id_is_v<T,stg_ids::STOGEO_MPROC>(); }

  template<typename T> constexpr bool is_simple_pp_variant_v()
  { return is_variant_of_v<T,stg_ids::STOGEO_PPROC>(); }

  template<typename T> constexpr bool is_marked_pp_variant_v()
  { return is_variant_of_v<T,stg_ids::STOGEO_MPROC>(); }

  template<typename T> constexpr bool is_stg_pproc_nonvariant_v()
  { return is_simple_pp_v<T>() || is_marked_pp_v<T>(); }

  template<typename T> constexpr bool is_stg_pproc_variant_v()
  {
    return is_variant_of_v<T,stg_ids::STOGEO_PPROC>() ||
      is_variant_of_v<T,stg_ids::STOGEO_MPROC>();
  }

  template<typename T> constexpr bool is_stg_pproc_v()
  { return is_stg_pproc_variant_v<T>() || is_stg_pproc_nonvariant_v<T>(); }
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Tags for scalar & functional intensity functions
  /// for point processes.
  ///
  struct scalr_inten_tag_t {};
  struct funct_inten_tag_t {};

  /// @brief Intensity function type dispatchers.
  ///
  template<typename T>
  struct inten_tag_dispatch: public std::conditional
  <is_arithmetic_v<T>(), scalr_inten_tag_t, funct_inten_tag_t> {};

  template<typename T>
  using inten_tag_dispatch_t =
    typename inten_tag_dispatch<decay_t<T> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Tags for simple & marked point processes.
  ///
  struct simple_pp_tag_t {};
  struct marked_pp_tag_t {};

  /// @brief Point process type dispatchers.
  ///
  template<typename T>
  struct pp_tag_dispatch: public std::conditional
  <is_simple_pp_v<T>(), simple_pp_tag_t, marked_pp_tag_t> {};

  template<typename T>
  using pp_tag_dispatch_t =
    typename pp_tag_dispatch<decay_t<T> >::type;
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Constant expression functor for test if any arithmetic is 0.
  ///
  /// @param __val: the input arithmetic value.
  /// @return True if __val is zero.
  ///
  struct is_zero_t
  {
    constexpr is_zero_t() {};
    template<typename T> constexpr bool operator()(T __val) const
    { return !__val; }
  };
  constexpr is_zero_t is_zero{};
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Constant expression functor for test if any arithmetic is not 0.
  ///
  /// @param __val: the input arithmetic value.
  /// @return True if __val is not zero.
  ///
  struct non_zero_t
  {
    constexpr non_zero_t() {};
    template<typename T> constexpr bool operator()(T __val) const
    { return __val; }
  };
  constexpr non_zero_t non_zero{};
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Constant expression functor returning `true` for anything.
  ///
  /// @param: an input.
  /// @return `true`.
  ///
  struct anything_t
  {
    constexpr anything_t() {};
    template<typename T> constexpr bool operator()(T) { return true; }
  };
  constexpr anything_t anything{};
  ///@}


  ///@{
  /// @ingroup group_meta
  ///
  /// @brief Constant expression functor returning `false` for anything.
  ///
  /// @param: an input.
  /// @return `false`.
  ///
  struct nothing_t
  {
    constexpr nothing_t() {};
    template<typename T> constexpr bool operator()(T) { return false; }
  };
  constexpr nothing_t nothing{};
  ///@}

}


#endif
