// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// defs.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jan  4 11:55:21 2016 Zhijin Li
// Last update Mon Sep  3 11:28:29 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_DEFS_HH
# define STOGEO_DEFS_HH

# include <cmath>
# include <vector>
# include <cassert>
# include <iostream>

# include "Eigen/Dense"
# include "Eigen/Cholesky"
# include "Eigen/Eigenvalues"

# include "boost/variant.hpp"
# include "boost/optional.hpp"


namespace stogeo
{
  /// @defgroup group_const StoGeo Constants
  ///
  /// @brief Constant expression objects in `StoGeo`.
  ///

  /// @ingroup group_const
  ///
  /// @brief Type def for the type of `variant` that `StoGeo` uses.
  ///
  /// @note In this version, `StoGeo` uses `boost::variant`.
  ///
  template<typename ...Args>
  using variant = typename boost::variant<Args...>;


  ///@{
  /// @ingroup group_const
  ///
  /// @brief Type def for the type of `optional` that `StoGeo` uses.
  ///
  /// @note In this version, `StoGeo` uses `boost::optional` with
  /// `boost::none_t` as `nullopt`.
  ///
  template<typename T> using optional = typename boost::optional<T>;
  using nullopt_t = boost::none_t;
  const nullopt_t nullopt = boost::none;
  ///@}


  /// @ingroup group_const
  ///
  /// @brief Constant expression for mathematical @f$ \pi @f$.
  ///
  constexpr double stg_pi =
    3.1415926535897931159979634685442;


  /// @ingroup group_const
  ///
  /// @brief Constant expression for @f$ \frac{1}{\sqrt{2\pi}} @f$.
  ///
  constexpr double one_over_sqrt2pi =
    0.398942280401432702863218082711682654917240143;


  ///@{
  /// @ingroup group_const
  ///
  /// @brief Constant expression for @f$ \frac{1}{\sqrt{2\pi}^{d}} @f$.
  /// with @f$ d @f$ being the desired dimension.
  ///
  template<int __d> constexpr double one_over_sqrt2pi_pow()
  { return std::pow(one_over_sqrt2pi,__d); }

  template<> constexpr double one_over_sqrt2pi_pow<1>()
  { return 0.398942280401432702863218082711682654917240143; }
  template<> constexpr double one_over_sqrt2pi_pow<2>()
  { return 0.159154943091895345608222100963757839053869247; }
  template<> constexpr double one_over_sqrt2pi_pow<3>()
  { return 0.063493635934240982843235201471543405205011368; }
  template<> constexpr double one_over_sqrt2pi_pow<4>()
  { return 0.025330295910584450791436239569520694203674793; }
  template<> constexpr double one_over_sqrt2pi_pow<5>()
  { return 0.010105326013811645816109496820445201592519879; }
  ///@}


  /// @ingroup group_const
  ///
  /// @brief Constant expression for @f$ \sqrt{2\pi} @f$.
  ///
  constexpr double sqrt2pi =
    2.506628274631000241612355239340104162693023681;


  ///@{
  /// @ingroup group_const
  ///
  /// @brief Constant expression for @f$ \sqrt{2\pi}^{d} @f$.
  /// with @f$ d @f$ being the desired dimension.
  ///
  template<int __d> constexpr double sqrt2pi_pow()
  { return std::pow(sqrt2pi,__d); }

  template<> constexpr double sqrt2pi_pow<1>()
  { return 2.506628274631000241612355239340104162693023681; }
  template<> constexpr double sqrt2pi_pow<2>()
  { return 6.283185307179585343817507236963137984275817871; }
  template<> constexpr double sqrt2pi_pow<3>()
  { return 15.74960994572241546052282501477748155593872070; }
  template<> constexpr double sqrt2pi_pow<4>()
  { return 39.47841760435741775836504530161619186401367188; }
  template<> constexpr double sqrt2pi_pow<5>()
  { return 98.95771780477254253582941601052880287170410156; }
  ///@}


  /// @ingroup group_const
  ///
  /// @brief `StoGeo` class identity collection.
  ///
  enum class stg_ids
    {
      STOGEO_POINT,
      STOGEO_VECTR,
      STOGEO_MATRX,
      STOGEO_DYMAT,
      STOGEO_PPATN,
      STOGEO_PPROC,
      STOGEO_MPROC,
      STOGEO_SHAPE,
      STOGEO_GGMOD,
      STOGEO_SPPAT,
      STOGEO_MKPAT,
      STOGEO_MPPAT,
      STOGEO_RNDVR,
      STOGEO_MSAIC,
      STOGEO_UNKNN,
      STOGEO_KERNL,
      STOGEO_SMPLR,
      STOGEO_SUPPR,
      STOGEO_SCLR_INTEN,
      STOGEO_FUNC_INTEN
    };


  /// @ingroup group_const
  ///
  /// @brief Constant tag for intensity function.
  ///
  struct inten_tag_t {}; constexpr inten_tag_t inten{};

  /// @ingroup group_const
  ///
  /// @brief Constant tag for inverse cumulative distribution function.
  ///
  struct icdf_tag_t {};  constexpr icdf_tag_t   icdf{};

  /// @ingroup group_const
  ///
  /// @brief Constant tag for probability distribution function.
  ///
  struct pdf_tag_t {};   constexpr pdf_tag_t     pdf{};

  /// @ingroup group_const
  ///
  /// @brief Constant tag for cumulative distribution function.
  ///
  struct cdf_tag_t {};   constexpr cdf_tag_t     cdf{};


  /// @ingroup group_const
  ///
  /// @brief Constant tags for Metropolis-Hasting MCMC sampling types.
  ///
  enum class mcmc { random_walk, independent, general };

  /// @ingroup group_const
  ///
  /// @brief Constant tags for Metropolis-Hasting MCMC sampling types.
  ///
  enum class sampler { inverse, reject, mh_mcmc };

  /// @ingroup group_const
  ///
  /// @brief Type constants for Matern Harcore processes.
  ///
  enum class mtn_hc { TypeI, TypeII, TypeIII };


  /// @defgroup group_traits StoGeo Property Traits
  ///
  /// @brief Properties traits for types used in `StoGeo` classes.
  ///

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief `StoGeo` default state type traits property.
    ///
    template<typename T> struct specs
    { static const stg_ids stg_id = stg_ids::STOGEO_UNKNN; };
  }

  /// @ingroup group_const
  ///
  /// @brief Tag that controls whether a random draw of a `StoGeo`
  /// random shape contains the shape center information.
  ///
  struct no_center_tag_t {};
  constexpr no_center_tag_t no_center;


  /// @ingroup group_const
  ///
  /// @brief Tags for point process realization with / without
  /// extra output.
  ///
  struct extra_tag_t {};
  constexpr extra_tag_t extra{};

  /// @ingroup group_const
  ///
  /// @brief Tags to specify to not perform **Bessel correction**
  /// for variance and covariance estimation.
  ///
  struct uncorrected_t {};
  constexpr uncorrected_t uncorrected;
}


#endif
