// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// core.hh for MO3
//
// Made by Zhijin LI
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 17 09:51:07 2015 Zhijin Li
// Last update Wed Feb 15 11:32:00 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_ROOTS_HH
# define STOGEO_ROOTS_HH

# include <string>
# include <exception>


namespace stogeo
{
  namespace internal__
  {
    /// The root class. Cannot be instantiated.
    template<typename EXACT>
    class root__
    {
    public:
      /// Static dispatches.
      EXACT& exact() { return static_cast<EXACT&>(*this); };
      const EXACT& exact() const { return static_cast<const EXACT&>(*this); };

    protected:
      /// Ctor is protected to prevent instantiation.
      constexpr root__() {};
    };

#ifdef STOGEO_ENABLE_INSTANCE_COUNT
    /// Counter class for ctor calls
    template<typename T>
    class call_count__
    {
    protected:
      // Ctors.
      call_count__() { ++_count; };
      call_count__(const call_count__&) { ++_count; };
      ~call_count__() {};

      static int count() { return _count; }

    private:
      static int _count;
      void operator delete(void*); //< Prohibit ptr instantiation w/ new.
    };
    template<typename EXACT> int call_count__<EXACT>::_count = 0;
#endif

  } //!internal__

  namespace err
  {
    /// Exception class for error handling.
    struct exception : public std::exception
    {
      explicit exception(std::string msg = "") noexcept:
        std::exception(),_msg(msg) {}
      virtual ~exception() noexcept {}
      const char* what() const noexcept override { return _msg.c_str(); }

    private:
      std::string _msg;
    };
  } //!err

} //!stogeo


#endif //!STOGEO_ROOTS_HH
