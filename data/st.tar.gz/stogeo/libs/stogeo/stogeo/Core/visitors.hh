// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// visitors.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jan  4 12:01:26 2016 Zhijin Li
// Last update Mon Sep  3 11:53:37 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_VISITORS_HH
# define STOGEO_VISITORS_HH

# include "roots.hh"
# include "meta.hh"
# include "boost/variant.hpp"


namespace stogeo
{
  namespace var
  {

    /// @brief Visitor: determine if a variant is a r.v.
    ///
    /// Expacts a variant that is either a random va or a deterministic
    /// value. Works on all these types. Not a template.
    ///
    /// @return: if the variant holds a r.v. or not.
    ///
    struct is_rnd_var: public boost::static_visitor<bool>
    {
      template<typename VT,
               enable_if_t<is_arithmetic_v<decay_t<VT> >()>* = nullptr>
      bool operator()(VT &&) const { return false; }

      template<typename VT, enable_if_t<is_stg_distr_v<VT>()>* = nullptr>
      bool operator()(VT &&) const { return true; }
    };

    /// @brief Visitor: reset a variant of r.v.
    ///
    /// Internally call the `reset_state` function of the random
    /// vairbale. Does nothing if a deterministic value is encountered.
    ///
    struct reset_rv: public boost::static_visitor<void>
    {
      template<typename VT,
               enable_if_t<is_arithmetic_v<decay_t<VT> >()>* = nullptr>
      void operator()(VT &&) const {}

      template<typename VT, enable_if_t<is_stg_distr_v<VT>()>* = nullptr>
      void operator()(VT &&rv) const { rv.reset_state(); }
    };

    /// @brief Visitor: get the curr held value of the variant.
    ///
    /// Similar to boost::get, with static assert. Expects a variant that
    /// is either arithmetic or not. Works only on arithmetic types. The
    /// template arg: the value type.
    ///
    /// @return: the held value.
    ///
    template<typename T> struct get_val: public boost::static_visitor<T>
    {
      static_assert(is_arithmetic_v<T>(),
                    "ERROR: GET_VAL NOT PASSED ARITHMETIC TYPE.");

      T operator()(const T &val) const { return val; }

      template<typename PT,
               enable_if_t<!is_arithmetic_v<decay_t<PT> >()>* = nullptr>
      T operator()(PT &&) const
      { throw err::exception(std::string("err: get_val expects non-rand.\n")); }
    };

    /// @brief Visitor: draw a realization of a r.v.
    ///
    /// Expects a variant that is either a r.v. or a deterministic val
    /// works only when it's an r.v. Template arg: the value type.
    ///
    /// @return: the drawn random value.
    ///
    template<typename T> struct draw_val: public boost::static_visitor<T>
    {
      template<typename VT, enable_if_t<!is_stg_distr_v<VT>()>* = nullptr>
      T operator()(VT &&) const
      { throw err::exception(std::string("err: draw_val expects randvar.\n")); }

      template<typename VT, enable_if_t<is_stg_distr_v<VT>()>* = nullptr>
      T operator()(VT &&operand) const { return operand.draw(); }
    };

    /// @brief Visitor: compute volume of a shape.
    ///
    /// Expects a variant that is a geometric shape. Works on all shape
    /// having the volume() interface. Template arg: the comp value type.
    ///
    /// @return: the computed volume.
    ///
    template<typename T> struct comp_volume: public boost::static_visitor<T>
    {
      template<typename GT> T operator()(GT &&operand) const
      {
        static_assert(is_stg_shape_v<GT>(), "ERROR: VOLUME EXPECTS A SHAPE.");
        return operand.volume();
      }
    };

    /// @brief Visitor: get the bounding box of a shape.
    ///
    /// Expects a variant that is a geometric shape. Works on all shape
    /// having the bounding_box() interface. Template arg: bound box type.
    ///
    /// @return: the bounding box of specified type T.
    ///
    template<typename T>
    struct get_bounding_box: public boost::static_visitor<T>
    {
      template<typename GT> T operator()(GT &&operand) const
      {
        static_assert(is_stg_shape_v<GT>(), "ERROR: EXPECTS A SHAPE.");
        return operand.bounding_box();
      }
    };

    /// @brief Visitor: check if a geometry is random.
    ///
    /// Expects a variant that is a geometric shape. Works on all shape
    /// having the is_random() interface. Not a template.
    ///
    /// @return bool: if the shape is random or not.
    ///
    struct is_rnd_shape: public boost::static_visitor<bool>
    {
      template<typename GT> bool operator()(GT &&operand) const
      {
        static_assert(is_stg_shape_v<GT>(), "ERROR: EXPECTS A SHAPE.");
        return operand.is_random();
      }
    };

    /// @brief Visitor: offer the interface of inside_test for shapes.
    ///
    /// Expects a variant that is a geometric shape. Works on all shape
    /// having the inside_test() interface. Template args: the val type
    /// and the dimension Dim.
    ///
    /// @param pt: the input pt to test.
    ///
    template<typename T, int Dim>
    struct inside_test: public boost::static_visitor<bool>
    {
      template<typename Point>
      inside_test(Point &&pt) : _pt(std::forward<Point>(pt)) {}

      template<typename GT> bool operator()(GT &&operand) const
      {
        static_assert(is_stg_shape_v<GT>(), "ERROR: EXPECTS A SHAPE.");
        return operand.inside_test(_pt);
      }

    private:
      Eigen::Ref<Eigen::Matrix<T,Dim,1> > _pt;
    };

    ///@{
    /// @brief Variant sampler object to draw entities from
    /// `StoGeo` random objects.
    ///

    /// @brief Generic sampler for variants of `StoGeo` simple point
    /// processes.
    ///
    /// This visitor applies to a point process or a variant. It
    /// draws samples into a point pattern structure and returns it.
    ///
    /// @param Window: the observation window type.
    /// @param Output: the output point pattern type. A
    /// `SimplePointPattern` or a `MarkedPointPattern`.
    ///
    // template<typename Window, typename Output>
    // struct spps_sampler_ret: boost::static_visitor<Output>
    // {
    //   spps_sampler_ret(const Window &window): _window( window ) {}

    //   template<typename Var> Output operator()(const Var &operand) const
    //   {
    //     static_assert
    //       (stg_dim_v<Output>() == stg_dim_v<Window>() &&
    //        stg_dim_v<Output>() == stg_dim_v<Var>(),
    //        "ERR: OUTPUT OR WINDOW MISMATCH THE VARIANT'S DIMENSION.");
    //     return operand.draw(_window);
    //   }

    // private:
    //   const Window &_window;
    // };

    /// @brief Generic sampler for variants of `StoGeo` point
    /// processes.
    ///
    /// This visitor applies to a simple point process and draws
    /// samples into a container structure.
    ///
    /// @param Window: the observation window type.
    /// @param Output: the output container structure. An Eigen
    /// Matrix.
    ///
    template<typename Window, typename Output>
    struct spps_sampler: boost::static_visitor<void>
    {
      spps_sampler(const Window &window, Output &output):
        _window( window ), _output( output ) {}

      template<typename Var> void operator()(const Var &operand) const
      {
        static_assert
          (dim_dispatch_v<Output>() == stg_dim_v<Window>() &&
           dim_dispatch_v<Output>() == stg_dim_v<Var>(),
           "ERR: OUTPUT OR WINDOW MISMATCH THE VARIANT'S DIMENSION.");
        operand.draw(_output, _window);
      }

    private:
      const Window &_window;
      Output       &_output;
    };

    /// @brief Generic sampler for variants of `StoGeo` marked point
    /// processes.
    ///
    /// This visitor applies to a marked point process or a variant
    /// and draws the points and marks into separate Eigen structures.
    /// For geometric marked point processes, the **vector
    /// representation** of the marks will be drawn.
    ///
    /// @param Window: the observation window type.
    /// @param PtsOut: the output Eigen structure for points. An Eigen
    /// Matrix.
    /// @param MksOut: the output Eigen structure for marks. An Eigen
    /// Matrix.
    ///
    template<typename Window, typename PtsOut, typename MksOut>
    struct mpps_sampler: boost::static_visitor<void>
    {
      mpps_sampler(const Window &window, PtsOut &pts, MksOut &mks):
        _window( window ), _pts( pts ), _mks( mks ) {}

      template<typename Var> void operator()(const Var &operand) const
      {
        static_assert
          (dim_dispatch_v<PtsOut>() == stg_dim_v<Window>() &&
           dim_dispatch_v<PtsOut>() == stg_dim_v<Var>(),
           "ERR: OUTPUT OR WINDOW MISMATCH THE VARIANT'S DIMENSION.");
        operand.draw(_pts, _mks, _window);
      }

    private:
      const Window &_window;
      PtsOut       &_pts;
      MksOut       &_mks;
    };

    template<typename T, bool is_arith=is_arithmetic_v<T>()>
    struct rndvar_sampler {};

    /// @brief Generic sampler for variants of `StoGeo` random variable.
    ///
    /// This visitor applies to a random variable or a deterministic
    /// scalar. For a deterministic scalar input, the return same
    /// scalar will be **copied and returned**. For a random variable
    /// input, a random value will be drawn. A compilation will occur if
    /// the input is neither a scalar nor a random variable.
    ///
    /// @param T: the scalar value type.
    ///
    template<typename T>
    struct rndvar_sampler<T,true>: public boost::static_visitor<T>
    {
      template<typename Var, enable_if_t<is_stg_distr_v<Var>()>* = nullptr>
      T operator()(Var &&operand) const { return operand.draw(); }

      template<typename Var, enable_if_t<is_arithmetic_v<Var>()>* = nullptr>
      T operator()(Var &&operand) const { return operand; }

      template<typename Var, enable_if_all_t
               <!is_arithmetic_v<Var>(), !is_stg_distr_v<Var>()>* = nullptr>
      T operator()(Var &&operand) const
      {
        static_assert(is_arithmetic_v<Var>() || is_stg_distr_v<Var>(),
                      "ERR: THE VARIANT MUST BE SCALAR OR RANDOM VAR.");
        return -1;
      }
    };
    ///@}

    /// @brief Generic sampler for variants of `StoGeo` random variable.
    ///
    /// This visitor applies to a random variable or a deterministic
    /// scalar. The constructor takes an output container as input and
    /// samples values into it. For a deterministic scalar input, the
    /// output will be filled with the same scalar value. For a random
    /// variable input, the output will be filled with random values
    /// sampled from the random variable. A compilation will occur if
    /// the input is neither a scalar nor a random variable.
    ///
    /// @param T: the scalar value type.
    /// @param Output: the output container structure. Can be any
    /// type that that draw method accepts, f.ex, an Eigen Matrix.
    ///
    template<typename Output>
    struct rndvar_sampler<Output,false>: public boost::static_visitor<void>
    {
      rndvar_sampler(Output &output): _output( output ) {}

      template<typename Var, enable_if_t<is_stg_distr_v<Var>()>* = nullptr>
      void operator()(Var &&operand) const { operand.draw(_output); }

      template<typename Var, enable_if_t<is_arithmetic_v<Var>()>* = nullptr>
      void operator()(Var &&operand) const
      {
        static_assert(is_eigen_v<Output>(),
                      "ERROR: EXPECTS AN EIGEN STRUCTURE AS INPUT.");
#pragma omp parallel for collapse(2)
        for(int __m = 0; __m < _output.rows(); __m++)
          for(int __n = 0; __n < _output.cols(); __n++)
            _output(__m, __n) = operand;
      }

      template<typename Var, enable_if_all_t
               <!is_arithmetic_v<Var>(), !is_stg_distr_v<Var>()>* = nullptr>
      void operator()(Var &&operand) const
      {
        static_assert(is_arithmetic_v<Var>() || is_stg_distr_v<Var>(),
                      "ERR: THE VARIANT MUST BE SCALAR OR RANDOM VAR.");
      }

    private:
      Output       &_output;
    };

    /// @brief Generic sampler for variants of `StoGeo` shapes.
    ///
    /// This visitor applies to a `StoGeo` random or deterministic
    /// shape. The constructor takes an output container as input and
    /// samples values into it. For a deterministic scalar input, the
    /// output will be filled with the same scalar value. For a random
    /// variable input, the output will be filled with random values
    /// sampled from the random variable. A compilation will occur if
    /// the input is neither a scalar nor a random variable.
    ///
    /// @param T: the scalar value type.
    /// @param Output: the output container structure. Can be any
    /// type that that draw method accepts, f.ex, an Eigen Matrix.
    ///
//     template<typename Output>
//     struct rndvar_sampler<Output,false>: public boost::static_visitor<void>
//     {
//       rndvar_sampler(Output &output): _output( output ) {}

//       template<typename Var, enable_if_t<is_stg_distr_v<Var>()>* = nullptr>
//       void operator()(Var &&operand) const { operand.draw(_output); }

//       template<typename Var, enable_if_t<is_arithmetic_v<Var>()>* = nullptr>
//       void operator()(Var &&operand) const
//       {
//         static_assert(is_eigen_v<Output>(),
//                       "ERROR: EXPECTS AN EIGEN STRUCTURE AS INPUT.");
// #pragma omp parallel for collapse(2)
//         for(int __m = 0; __m < _output.rows(); __m++)
//           for(int __n = 0; __n < _output.cols(); __n++)
//             _output(__m, __n) = operand;
//       }

//       template<typename Var, enable_if_all_t
//                <!is_arithmetic_v<Var>(), !is_stg_distr_v<Var>()>* = nullptr>
//       void operator()(Var &&operand) const
//       {
//         static_assert(is_arithmetic_v<Var>() || is_stg_distr_v<Var>(),
//                       "ERR: THE VARIANT MUST BE SCALAR OR RANDOM VAR.");
//       }

//     private:
//       Output       &_output;
//     };
    ///@}

  } //!var


  namespace utils
  {
    template<typename Var, typename Shape, typename ...Outs,
             enable_if_t<not_empty<Outs...>()>* = nullptr>
    void sample_var(Var &&var, Shape &&window, Outs &&...outs)
    {
      static_assert(is_stg_pproc_variant_v<Var>(),
                    "ERR: EXPECT A SIMPLE OR MARKED POINT PROCESS VARIANT.");
      using __sampler_t = conditional_t
        <is_simple_pp_variant_v<Var>(),
         typename var::spps_sampler<decay_t<Shape>, decay_t<Outs>...>,
         typename var::mpps_sampler<decay_t<Shape>, decay_t<Outs>...> >;

      boost::apply_visitor
        (__sampler_t
         (std::forward<Shape>(window), std::forward<Outs>(outs)...),
         std::forward<Var>(var));
    }

    /// @brief Generic sampler for variants of `StoGeo` simple point
    /// processes.
    ///
    /// This visitor applies to a point process or a variant. It
    /// draws samples into a point pattern structure and returns it.
    ///
    /// @param Window: the observation window type.
    /// @param Output: the output point pattern type. A
    /// `SimplePointPattern` or a `MarkedPointPattern`.
    ///
    template<typename Pattern, typename Var, typename Shape,
             enable_if_all_t<is_stg_pproc_variant_v<Var>(),
                             is_stg_shape_v<Shape>()>* = nullptr>
    Pattern sample_var(Var &&var, Shape &&window)
    {
      return boost::apply_visitor
        (var::spps_sampler<decay_t<Shape>,Pattern>
         (std::forward<Shape>(window)), std::forward<Var>(var));
    }

    template<typename Var, typename Output,
             enable_if_all_t<is_variant_of_v<Var,stg_ids::STOGEO_RNDVR>(),
                             !is_stg_shape_v<Output>()>* = nullptr>
    void sample_var(Var &&var, Output &output)
    {
      boost::apply_visitor
        (var::rndvar_sampler<Output>(output), std::forward<Var>(var));
    }

    template<typename Scalar, typename Var,
             enable_if_t<is_variant_of_v<Var,stg_ids::STOGEO_RNDVR>()>* = nullptr>
    Scalar sample_var(Var &&var)
    {
      return boost::apply_visitor
        (var::rndvar_sampler<Scalar>(), std::forward<Var>(var));
    }

    template<typename Output, typename Var, typename ...Sizes,
             enable_if_all_t<is_variant_of_v<Var,stg_ids::STOGEO_RNDVR>(),
                             not_empty<Sizes...>()>* = nullptr>
    Output sample_var(Var &&var, Sizes ...sizes)
    {
      Output __result(sizes...);
      boost::apply_visitor
        (var::rndvar_sampler<Output>(__result), std::forward<Var>(var));
      return __result;
    }

  } //!utils

} //!stogeo


#endif //!STOGEO_VISITORS_HH
