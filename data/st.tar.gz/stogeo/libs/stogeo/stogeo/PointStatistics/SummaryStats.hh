// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// SummaryStats.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jul 25 18:29:12 2016 Zhijin Li
// Last update Mon Jul 25 18:29:13 2016 Zhijin Li
// ---------------------------------------------------------------------------
