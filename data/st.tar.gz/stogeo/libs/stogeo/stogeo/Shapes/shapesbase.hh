// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// shapesbase.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 10:58:07 2015 Zhijin Li
// Last update Wed Dec  6 18:16:22 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_SHAPESBASE_HH
# define STOGEO_SHAPESBASE_HH

# include "Eigen/StdVector"
# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "../Utilities/computations.hh"
# include "../Utilities/mipp_helpers.hh"


namespace stogeo
{

  /// @defgroup group_shape Geometric Primitives
  ///
  /// @brief Classes for geometric primitive objects such as
  /// * `stogeo::shapes::Box`
  /// * `stogeo::shapes::Sphere`
  /// * `stogeo::shapes::Ellipsoid`
  /// * `stogeo::shapes::Rectangle`
  ///

  /// @ingroup group_shape
  namespace shapes
  {
    namespace abstract
    {

      /// @ingroup group_shape
      ///
      /// @brief The base class for all geometric primitives.
      ///
      /// @param EXACT: type of derived class inheriting it.
      /// @param Dim: the dimension.
      ///
      template<typename EXACT, int Dim>
      class shapesbase: public internal__::root__<EXACT>
      {
      public:
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        using specs_t =      traits::specs<EXACT>;
        using scalr_t = typename specs_t::scalr_t;
        using param_t = typename specs_t::param_t;
        using varin_t = typename specs_t::varin_t;
        using point_t = typename specs_t::point_t;
        using vectr_t = typename specs_t::vectr_t;
        using matrx_t = typename specs_t::matrx_t;
        using rotmt_t = typename specs_t::rotmt_t;
        using slice_t = typename specs_t::slice_t;
        using bound_t = typename specs_t::bound_t;
        using parvc_t = typename specs_t::parvc_t;
        using vpack_t = typename specs_t::vpack_t;
        using alloc_t = typename specs_t::alloc_t;
        using internal__::   root__<EXACT>::exact;

        static constexpr int n_params = specs_t::n_params;

      protected:

        //------- Interfaces.

        /// @brief Get the center of a shape.
        ///
        /// @return A const-ref to the center, an Eigen vector.
        ///
        const point_t& centre() const { return _centre; }

        /// @brief Get the params vector of a shape.
        ///
        /// @return A const-ref to the param vector, an Eigen vector,
        /// or **a scalar if there's only one parameter**.
        ///
        const parvc_t& param() const { return exact().param_impl(); }

        /// @brief Get current parameter variants.
        ///
        /// @return A const reference to the parameter variants of
        /// the current shape.
        ///
        const varin_t& param_var() const { return exact().param_var_impl(); }

        /// @brief Get current parameter variants. Non-const accessor.
        ///
        /// @return A non-const reference to the parameter variants of
        /// the current shape.
        ///
        varin_t& param_var() { return exact().param_var_impl(); }

        /// @brief Get the current rotation matrix.
        ///
        /// @return A const-ref to the rotation matrix, an Eigen Dim x
        /// Dim fixed size matrix.
        ///
        const rotmt_t& rot_mat() const { return exact().rot_mat_impl(); }

        /// @brief Get a vector reprez of the shape.
        ///
        /// @return An Eigen column vector containing the shape
        /// centre and parameters.
        ///
        vpack_t vpack() const { return exact().vpack_impl(); }

        /// @brief Compute shape volume.
        ///
        /// @return The computed volume.
        ///
        scalr_t volume() const { return exact().volume_impl(); }

        /// @brief Check if the current instance is in a parameter-
        /// valid state.
        ///
        /// @return True if all shape parameters are initialized.
        ///
        bool ready() const { return exact().ready_impl(); };

        /// @brief Check if the shape is random.
        ///
        /// @return True if current shape is random.
        ///
        bool is_random() const { return exact().is_random_impl(); }

        /// @brief Compute the bounding box of the shape.
        ///
        /// The bounding box is an Eigen Dim x 2 matrix. It is a fixed
        /// size matrix. First column is the inner-bottom-left corner
        /// of the bounding box. Second column is the outer-upper-right
        /// corner of the bounding box. i.e. a bounding box is a box
        /// defined by two corner positions.
        ///
        /// @return The computed bounding box. An Eigen Dim x 2 matrix.
        ///
        bound_t bounding_box() const { return exact().bounding_box_impl(); }

        /// @brief The maximum radius of a sphere enclosing completely
        /// the shape.
        ///
        /// @return The computed enclosing radius.
        ///
        scalr_t enclosing_radius() const
        { return exact().enclosing_radius_impl(); }

        ///@{
        /// @brief Draw a shape realization in vector form.
        ///
        /// @note This version returns an Eigen vector that contains
        /// the vectorized form of a randomly drawn shape. The
        /// center is the same as the input.
        ///
        /// @param: the desired centre position.
        /// @return A vector representation of the drawn shape.
        ///
        template<typename PT, int dummy=n_params,
                 enable_if_t<dummy!=1>* = nullptr>
        vpack_t draw(PT &&centre) const;

        template<typename PT, int dummy=n_params,
                 enable_if_t<dummy==1>* = nullptr>
        vpack_t draw(PT &&centre) const;
        ///@}

        /// @brief Draw a shape realization in vector form.
        ///
        /// @note This version returns an Eigen vector that contains
        /// the vectorized form of a randomly drawn shape. The
        /// center is the same as that of the current shape.
        ///
        /// @return A vector representation of the drawn shape.
        ///
        vpack_t draw() const { return exact().draw(_centre); }

        ///@{
        /// @brief Draw a shape realization in vector form.
        ///
        /// @note This version discard the info of the shape center.
        /// The return type is an Eigen vector that contains only the
        /// shape parameters.
        ///
        /// @param tag: use `stogeo::no_center` to indicate
        /// the use of this version.
        /// @return An Eigen vector that contains randomly drawn shape
        /// parameters, without the center.
        ///
        template<int dummy=n_params, enable_if_t<dummy != 1>* = nullptr>
        parvc_t draw(no_center_tag_t tag) const;

        template<int dummy=n_params, enable_if_t<dummy == 1>* = nullptr>
        scalr_t draw(no_center_tag_t tag) const;
        ///@}

        /// @brief Alter the curr state of the shape.
        ///
        /// @note This has no effect if current instance is not random.
        ///
        /// @return `*this`.
        ///
        EXACT& roll() { return exact().roll_impl(); };

        /// @brief Reset the internal state of the shape.
        ///
        /// Together with the `stogeo::utils::reset_shared_engine()`
        /// function, they can be used to reproduce the same simulation
        /// results.
        ///
        EXACT& reset_state() { return exact().reset_state_impl(); };

        /// @brief Discretization under given reolution.
        ///
        /// Produces an Image of dimension Dim. Discretization is done inside
        /// shape's bounding box: ImSize = BoundSize/resolution. Elems inside
        /// the shape filled with in_val, ouside with out_val. Needs explicit
        /// template argument if neither in_val nor out_val specified.
        ///
        /// @param resolution: desired resolution: Eigen Dim x 1 vec.
        /// @param in_val: value assigned to elems inside the shape.
        /// @param out_val: value assigned to elems outside the shape.
        /// @return A cmn::Image of dimension Dim.
        ///
        template<typename VT, typename PT,
                 typename = enable_if_t<is_eigen_v<PT>()> >
        cmn_img_t<VT,Dim> discrete(PT &&, VT in_val=0, VT out_val=1) const;

        /// @brief Discretization under given reolution.
        ///
        /// Produces an Image of dimension Dim. Discretization is done inside
        /// shape's bounding box: ImSize = BoundSize/resolution. Elems inside
        /// the shape filled with in_val, ouside with out_val. Needs explicit
        /// template argument if neither in_val nor out_val specified.
        ///
        /// @param dom: input domain where the discrete field lies in.
        /// @param in_val: value assigned to elems inside the shape.
        /// @param out_val: value assigned to elems outside the shape.
        /// @return A cmn::Image of dimension Dim.
        ///
        template<typename VT>
        cmn_img_t<VT,Dim> discrete(const cmn_domain_t<Dim> &,
                                   VT in_val=0, VT out_val=1) const;

        ///@{
        /// @brief Move the center of a shape to a specified position.
        ///
        /// @param pt: the new center.
        /// @return `*this`;
        ///
        EXACT& move_to(const point_t &pt) & { _centre = pt; return exact(); };

        EXACT&& move_to(const point_t &pt) &&
        { _centre = pt; return std::move(exact()); };
        ///}

        /// @brief Rotate the current shape.
        ///
        /// Rotate with one angle for 2D case and three angles for 3D
        /// case. Rotation is **intrinsic, in reversed params order**.
        ///
        /// @param angles: angles of the rotation.
        /// @return `*this`.
        ///
        template<typename... PTS> EXACT& rotate(PTS &&...angles) &
        { return exact().rotate_impl(std::forward<PTS>(angles)...); }

        /// @brief Test if a point is inside the current shape.
        ///
        /// @param pt: the input point.
        /// @return True if the point is inside the shape.
        ///
        template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                              eigen_rows_v<PT>()==Dim,
                                              eigen_cols_v<PT>()==1>* = nullptr>
        bool inside_test(PT &&) const;

        /// @brief Test if points(columns) of a matrix are inside the
        /// shape.
        ///
        /// @param mat: the input matrix, must be column ordered, with
        /// each column representing a point to test.
        /// @return A logical vector storing the test results for
        /// each point.
        ///
        template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                              eigen_rows_v<MT>()==Dim,
                                              eigen_cols_v<MT>()!=1>* = nullptr>
        slice_t inside_test(MT &&) const;

        /// @brief Test if points(columns) of a matrix are inside the
        /// shape.
        ///
        /// @param mat: the input matrix, must be column ordered, with
        /// each column representing a point to test.
        /// @param lv: the logical vector to store the test results for
        /// each point.
        ///
        template<typename MT, enable_if_all_t
                 <is_eigen_v<MT>(), eigen_rows_v<MT>()==Dim>* = nullptr>
        void inside_test(MT &&, slice_t &) const;

        //------- Ctors & dtor.

        /// @brief Ctor.
        shapesbase() = default;

        /// @brief Ctor.
        ///
        /// @param centre: the shape centre.
        ///
        template<typename PT, enable_if_all_t
                 <is_eigen_v<PT>(), eigen_rows_v<PT>()==Dim>* = nullptr>
        shapesbase(PT &&centre): _centre(std::forward<PT>(centre)) {};

        /// @brief Default copy ctors.
        shapesbase(const shapesbase &) = default;

        /// @brief Default move ctor.
        shapesbase(shapesbase &&) = default;

        /// @brief Default copy assignment operator.
        shapesbase& operator=(const shapesbase &) = default;

        /// @brief Default move assignment operator.
        shapesbase& operator=(shapesbase &&) = default;

        //------- Class attributes.

        point_t _centre; //:< The shape center.
      };

    }
  }
}


# include "shapesbase.hxx"
#endif
