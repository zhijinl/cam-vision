// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Ellipsoid.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 14:37:07 2015 Zhijin Li
// Last update Thu Oct 12 19:11:37 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_ELLIPSOID_HH
# define STOGEO_ELLIPSOID_HH

# include "shapesbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace shapes { template<typename T, int Dim> class Ellipsoid; }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::shapes::Ellipsoid`
    /// class.
    ///
    template<typename T, int Dim> struct specs<shapes::Ellipsoid<T,Dim> >
    {
      static constexpr int dim      =                                 Dim;
      static constexpr int n_params =                             3*Dim-3;
      static const stg_ids stg_id   =               stg_ids::STOGEO_SHAPE;
      typedef variant<T, rnd::RUniform<T>,
                             rnd::Gaussian<T> >                   param_t;
      typedef T                                                   scalr_t;
      typedef std::array<param_t,n_params>                        varin_t;
      typedef Eigen::Matrix<T,Dim,1>                              point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>                   vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>                 matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>                slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic>      dymmt_t;
      typedef Eigen::Matrix<T,Dim,Dim>                            rotmt_t;
      typedef Eigen::Matrix<T,Dim,2>                              bound_t;
      typedef Eigen::Matrix<T,3*Dim-3,1>                          parvc_t;
      typedef Eigen::Matrix<T,3*Dim-3,Eigen::Dynamic>             parmt_t;
      typedef Eigen::Matrix<T,4*Dim-3,1>                          vpack_t;
      typedef Eigen::Matrix<T,4*Dim-3,Eigen::Dynamic>             mpack_t;
      typedef Eigen::aligned_allocator<shapes::Ellipsoid<T,Dim> > alloc_t;
    };
  }

  /// @ingroup group_shape
  namespace shapes
  {

    /// @ingroup group_shape
    ///
    /// @brief Class for an `Ellipsoid` in arbitrary dimension.
    ///
    /// @param T: the scalar typeused for floating-point computations.
    /// @param Dim: the dimension.
    ///
    template<typename T, int Dim> class Ellipsoid
      : public abstract::shapesbase<Ellipsoid<T,Dim>,Dim>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t =          Ellipsoid<T,Dim>;
      using specs_t =    traits::specs<exact_t>;
      using param_t = typename specs_t::param_t;
      using scalr_t = typename specs_t::scalr_t;
      using varin_t = typename specs_t::varin_t;
      using point_t = typename specs_t::point_t;
      using vectr_t = typename specs_t::vectr_t;
      using matrx_t = typename specs_t::matrx_t;
      using slice_t = typename specs_t::slice_t;
      using rotmt_t = typename specs_t::rotmt_t;
      using dymat_t = typename specs_t::dymmt_t;
      using bound_t = typename specs_t::bound_t;
      using parvc_t = typename specs_t::parvc_t;
      using vpack_t = typename specs_t::vpack_t;
      using mpack_t = typename specs_t::mpack_t;
      using parmt_t = typename specs_t::parmt_t;
      using parnt_t = abstract::shapesbase<Ellipsoid<T,Dim>,Dim>;

      friend parnt_t;
      using parnt_t::            draw;
      using parnt_t::            roll;
      using parnt_t::           ready;
      using parnt_t::           vpack;
      using parnt_t::           param;
      using parnt_t::          centre;
      using parnt_t::          rotate;
      using parnt_t::          volume;
      using parnt_t::         move_to;
      using parnt_t::         rot_mat;
      using parnt_t::        discrete;
      using parnt_t::       param_var;
      using parnt_t::       is_random;
      using parnt_t::     reset_state;
      using parnt_t::     inside_test;
      using parnt_t::    bounding_box;
      using parnt_t::enclosing_radius;

      static constexpr int dim      =     Dim;
      static constexpr int n_params = 3*Dim-3;
      static constexpr int n_angles = 2*Dim-3;

      /// @brief Default ctor. Initialize to a unit sphere.
      Ellipsoid();

      /// @brief Ctor 1. Taking a center point and variadic random
      /// or deterministic parameters.
      ///
      /// Initialized w centre coords and separate params.
      /// @param centre: the centre point, Eigen Dim x 1.
      /// @param params: vairadic ellip params. La, Lb, Lc,
      /// and three angles. Can be deterministic or r.v.
      ///
      template<typename... PTS, typename PT,
               typename = enable_if_all_t<is_eigen_v<PT>(),
                                          eigen_rows_v<PT>()==Dim,
                                          sizeof...(PTS) == (3*Dim-3)> >
      Ellipsoid(PT &&centre, PTS &&...params);

      /// @brief Ctor 2. Taking a center point and deterministic
      /// Eigen vector.
      ///
      /// Initialized w centre coords and params vector.
      /// All values must be deterministic.
      /// @param centre: the centre point, Eigen Dim x 1.
      /// @param par_vec: an Eigen 3*Dim-3 x 1 vec with
      /// all ellipsoid params.
      ///
      template<typename PT, typename PVT,
               typename = enable_if_all_t<is_eigen_v<PT>(),
                                          is_eigen_v<PVT>(),
                                          eigen_rows_v<PT>()==Dim,
                                          eigen_rows_v<PVT>()==(3*Dim-3)> >
      Ellipsoid(PT &&centre, PVT &&par_vec);

      /// @brief Ctor 3. Taking only variadic deterministic or
      /// random parameters.
      ///
      /// Initialized only w/ separate params. Centre = o.
      /// @params args: variadic ellip params. La, Lb, Lc,
      /// and three angles. Can be deterministic or r.v.
      ///
      template<typename VT, typename... PTS,
               typename = enable_if_all_t<!is_eigen_v<VT>(),
                                          sizeof...(PTS)==(3*Dim-4)> >
      Ellipsoid(VT &&first, PTS &&...rest):
        Ellipsoid(point_t::Zero(),std::forward<VT>(first),
                  std::forward<PTS>(rest)...) {};
      // Call ctor 1.

      /// @brief Ctor 4.
      /// Initialized w centre half lengths & orientations.
      /// All values must be deterministic.
      /// @param centre: the centre point, Eigen Dim x 1.
      /// @param halfs: half axis lengths, Eigen Dim x 1.
      /// @param angles: arithmetic when Dim == 2. Eigen
      /// Dim x 1 when Dim == 3.
      ///
      template<typename PT, typename Halfs, typename Angles,
               typename = enable_if_all_t<eigen_rows_v<PT>()==Dim,
                                          eigen_rows_v<Halfs>()==Dim>,
               typename = enable_if_any_t
               <(Dim==2 && is_arithmetic_v<decay_t<Angles> >()),
                (Dim==3 && eigen_rows_v<Angles>()==3)> >
      Ellipsoid(PT &&centre, Halfs &&halfs, Angles &&angles):
        Ellipsoid(std::forward<PT>(centre),
                  (parvc_t() << std::forward<Halfs>(halfs),
                   std::forward<Angles>(angles)).finished()) {};
      // Call ctor 2.

      /// @brief Ctor 5. Taking an Eigen deterministic vector
      /// containing only parameters not center point.
      ///
      /// Initialized only w/ params vector. Centre = o.
      /// All values must be deterministic.
      /// @param vec: an Eigen 3*Dim-3 x 1 vec with all
      /// ellipsoid params.
      ///
      template<typename PVT, enable_if_all_t<is_eigen_v<PVT>(),
                                             eigen_rows_v<PVT>()==(3*Dim-3)>*
               = nullptr>
      Ellipsoid(PVT &&vec):
        Ellipsoid(point_t::Zero(),std::forward<PVT>(vec)) {};
      // Call ctor 2.

      /// @brief Ctor 6. Taking an Eigen deterministic vector containing
      /// center corrdinates and parameters.
      ///
      /// Initialized w/ one vector containing centre + params.
      /// @param vec: an Eigen 4*Dim-3 x 1 vec with centre and
      /// all ellipsoid params.
      ///
      template<typename PVT, enable_if_all_t<is_eigen_v<PVT>(),
                                             eigen_rows_v<PVT>()==(4*Dim-3)>*
               = nullptr>
      Ellipsoid(PVT &&vec):
        Ellipsoid(std::forward<PVT>(vec).template segment<Dim>(0),
                  std::forward<PVT>(vec).template tail<(3*Dim-3)>()) {};
      // Call ctor 2.

      /// @brief Default copy ctors.
      Ellipsoid(const Ellipsoid &) = default;

      /// @brief Default move ctor.
      Ellipsoid(Ellipsoid &&) = default;

      /// @brief Default copy assignment operator.
      Ellipsoid& operator=(const Ellipsoid &) = default;

      /// @brief Default move assignment operator.
      Ellipsoid& operator=(Ellipsoid &&) = default;

      ///@{
      /// @brief Set axis lengths of the current ellipsoid.
      ///
      /// @note This function also recaches the inverse axis
      /// length parameter.
      ///
      /// @warning This function does not change the **nature**
      /// of the current ellipsoid object. That means, for example
      /// if current ellipsoid is random, setting axes affect only
      /// the current state of the ellipsoid. Next time you roll
      /// it or draw a sample from it, you will always get a
      /// random realization.
      ///
      /// @param lengths: variadic input scalars specifying
      /// the target axis lengths separately. Or an Eigen Dim x 1
      /// vector.
      ///
      template<typename ...Args>
      exact_t& set_axis_lengths(Args ...lengths);

      template<typename Len>
      exact_t& set_axis_lengths(Len &&lengths);
      ///@}

      ///@{
      /// @brief Set rotation angles of the current ellipsoid.
      ///
      /// @note This function **will** trigger rotation
      /// matrix cache.
      ///
      /// @warning This function does not change the **nature**
      /// of the current ellipsoid object. That means, for example
      /// if current ellipsoid is random, setting angles affect
      /// only the current state of the ellipsoid. Next time you
      /// roll it or draw a sample from it, you will always get a
      /// random realization.
      ///
      /// @param lengths: variadic input scalars specifying
      /// the target rotation angles separately. Or an Eigen Dim
      /// x 1 vector.
      ///
      template<typename ...Args>
      exact_t& set_angles(Args ...angles);

      template<typename Angles>
      exact_t& set_angles(Angles &&angles);
      ///@}

      /// @brief Set rotation matrix of the current ellipsoid.
      ///
      /// @note This function also updates rotation angles from
      /// input matrix, using extrinsic rotation convention.
      ///
      /// @warning This function does not change the **nature**
      /// of the current ellipsoid object. That means, for example
      /// if current ellipsoid is random, setting angles affect
      /// only the current state of the ellipsoid. Next time you
      /// roll it or draw a sample from it, you will always get a
      /// random realization.
      ///
      /// @param lengths: input target rotation matrix, must
      /// be Eigen fixed size Dim x Dim.
      ///
      template<typename Mat>
      exact_t& set_rotation(Mat &&rot_mat);

    private:

      /// @brief Implementation of set axis lengths for element
      /// unpacking.
      ///
      template<typename Len, int ...Indx>
      exact_t& set_axis_lengths_impl(Len &&lengths, indx_seq<Indx...>);

      /// @brief Implementation of set angles for element
      /// unpacking.
      ///
      template<typename Angles, int ...Indx>
      exact_t& set_angles_impl(Angles &&angles, indx_seq<Indx...>);

      /// @brief Get a vector reprez of the ellipsoid.
      ///
      /// @return An Eigen column vector containing the ellipsoid
      /// centre, semi-axes lengths and orientation angles.
      ///
      vpack_t vpack_impl() const;

      /// @brief Access rotation mat.
      ///
      /// @return Current rotation matrix.
      ///
      const rotmt_t& rot_mat_impl() const;

      /// @brief Check if the current instance is in a parameter-
      /// valid state.
      ///
      /// @return True if all ellipsoid parameters are initialized.
      ///
      bool ready_impl() const;

      /// @brief Get current parameters.
      ///
      /// @return An Eigen vector containing all current ellipsoid
      /// parameters: semi axes lengths + orientation angles.
      ///
      const parvc_t& param_impl() const { return _params_vec; };

      /// @brief Get current parameter variants.
      ///
      /// @return A const reference to the parameter variants of
      /// the current shape.
      ///
      const varin_t& param_var_impl() const { return _params_in; }

      /// @brief Get current parameter variants. Non-const accessor.
      ///
      /// @return A non-const reference to the parameter variants of
      /// the current shape.
      ///
      varin_t& param_var_impl() { return _params_in; }

      /// @brief Check if the ellipsoid is random.
      ///
      /// @return True if current ellipsoid is random.
      ///
      bool is_random_impl() const;

      /// @brief Compute object volume.
      ///
      /// @return The computed volume.
      ///
      T volume_impl() const;

      /// @brief Compute the bounding box of the ellipsoid.
      ///
      /// The bounding box is an Eigen Dim x 2 matrix. It is a fixed
      /// size matrix. First column is the inner-bottom-left corner
      /// of the bounding box. Second column is the outer-upper-right
      /// corner of the bounding box. i.e. a bounding box is a box
      /// defined by two corner positions. For ellipsoid, it is a box
      /// with identical side lengths, all equal to the longest axis
      /// length.
      ///
      /// @return The computed bounding box. An Eigen Dim x 2 matrix.
      ///
      bound_t bounding_box_impl() const;

      /// @brief The maximum radius of a sphere enclosing completely
      /// the ellipsoid.
      ///
      /// For ellipsoid it is computed as the max of semi axes lengths.
      ///
      /// @return The computed enclosing radius.
      ///
      scalr_t enclosing_radius_impl() const
      { return _params_vec.segment(0,Dim).maxCoeff(); }

      /// @brief Alter the curr state of the ellipsoid.
      ///
      /// @note This has no effect if current instance is not random.
      ///
      /// @return `*this`.
      ///
      exact_t& roll_impl();

      /// @brief Reset the internal state of the ellipsoid.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      /// @note This function does nothing if the current ellipsoid
      /// is not random.
      ///
      /// @warning If the current ellipsoid is random, this function
      /// invalidates the internal cache and resets the parameters
      /// that are random.
      ///
      /// @return Non-const reference `*this`.
      ///
      exact_t& reset_state_impl();

      /// @brief Test if a point is inside the current ellipsoid.
      ///
      /// @param pt: the input point.
      /// @return True if the point is inside the ellipsoid.
      ///
      template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                            eigen_rows_v<PT>()==Dim,
                                            eigen_cols_v<PT>()==1>* = nullptr>
      bool inside_test_impl(PT &&pt) const;

      /// @brief Test if points(columns) of a matrix are inside the
      /// ellipsoid.
      ///
      /// @param mat: the input matrix, must be column ordered, with
      /// each column representing a point to test.
      /// @param lv: the logical vector to store the test results for
      /// each point.
      ///
      template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                            eigen_rows_v<MT>()==Dim>* = nullptr>
      void inside_test_impl(MT &&mat, slice_t &lv) const;

      /// @brief Rotate the current ellipsoid.
      ///
      /// Rotate with one angle for 2D case and three angles for 3D
      /// case. Rotation is **intrinsic, in reversed params order**.
      ///
      /// @param angles: angles of the rotation.
      /// @return `*this`.
      ///
      template<typename... PTS,
               typename = enable_if_t<sizeof...(PTS)==(2*Dim-3)> >
      exact_t& rotate_impl(PTS &&...angles);

      /// @brief Check if at least one axis length is random.
      bool has_random_axis_length() const;

      /// @brief Check if at least one orientation angle is random.
      bool has_random_orientation() const;

      /// @brief Re-cache rotation matrix.
      void recache_rotation() const;

      /// @brief Re-cache inverse of axes lengths.
      void recache_invcoeff() const;

      using parnt_t::                _centre; //:< The center.
      varin_t                     _params_in; //:< Buffur for input params.
      parvc_t                    _params_vec; //:< Half len & orientation.
      std::array<bool,3*Dim-3> _params_valid; //:< If a param has valid val.
      mutable rotmt_t        _rotation_cache; //:< Cache for rotation mat.
      mutable point_t        _invcoeff_cache; //:< Cache for inverse coeffs.
      mutable bool   _rotation_cached{false}; //:< If the coeffs are cached.
      mutable bool   _invcoeff_cached{false}; //:< If the rotation is cached.
    };

  }

  namespace utils
  {

    /// @brief Ellipsoid factory.
    ///
    /// @param args: variadic arguments for constructing a
    /// `stogeo::Ellipsoid`.
    /// @return A `stogeo::Ellipsoid` instance.
    ///
    template<typename T, int Dim, typename ...Args>
    shapes::Ellipsoid<T,Dim> make_ellipsoid(Args &&...args)
    {
      return shapes::Ellipsoid<T,Dim>(std::forward<Args>(args)...);
    }
  }

}


# include "Ellipsoid.hxx"
#endif
