// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Rectangle.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 14:37:07 2015 Zhijin Li
// Last update Thu Oct 12 19:11:47 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace shapes
  {

    // =====================================================================
    template<typename T, int Dim >
    Rectangle<T,Dim>::Rectangle():
      abstract::shapesbase<exact_t,Dim>(point_t::Zero()),
      _rotation_cache(rotmt_t::Identity()),
      _rotation_cached(true)
    {
      _params_vec.template segment<Dim>(0) = point_t::Ones();
      _params_vec.template segment<Dim>(Dim) = point_t::Zero();
      _params_valid.fill(true);

      std::copy(_params_vec.data(), _params_vec.data()+_params_vec.size(),
                std::begin(_params_in));
    }

    // =====================================================================
    template<typename T, int Dim >
    template<typename... PTS, typename PT, typename>
    Rectangle<T,Dim>::Rectangle(PT &&centre, PTS &&... params):
      abstract::shapesbase<exact_t,Dim>(std::forward<PT>(centre)),
      _params_in({std::forward<PTS>(params)...})
    {
      for(std::size_t __i = 0; __i < _params_in.size(); ++__i)
      {
        if(!boost::apply_visitor(var::is_rnd_var(),_params_in[__i]))
        {
          _params_vec(__i) = boost::apply_visitor
            (var::get_val<scalr_t>(),_params_in[__i]);
          _params_valid[__i] = true;
        }else
          _params_valid[__i] = false;
      }
      if( !has_random_orientation() ) recache_rotation();
    };

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT, typename PVT, typename>
    Rectangle<T,Dim>::Rectangle(PT &&centre, PVT &&par_vec):
      abstract::shapesbase<exact_t,Dim>(centre),
      _params_vec(std::forward<PVT>(par_vec)),
      _params_valid(utils::make_array<3*Dim-3,bool>(true)),
      _rotation_cache(utils::comp_rotmat
                     (_params_vec.template segment<2*Dim-3>(Dim))),
      _rotation_cached(true)
    {
      std::copy(_params_vec.data(), _params_vec.data()+_params_vec.size(),
                std::begin(_params_in));
    };

    // =====================================================================
    template<typename T, int Dim>
    auto Rectangle<T,Dim>::vpack_impl() const -> vpack_t
    {
      vpack_t __tmp; __tmp << centre(),param();
      return __tmp;
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Rectangle<T,Dim>::rot_mat_impl() const -> const rotmt_t&
    {
      if( !_rotation_cached ) recache_rotation();
      return _rotation_cache;
    }

    // =====================================================================
    template<typename T, int Dim>
    bool Rectangle<T,Dim>::ready_impl() const
    {
      return std::find(std::begin(_params_valid),std::end(_params_valid),false)
        == std::end(_params_valid) && _rotation_cached;
    }

    // =====================================================================
    template<typename T, int Dim>
    bool Rectangle<T,Dim>::is_random_impl() const
    {
      return has_random_side_length() || has_random_orientation();
    }

    // =====================================================================
    template<typename T, int Dim>
    T Rectangle<T,Dim>::volume_impl() const
    {
      return _params_vec.template segment<Dim>(0).prod();
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Rectangle<T,Dim>::bounding_box_impl() const -> bound_t
    {
      bound_t __bb;
      __bb << (_centre.array()-_params_vec.template segment<Dim>(0).
               norm()/static_cast<T>(2)).matrix(),
        (_centre.array()+_params_vec.template segment<Dim>(0).
         norm()/static_cast<T>(2)).matrix();
      return __bb;
    }

    // =====================================================================
    template<typename T, int Dim >
    auto Rectangle<T,Dim>::roll_impl() -> exact_t&
    {
      for(int __d = 0; __d < 3*Dim-3; ++__d)
      {
        if( boost::apply_visitor(var::is_rnd_var(),_params_in[__d]) )
        {
          _params_vec(__d) = boost::apply_visitor
            (var::draw_val<scalr_t>(),_params_in[__d]);
          _params_valid[__d] = true;
        }
      }

      if( has_random_orientation() ) recache_rotation();
      return *this;
    }

    // =====================================================================
    template<typename T, int Dim >
    auto Rectangle<T,Dim>::reset_state_impl() -> exact_t&
    {
      for(int __d = 0; __d < 3*Dim-3; ++__d)
        if( boost::apply_visitor(var::is_rnd_var(),_params_in[__d]) )
        {
          _params_vec(__d)   = 0;
          _params_valid[__d] = false;
        }

      _rotation_cached = false;
      if( has_random_orientation() ) _rotation_cache = rotmt_t::Zero();
      return *this;
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                          eigen_rows_v<PT>()==Dim,
                                          eigen_cols_v<PT>()==1>*>
    bool Rectangle<T,Dim>::inside_test_impl(PT &&pt) const
    {
      for(int __d = 0; __d < Dim; ++__d)
      {
        if( (_rotation_cache.transpose()*(pt-_centre))(__d)
            *static_cast<T>(-2.0) > _params_vec(__d) ||
            (_rotation_cache.transpose()*(pt-_centre))(__d)
            *static_cast<T>(2.0) > _params_vec(__d) )
          return false;
      }
      return true;
    };

    // =====================================================================
    template<typename T, int Dim>
    template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                          eigen_rows_v<MT>()==Dim>*>
    void Rectangle<T,Dim>::inside_test_impl(MT &&mat, slice_t &lv) const
    {
      assert( ready() && "random rectangle not initialized." );

#pragma omp parallel for
      for(int __n = 0; __n < mat.cols(); ++__n)
        lv(__n) = inside_test_impl(mat.col(__n));
    }

    // =====================================================================
    template<typename T, int Dim > template<typename... PTS, typename>
    auto Rectangle<T,Dim>::rotate_impl(PTS &&... angles) -> exact_t&
    {
      /// TODO: check this implementation, not a proper way of rotation.
      auto __args_list = {std::forward<PTS>(angles)...};
      for(auto & __arg: __args_list)
      { _params_vec(Dim+&__arg-std::begin(__args_list)) += __arg; }

      recache_rotation();
      return *this;
    };

    // =====================================================================
    template<typename T, int Dim>
    bool Rectangle<T,Dim>::has_random_side_length() const
    {
      return  std::find_if(std::begin(_params_in),
                           std::begin(_params_in)+Dim+1,
                           [](const param_t &__par)
                           { return boost::apply_visitor(var::is_rnd_var(),__par); }
                           ) != std::begin(_params_in)+Dim+1;
    }

    // =====================================================================
    template<typename T, int Dim>
    bool Rectangle<T,Dim>::has_random_orientation() const
    {
      return std::find_if(std::next(std::begin(_params_in),Dim),
                          std::end(_params_in),
                          [](const param_t &__par)
                          { return boost::apply_visitor(var::is_rnd_var(),__par); }
                          ) != std::end(_params_in);
    }

    // =====================================================================
    template<typename T, int Dim>
    void Rectangle<T,Dim>::recache_rotation() const
    {
      _rotation_cache =
        utils::comp_rotmat(_params_vec.template segment<2*Dim-3>(Dim));
      _rotation_cached = true;
    }

  } //!shapes
} //!stogeo
