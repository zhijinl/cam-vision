// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Box.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 14:37:07 2015 Zhijin Li
// Last update Sun Nov 20 21:55:20 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace shapes
  {

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT, typename... PTS, typename>
    Box<T,Dim>::Box(PT &&centre, PTS ...side_lengths):
      abstract::shapesbase<Box<T,Dim>,Dim>(std::forward<PT>(centre)),
      _side_lgths(utils::make_eigen_pt<T>(side_lengths...)) {};

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT, typename PVT, typename>
    Box<T,Dim>::Box(PT &&centre, PVT &&side_lengths):
      abstract::shapesbase<Box<T,Dim>,Dim>(std::forward<PT>(centre)),
      _side_lgths(std::forward<PVT>(side_lengths)) {};

    // =====================================================================
    template<typename T, int Dim>
    auto Box<T,Dim>::vpack_impl() const -> vpack_t
    {
      vpack_t __tmp;
      __tmp << centre(),param();
      return __tmp;
    }

    // =====================================================================
    template<typename T, int Dim>
    T Box<T,Dim>::volume_impl() const
    {
      return _side_lgths.prod();
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Box<T,Dim>::bounding_box_impl() const -> bound_t
    {
      bound_t __bb;
      __bb << _centre-_side_lgths/static_cast<T>(2),
        _centre+_side_lgths/static_cast<T>(2);

      return __bb;
    }

    // =====================================================================
    template<typename T, int Dim > template<typename... PTS, typename>
    auto Box<T,Dim>::rotate_impl(PTS &&...) & -> exact_t&
    {
      std::cout << "warning: rotate has no effect for boxes.\n";
      return *this;
    };

    // =====================================================================
    template <typename T, int Dim>
    template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                          eigen_rows_v<PT>()==Dim,
                                          eigen_cols_v<PT>()==1>*>
    bool Box<T,Dim>::inside_test_impl(PT &&pt) const
    {
      return  ((pt.array() > (_centre-_side_lgths/static_cast<T>(2)).array())
               .count() == Dim) &&
        ((pt.array() < (_centre+_side_lgths/static_cast<T>(2)).array())
         .count() == Dim);
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename MT,
             enable_if_all_t<is_eigen_v<MT>(),
                             eigen_rows_v<MT>()==Dim>*>
    void Box<T,Dim>::inside_test_impl(MT &&mat, slice_t &lv) const
    {
#pragma omp parallel for
      for(auto __n = 0; __n < mat.cols(); ++__n)
        lv(__n) = inside_test_impl(mat.col(__n));
    }

  } //!shapes
} //!stogeo
