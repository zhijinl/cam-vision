// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Sphere.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 14:37:07 2015 Zhijin Li
// Last update Thu Oct 12 19:10:55 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace shapes
  {

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT, typename VT, typename>
    Sphere<T,Dim>::Sphere(PT &&centre, VT &&par_in):
      abstract::shapesbase<exact_t,Dim>(std::forward<PT>(centre)),
      _par_in(std::forward<VT>(par_in))
    {
      if (!boost::apply_visitor(var::is_rnd_var(),_par_in))
      {
        _radius = boost::apply_visitor(var::get_val<scalr_t>(),_par_in);
        _param_valid = true;
      }else
      {
        _param_valid = false;
      }
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Sphere<T,Dim>::vpack_impl() const -> vpack_t
    {
      vpack_t __tmp;
      __tmp << centre(),param();
      return __tmp;
    }

    // =====================================================================
    template<typename T, int Dim>
    bool Sphere<T,Dim>::is_random_impl() const
    {
      return boost::apply_visitor(var::is_rnd_var(),_par_in);
    }

    // =====================================================================
    template<typename T, int Dim>
    T Sphere<T,Dim>::volume_impl() const
    {
      return std::pow(stg_pi,Dim/2.0)/tgamma(Dim/2.0+1.0)*
        static_cast<T>(std::pow(_radius,Dim));
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Sphere<T,Dim>::bounding_box_impl() const -> bound_t
    {
      bound_t __bb;
      __bb << (_centre.array()-_radius).matrix(),
        (_centre.array()+_radius).matrix();
      return __bb;
    }

    // =====================================================================
    template<typename T, int Dim > template<typename... PTS, typename>
    auto Sphere<T,Dim>::rotate_impl(PTS &&...) -> exact_t&
    {
      std::cout << "warning: rotate has no effect on spheres.\n";
      return *this;
    };

    // =====================================================================
    template<typename T, int Dim>
    auto Sphere<T,Dim>::roll_impl() -> exact_t&
    {
      if(boost::apply_visitor(var::is_rnd_var(),_par_in))
      {
        _radius = boost::apply_visitor(var::draw_val<scalr_t>(),_par_in);
        _param_valid = true;
      }
      return *this;
    }

    // =====================================================================
    template<typename T, int Dim>
    auto Sphere<T,Dim>::reset_state_impl() -> exact_t&
    {
      if(boost::apply_visitor(var::is_rnd_var(),_par_in))
      {
        _radius = 0;
        _param_valid = false;
        boost::apply_visitor(var::reset_rv{},_par_in);
        return *this;
      }
      return *this;
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename PT,
             enable_if_all_t<is_eigen_v<PT>(),
                             eigen_rows_v<PT>()==Dim,
                             eigen_cols_v<PT>()==1>*>
    bool Sphere<T,Dim>::inside_test_impl(PT &&pt) const
    {
      return (((pt-_centre).array())*((pt-_centre).array())).sum()
        <= _radius*_radius;
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename MT,
             enable_if_all_t<is_eigen_v<MT>(),
                             eigen_rows_v<MT>()==Dim>*>
    void Sphere<T,Dim>::inside_test_impl(MT &&mat, slice_t &lv) const
    {
      assert( ready() && "shape not ready, forgot to roll?");

#pragma omp parallel for
      for(int __n = 0; __n < mat.cols(); ++__n)
      { lv(__n) = inside_test_impl(mat.col(__n)); }
    }

  } //!shapes
} //!stogeo
