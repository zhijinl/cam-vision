// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Box.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 14:37:07 2015 Zhijin Li
// Last update Thu Oct 12 19:11:29 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_BOX_HH
# define STOGEO_BOX_HH

# include "shapesbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace shapes { template<typename T, int Dim> class Box; }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::shapes::Box`
    /// class.
    ///
    template<typename T, int Dim> struct specs<shapes::Box<T,Dim> >
    {
      static constexpr int dim      =                            Dim;
      static constexpr int n_params =                            Dim;
      static const stg_ids stg_id   =          stg_ids::STOGEO_SHAPE;
      typedef T                                              param_t;
      typedef T                                              scalr_t;
      typedef T                                              varin_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef Eigen::Matrix<T,Dim,Dim>                       rotmt_t;
      typedef Eigen::Matrix<T,Dim,2>                         bound_t;
      typedef Eigen::Matrix<T,Dim,1>                         parvc_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            parmt_t;
      typedef Eigen::Matrix<T,2*Dim,1>                       vpack_t;
      typedef Eigen::Matrix<T,2*Dim,Eigen::Dynamic>          mpack_t;
      typedef Eigen::aligned_allocator<shapes::Box<T,Dim> >  alloc_t;
    };
  }

  /// @ingroup group_shape
  namespace shapes
  {

    /// @ingroup group_shape
    ///
    /// @brief Class for a `Box` in arbitrary dimension.
    ///
    /// Box is a rectangle that **cannot be rotated**. It is always
    /// aligned with canonical axes.
    ///
    /// @param T: the scalar typeused for floating-point computations.
    /// @param Dim: the dimension.
    ///
    template<typename T, int Dim> class Box
      : public abstract::shapesbase<Box<T,Dim>,Dim>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t =                Box<T,Dim>;
      using specs_t =    traits::specs<exact_t>;
      using param_t = typename specs_t::param_t;
      using scalr_t = typename specs_t::scalr_t;
      using varin_t = typename specs_t::varin_t;
      using point_t = typename specs_t::point_t;
      using vectr_t = typename specs_t::vectr_t;
      using matrx_t = typename specs_t::matrx_t;
      using slice_t = typename specs_t::slice_t;
      using dymat_t = typename specs_t::dymmt_t;
      using rotmt_t = typename specs_t::rotmt_t;
      using bound_t = typename specs_t::bound_t;
      using parvc_t = typename specs_t::parvc_t;
      using vpack_t = typename specs_t::vpack_t;
      using mpack_t = typename specs_t::mpack_t;
      using parmt_t = typename specs_t::parmt_t;
      using parnt_t = abstract::shapesbase<Box<T,Dim>,Dim>;

      friend parnt_t;
      using parnt_t::        roll;
      using parnt_t::       ready;
      using parnt_t::       vpack;
      using parnt_t::       param;
      using parnt_t::      centre;
      using parnt_t::      rotate;
      using parnt_t::      volume;
      using parnt_t::     move_to;
      using parnt_t::     rot_mat;
      using parnt_t::    discrete;
      using parnt_t::   is_random;
      using parnt_t::   param_var;
      using parnt_t:: reset_state;
      using parnt_t:: inside_test;
      using parnt_t::bounding_box;

      static constexpr int dim = Dim;
      static constexpr int n_params = Dim;

      /// @brief Default ctor. Initialize to a unit cube.
      Box(): Box(point_t::Zero(), point_t::Ones()) {};

      /// @brief Ctor 1.
      ///
      /// Initialized w centre coords & separate params.
      /// @param centre: the centre point, Eigen Dim x 1.
      /// @param side_lengths: variadic arithmetic, specifying
      /// lengths of the sides of the box. r.v. not allowed.
      ///
      template<typename PT, typename... PTS, typename =
               enable_if_all_t<is_eigen_v<PT>(),
                               eigen_rows_v<PT>()==Dim,
                               sizeof...(PTS) == Dim,
                               is_arithmetic_v<PTS>()...> >
      Box(PT &&centre, PTS ...side_lengths);

      /// @brief Ctor 2.
      ///
      /// Initialized w centre coords and params vector.
      /// @param centre: the centre point, Eigen Dim x 1.
      /// @param side_lengths vec: an Eigen Dim x 1 vec containing
      /// side lengths of the box.
      ///
      template<typename PT, typename PVT, typename =
               enable_if_all_t<is_eigen_v<PT>(),
                               is_eigen_v<PVT>(),
                               eigen_rows_v<PT>()==Dim,
                               eigen_rows_v<PVT>()==Dim> >
      Box(PT &&, PVT &&);

      /// @brief Ctor 3.
      ///
      /// Initialized w/ only separate params. Centre = o.
      /// @param args:  variadic arithmetic, specifying lengths
      /// of the sides of the box. r.v. not allowed.
      ///
      template<typename... PTS,
               enable_if_all_t<sizeof...(PTS)==Dim,
                               is_arithmetic_v<PTS>()...>* = nullptr>
      Box(PTS ...args): Box(point_t::Zero(), args...) {};
      // Calls ctor 1.

      /// @brief Ctor 4.
      ///
      /// Initialized w/ only params vector.
      /// @param vec: an Eigen Dim x 1 vec containing only side
      /// lengths of the box.
      ///
      template<typename PVT,
               enable_if_all_t<is_eigen_v<PVT>(),
                               eigen_rows_v<PVT>()==Dim>* = nullptr>
      Box(PVT &&vec): Box(point_t::Zero(),std::forward<PVT>(vec)) {};
      // Call ctor 2.

      /// @brief Ctor 5.
      ///
      /// Initialized w/ one vector containing centre + params.
      /// @param vec: an Eigen 2*Dim x 1 vec with the centre &
      /// and side lengths.
      ///
      template<typename PVT,
               enable_if_all_t<is_eigen_v<PVT>(),
                               eigen_rows_v<PVT>()==2*Dim>* = nullptr>
      Box(PVT &&vec):Box(std::forward<PVT>(vec).template segment<Dim>(0),
                         std::forward<PVT>(vec).template tail<(Dim)>()) {};
      // Call ctor 2.

      /// @brief Ctor 6.
      ///
      /// Construct a Box from a cmn::Domain.
      /// @param domain: the input domain.
      ///
      template<typename Indx = make_seq_t<Dim> >
      Box(const cmn::abstract::Domain<Dim> &domain): Box(Indx(), domain) {};

      /// @brief Default copy ctors.
      Box(const Box &) = default;

      /// @brief Default move ctor.
      Box(Box &&) = default;

      /// @brief Default copy assignment operator.
      Box& operator=(const Box &) = default;

      /// @brief Default move assignment operator.
      Box& operator=(Box &&) = default;

    private:

      /// @brief A private ctor called by Ctor 6.
      ///
      /// This ctor serves as the implementation of Box ctor taking
      /// a `cmn::Domain` as input.
      ///
      /// @param domain: an input domain.
      ///
      template<int ...Indx>
      Box(indx_seq<Indx...>, const cmn::abstract::Domain<Dim> &domain):
        Box(point_t{(domain.originLU(Indx)+domain[Indx]*domain.sp()[Indx]/2)...},
            parvc_t{(domain[Indx]*domain.sp()[Indx])...}) {};

      /// @brief Get a vector reprez of the box.
      ///
      /// @return An Eigen column vector containing the box
      /// centre and side lengths.
      ///
      vpack_t vpack_impl() const;

      /// @brief Access rotation mat.
      ///
      /// @return **Always the identity matrix**.
      ///
      const rotmt_t& rot_mat_impl() const { return rotmt_t::Identity(); };

      /// @brief Check if the current instance is in a parameter-
      /// valid state.
      ///
      /// @return **Always true for Box**.
      ///
      constexpr bool ready_impl() const { return true; };

      /// @brief Get current parameters.
      ///
      /// @return A const-ref to current parameter vector.
      ///
      const parvc_t& param_impl() const { return _side_lgths; };

      /// @brief Get current parameter variants.
      ///
      /// @note This interface is deleted for `stogeo::Box` since
      /// a box is always deterministic.
      ///
      /// @sa For a rectangles, consider `stogeo::shapes::Rectangle`.
      ///
      const varin_t& param_var_impl() const = delete;

      /// @brief Get current parameter variants. Non-const accessor.
      ///
      /// @note This interface is deleted for `stogeo::Box` since
      /// a box is always deterministic.
      ///
      /// @sa For a rectangles, consider `stogeo::shapes::Rectangle`.
      ///
      varin_t& param_var_impl() = delete;

      /// @brief Check if the Box is random: always return false.
      ///
      /// @return **Always false**.
      ///
      bool is_random_impl() const { return false; };

      /// @brief Compute object volume.
      ///
      /// @return The computed volume.
      ///
      T volume_impl() const;

      /// @brief Compute the bounding box of the box.
      ///
      /// The bounding box is an Eigen Dim x 2 matrix. It is a fixed
      /// size matrix. First column is the inner-bottom-left corner
      /// of the bounding box. Second column is the outer-upper-right
      /// corner of the bounding box. i.e. a bounding box is a box
      /// defined by two corner positions. For Box, it is a box with
      /// the same side lengths as the curr Box object.
      ///
      /// @return The computed bounding box. An Eigen Dim x 2 matrix.
      ///
      bound_t bounding_box_impl() const;

      /// @brief Alter curr state.
      ///
      /// @note This function has no effect on a box. It is for API
      /// compatibility.
      ///
      exact_t& roll_impl() { return *this; };

      /// @brief Reset the internal state of the shape.
      ///
      /// @note This function has no effect on a box. It is for API
      /// compatibility.
      ///
      exact_t& reset_state_impl() { return *this; };

      /// @brief Test if a point is inside the box.
      ///
      /// @param pt: the input point.
      /// @return True if the point is inside the box.
      ///
      template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                            eigen_rows_v<PT>()==Dim,
                                            eigen_cols_v<PT>()==1>* = nullptr>
      bool inside_test_impl(PT &&pt) const;

      /// @brief Test if points(columns) of a matrix are inside the
      /// box.
      ///
      /// @param mat: the input matrix, must be column ordered, with
      /// each column representing a point to test.
      /// @param lv: the logical vector to store the test result for each
      /// point.
      ///
      template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                            eigen_rows_v<MT>()==Dim>* = nullptr>
      void inside_test_impl(MT &&mat, slice_t &lv) const;

      /// @brief Rotate the object.
      ///
      /// @note This function has no effect: it is only for API
      /// compatibility.
      ///
      template<typename... PTS,
               typename = enable_if_t<sizeof...(PTS)==(2*Dim-3)> >
      exact_t& rotate_impl(PTS &&...) &;

      using parnt_t::_centre; //:< The center.
      parvc_t    _side_lgths; //:< The side lengths of the box.
    };

  }

  namespace utils
  {
    /// @brief Box factory.
    ///
    /// @param args: variadic arguments for constructing a
    /// `stogeo::Box`.
    /// @return A `stogeo::Box` instance.
    ///
    template<typename T, int Dim, typename ...Args>
    shapes::Box<T,Dim> make_box(Args &&...args)
    {
      return shapes::Box<T,Dim>(std::forward<Args>(args)...);
    }
  }

}


# include "Box.hxx"
#endif
