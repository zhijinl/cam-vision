// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// shapesbase.hxx for StoGeo
//
// Made by Zhijin LI
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:41:07 2015 Zhijin Li
// Last update Thu Oct 12 19:08:01 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace shapes
  {
    namespace abstract
    {

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename PT, int dummy, enable_if_t<dummy!=1>*>
      auto shapesbase<EXACT,Dim>::draw(PT &&centre) const -> vpack_t
      {
        vpack_t __vec;
        __vec.template segment<Dim>(0) = std::forward<PT>(centre);
        for(int __d = Dim; __d < 4*Dim-3; ++__d)
        {
          if( boost::apply_visitor
              (var::is_rnd_var(), value_at(param_var(),__d-Dim)) )
            __vec(__d) = boost::apply_visitor
              (var::draw_val<scalr_t>(),value_at(param_var(),__d-Dim));
          else
            __vec(__d) = boost::apply_visitor
              (var::get_val<scalr_t>(),value_at(param_var(),__d-Dim));
        }
        return __vec;
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename PT, int dummy, enable_if_t<dummy==1>*>
      auto shapesbase<EXACT,Dim>::draw(PT &&centre) const -> vpack_t
      {
        vpack_t __vec;
        __vec.template segment<Dim>(0) = std::forward<PT>(centre);

        if(boost::apply_visitor(var::is_rnd_var(),param_var()))
          __vec(Dim) = boost::apply_visitor
            (var::draw_val<scalr_t>(),param_var());
        else
          __vec(Dim) = boost::apply_visitor
            (var::get_val<scalr_t>(),param_var());
        return __vec;
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<int dummy, enable_if_t<dummy!=1>*>
      auto shapesbase<EXACT,Dim>::draw(no_center_tag_t tag) const -> parvc_t
      {
        parvc_t __vec;
        for(int __n = 0; __n < n_params; ++__n)
        {
          if( boost::apply_visitor
              (var::is_rnd_var(),value_at(param_var(),__n)) )
            __vec(__n) = boost::apply_visitor
              (var::draw_val<scalr_t>(),value_at(param_var(),__n));
          else
            __vec(__n) = boost::apply_visitor
              (var::get_val<scalr_t>(),value_at(param_var(),__n));
        }
        return __vec;
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<int dummy, enable_if_t<dummy==1>*>
      auto shapesbase<EXACT,Dim>::draw(no_center_tag_t tag) const -> scalr_t
      {
        if( boost::apply_visitor(var::is_rnd_var(), param_var()) )
          return boost::apply_visitor
            ( var::draw_val<scalr_t>(), param_var() );
        else
          return boost::apply_visitor
            ( var::get_val<scalr_t>(), param_var() );
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename VT, typename PT, typename>
      cmn_img_t<VT,Dim> shapesbase<EXACT,Dim>::discrete(PT &&spacing,
                                                        VT in_val,
                                                        VT out_val) const
      {
        static_assert(eigen_rows_v<PT>()==Dim,
                      "ERROR: SPACING DIMENSION MISMATCH.");
        static_assert(eigen_cols_v<PT>()==1,
                      "ERROR: EXPECTS AN EIGEN VEC FOR SPACING.");
        static_assert(is_floating_point_v<eigen_val_t<PT> >(),
                      "ERROR: SPACING MUST BE FLOATING TYPE.");

        auto __domain = utils::make_cmn_domain(bounding_box(),spacing);
        return discrete(__domain,in_val,out_val);
      }

      // =====================================================================
      template<typename EXACT, int Dim> template<typename VT>
      auto shapesbase<EXACT,Dim>::discrete(const cmn_domain_t<Dim> &dom,
                                           VT in_val, VT out_val) const
        -> cmn_img_t<VT,Dim>
      {
        using __image_t = cmn_img_t<VT,Dim>;
        __image_t __bin_img(dom);
        cmn_iter_type(__image_t) __it(dom);

        cmn_for_all(__it)
        {
          __bin_img[__it] = inside_test(utils::cmn_itr_pos<scalr_t>(__it))?
            in_val:out_val;
        }
        return __bin_img;
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename PT, enable_if_all_t<is_eigen_v<PT>(),
                                            eigen_rows_v<PT>()==Dim,
                                            eigen_cols_v<PT>()==1>*>
      bool shapesbase<EXACT,Dim>::inside_test(PT &&pt) const
      {
        return exact().inside_test_impl(std::forward<PT>(pt));
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                            eigen_rows_v<MT>()==Dim>*>
      void shapesbase<EXACT,Dim>::inside_test(MT &&mat, slice_t &lv) const
      {
        exact().inside_test_impl(std::forward<MT>(mat),lv);
      }

      // =====================================================================
      template<typename EXACT, int Dim>
      template<typename MT, enable_if_all_t<is_eigen_v<MT>(),
                                            eigen_rows_v<MT>()==Dim,
                                            eigen_cols_v<MT>()!=1>*>
      auto shapesbase<EXACT,Dim>::inside_test(MT &&mat) const -> slice_t
      {
        slice_t __lv(mat.cols());
        inside_test(std::forward<MT>(mat),__lv);
        return __lv;
      }

    } //!abstract
  } //!shapes
} //!stogeo
