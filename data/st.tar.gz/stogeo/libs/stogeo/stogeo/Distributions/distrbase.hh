// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// distrbase.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 16:04:07 2015 Zhijin Li
// Last update Mon Sep 11 19:01:37 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_DISTRBASE_HH
# define STOGEO_DISTRBASE_HH

# include "stogeo/core.hh"
# include "stogeo/Utilities/utils.hh"


namespace stogeo
{

  /// @defgroup group_stats Multivariate Statistics
  ///
  /// @brief Classes for modeling multivariate statistical distributions,
  /// sampling & empirical estimation etc.

  /// @ingroup group_stats
  namespace rnd
  {
    namespace abstract
    {

      /// @ingroup group_stats
      ///
      /// @brief The base class for all statistical distributions.
      ///
      /// @param EXACT: type of derived class inheriting it.
      /// @param Dim: the dimension.
      ///
      template<typename EXACT>
      class distrbase: public internal__::root__<EXACT>
      {
      private:

        using internal__::   root__<EXACT>::exact;
        using specs_t =      traits::specs<EXACT>;
        using scalr_t = typename specs_t::scalr_t;
        using value_t = typename specs_t::value_t;
        using locat_t = typename specs_t::locat_t;
        using param_t = typename specs_t::param_t;

      public:

        /// @brief Draw a single value.
        ///
        /// @return One sample following the current distribution.
        ///
        value_t draw() const;

        /// @brief Independently draw vals into en Eigen structure.
        ///
        /// @param structure: the input Eigen structure.
        ///
        template<typename MT>
        void draw(MT &&structure) const;

        /// @brief Independently draw vals into en Eigen structure.
        ///
        /// Need to explicitly specify the output Eigen Matrix type.
        /// @param: optional rows of the output matrix. Has no effect
        /// if the output is fixed size.
        /// @param: optional cols of the output matrix. Has no effect
        /// if the output is fixed size.
        /// @return Output mat/vec filled with random number from distr.
        ///
        template<typename Matrix> Matrix draw(int rows=0, int cols=0) const;

        /// @brief Reset state of the random distribuition: so that
        /// next call to draw() is independent from the previous one.
        ///
        /// @note For usual cases of simulations, you barely need
        /// to use this function. It is **different from reseting the
        /// random seed**, which is managed by the function
        /// `stogeo::utils::reset_shared_engine()`. In one stream of
        /// simulations, it is rarely necessary to call this function.
        ///
        /// @note In two use cases this function might be usefull:
        /// - When you want to reproduce the same simulation results,
        ///   consider combining this function with
        ///   `stogeo::utils::reset_shared_engine()`.
        /// - When you want to simulate **another independent
        ///   stream of values use the same distribution object**.
        ///
        /// @return Non-const reference to `*this`.
        ///
        EXACT& reset_state();

        /// @brief Reset parameters of the distribution.
        ///
        /// @param args: variadic params same as used for the distr.
        ///
        template<typename ...Args,
                 typename = enable_if_all_t<is_arithmetic_v<Args>()...> >
        EXACT& reset_param(Args ...args);

        /// @brief Return the max value of the pdf / pmf.
        ///
        /// @return The maximum value of the pdf / pmf function.
        ///
        scalr_t distr_max() const
        { return exact().max_distr_val_impl(); }

        /// @brief Return the value at specified index of the pdf / pmf.
        ///
        /// @param location: where pdf / pmf will be evaluated.
        /// @return The pdf / pmf value evaluated at `location`.
        ///
        scalr_t operator()(locat_t location) const
        { return exact().distr_val_at_impl(location); }

      protected:

        /// @brief Ctor. Protected to prevent instantiation.
#ifdef STG_NON_REPRODUCIBLE
        distrbase(): _engine( gen_uid() ) {};
#else
        distrbase() = default;
#endif

        /// @brief Default copy ctor.
        distrbase(const distrbase &rhs) = default;

        /// @brief Default move ctor.
        distrbase(distrbase &&rhs) = default;

        /// @brief Default copy assignment operator.
        distrbase& operator=(const distrbase &rhs) = default;

        /// @brief Default move assignment operator.
        distrbase& operator=(distrbase &&rhs) = default;

        /// @brief generate unique object id
#ifdef STG_NON_REPRODUCIBLE
        uintptr_t gen_uid() const;
        mutable std::mt19937_64 _engine;
#endif
      };

    } //!abstract
  } //!rnd
} //!stogeo


# include "distrbase.hxx"
#endif //!STOGEO_DISTRBASE_HH
