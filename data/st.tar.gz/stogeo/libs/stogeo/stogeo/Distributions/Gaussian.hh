// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Gaussian.hh for MO3
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Wed Feb 15 11:32:34 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_GAUSSIAN_HH
# define STOGEO_GAUSSIAN_HH

# include "distrbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace rnd { template<typename T> class Gaussian; }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_stats
    ///
    /// @brief Type traits properties for the `stogeo::rnd::Gaussian`
    /// class.
    ///
    template<typename T> struct specs<rnd::Gaussian<T> >
    {
      static const stg_ids stg_id    = stg_ids::STOGEO_RNDVR;
      static const int dim           =                     1;
      static const bool is_symmetric =                  true;
      typedef T                                      scalr_t;
      typedef T                                      value_t;
      typedef T                                      locat_t;
      typedef std::normal_distribution<T>            distr_t;
      typedef typename distr_t::param_type           param_t;
    };
  }

  /// @ingroup group_stats
  namespace rnd
  {

    /// @ingroup group_stats
    ///
    /// @brief Class for Gaussian distribution.
    ///
    /// @param T: the scalar value, result type of each sampling.
    ///
    template<typename T> class Gaussian
      : public abstract::distrbase<Gaussian<T> >
    {
    public:

      using exact_t =            Gaussian<T>;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using value_t = typename specs_t::value_t;
      using locat_t = typename specs_t::locat_t;
      using distr_t = typename specs_t::distr_t;
      using param_t = typename specs_t::param_t;

      using parnt_t = abstract::distrbase<exact_t>;
      friend parnt_t;

      using parnt_t::draw;
      using parnt_t::distr_max;
      using parnt_t::operator();
      using parnt_t::reset_state;
      using parnt_t::reset_param;

      /// Ctor.
      template<typename... PT,
               enable_if_all_t<is_arithmetic_v<PT>()...>* = nullptr>
      explicit Gaussian(PT ...);

      /// Dflt ctor.
      Gaussian() = default;

      /// Dflt copy ctor.
      Gaussian(const Gaussian &rhs) = default;

      /// Dflt Move ctor.
      Gaussian(Gaussian &&rhs) = default;

      /// Dflt copy assignment operator.
      exact_t& operator=(const Gaussian &rhs) = default;

      /// Dflt Move assignment operator.
      exact_t& operator=(Gaussian &&rhs) = default;

      /// Access the mean.
      scalr_t mu() const { return _distribution.mean(); }

      /// Access the sigma: standard deviation.
      scalr_t sigma() const { return _distribution.stddev(); }

    private:

      /// Sample a Gaussian r.v.
      value_t draw_impl() const;

      /// Return the max value of the Gaussian pdf.
      scalr_t max_distr_val_impl() const;

      /// Return the value at specified index of the Gaussian pdf.
      ///
      /// @param location: input index where the pdf will be evaluated.
      ///
      scalr_t distr_val_at_impl(locat_t location) const;

      mutable distr_t _distribution;
    };

  } //!rnd
} //!stogeo


# include "Gaussian.hxx"
#endif //!STOGEO_GAUSSIAN_HH
