// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// distrbase.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 16:04:07 2015 Zhijin Li
// Last update Thu Oct 12 13:31:16 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace rnd
  {
    namespace abstract
    {

      // =====================================================================
      template<typename EXACT>
      auto distrbase<EXACT>::draw() const -> value_t
      { return exact().draw_impl(); }

      // =====================================================================
      template<typename EXACT> template<typename MT>
      void distrbase<EXACT>::draw(MT &&structure) const
      {
        static_assert(is_eigen_v<MT>(),
                      "ERROR: EXPECTS AN EIGEN STRUCTURE.");
        // for(int __n = 0; __n < structure.size(); __n++)
        //   *(structure.data() + __n) = draw();
        for(int __m = 0; __m < structure.rows(); __m++)
          for(int __n = 0; __n < structure.cols(); __n++)
            structure(__m, __n) = draw();
      }

      // =====================================================================
      template<typename EXACT> template<typename Matrix>
      Matrix distrbase<EXACT>::draw(int rows, int cols) const
      {
        Matrix __result(rows,cols); draw(__result);
        return __result;
      }

      // =====================================================================
      template<typename EXACT>
      auto distrbase<EXACT>::reset_state() -> EXACT&
      {
        exact()._distribution.reset();
        return (*this).exact();
      }

      // =====================================================================
      template<typename EXACT>
      template<typename ...Args, typename>
      auto distrbase<EXACT>::reset_param(Args ...args) -> EXACT&
      {
        exact()._distribution.param(param_t(args...));
        return (*this).exact();
      }

      // =====================================================================
#ifdef STG_NON_REPRODUCIBLE
      template<typename EXACT>
      uintptr_t distrbase<EXACT>::gen_uid() const
      {
        /// TODO: consider add time_of_moment to addr value.
        return reinterpret_cast<uintptr_t>(&exact());
      }
#endif

    } //!abstract
  } //!rnd
} //!stogeo
