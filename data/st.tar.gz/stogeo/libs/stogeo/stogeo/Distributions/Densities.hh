// ---------------------------------------------------------------------------
// Copyright (c) 2018 by General Electric Medical Systems
//
// Densities.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Sep  3 11:45:57 2018 Zhijin Li
// Last update Mon Sep  3 12:03:11 2018 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{

  // Fwd decl.
  namespace rnd
  {
    template<typename,int,typename,typename> class Distribution;
  }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::rnd::Distribution`
    /// class.
    ///
    template<typename ValueType, int Dim, typename Func, typename Sampler>
    struct specs<rnd::Distribution<ValueType,Dim,Func> >
    {
      static const stg_ids stg_id    =    stg_ids::STOGEO_RNDVR;
      static const int dim           =                      Dim;
      static const bool is_symmetric =                    false;
      typedef double                                    scalr_t;
      typedef point_dispatch_t<ValueType,Dim,Func> value_t;
      typedef point_dispatch_t<ValueType,Dim,Func> locat_t;
      typedef Func                                 distr_t;
      typedef Sampler                                   smplr_t;
    };
  }


  namespace rnd
  {

    template<typename ValueType, int Dim, typename Func, sampler smplr>
    class PDF:
      public abstract::distrbase<PDF<ValueType,Dim,Func,smplr> >
    {
    };

    template<typename ValueType, int Dim, typename Func, sampler smplr>
    class UnnormalizedDensity:
      public abstract::distrbase<UnnormalizedDensity<ValueType,Dim,Func,smplr> >
    {
    };

    // template<typename ValueType, int Dim, typename Func, sampler smplr>
    // class CDF:
    //   public abstract::distrbase<CDF<ValueType,Dim,Func,smplr> >
    // {
    // };

    template<typename ValueType, int Dim, typename Func, sampler smplr>
    class InverseCDF:
      public abstract::distrbase<InverseCDF<ValueType,Dim,Func,smplr> >
    {
    };

  }
}
