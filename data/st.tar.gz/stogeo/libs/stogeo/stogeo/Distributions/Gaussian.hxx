// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Gaussian.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Fri Nov 18 15:14:42 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace rnd
  {

    // =====================================================================
    template<typename T>
    template<typename... PT,
             enable_if_all_t<is_arithmetic_v<PT>()...>*>
    Gaussian<T>::Gaussian(PT ...pars):
      abstract::distrbase<Gaussian<T> >(),
      _distribution(distr_t(pars...)) {}

    // =====================================================================
    template<typename T>
    auto Gaussian<T>::draw_impl() const -> value_t
#ifdef STG_NON_REPRODUCIBLE
    { return _distribution(this->_engine); };
#else
    { return _distribution(utils::shared_engine()); };
#endif

    // =====================================================================
    template<typename T>
    auto Gaussian<T>::max_distr_val_impl() const -> scalr_t
    { return one_over_sqrt2pi/sigma(); };

    // =====================================================================
    template<typename T>
    auto Gaussian<T>::distr_val_at_impl(locat_t location) const -> scalr_t
    {
      return stogeo::one_over_sqrt2pi/sigma()*
        std::exp( -(location-mu())*(location-mu())/(2*sigma()*sigma()) );
    };

  } //!rnd
} //!stogeo
