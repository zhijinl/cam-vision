// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Distribution.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Aug 14 23:23:29 2016 Zhijin Li
// Last update Mon Sep  3 11:45:37 2018 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_DISTRIBUTION_HH
# define STOGEO_DISTRIBUTION_HH

# include "stogeo/core.hh"

namespace stogeo
{

  // Fwd decl.
  namespace rnd
  {
    template<typename,int,typename,typename> class Distribution;
  }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::rnd::Distribution`
    /// class.
    ///
    template<typename ValueType, int Dim, typename Func, typename Sampler>
    struct specs<rnd::Distribution<ValueType,Dim,Func> >
    {
      static const stg_ids stg_id    =    stg_ids::STOGEO_RNDVR;
      static const int dim           =                      Dim;
      static const bool is_symmetric =                    false;
      typedef double                                    scalr_t;
      typedef point_dispatch_t<ValueType,Dim,Func> value_t;
      typedef point_dispatch_t<ValueType,Dim,Func> locat_t;
      typedef Func                                 distr_t;
      typedef Sampler                                   smplr_t;
    };
  }

  /// @ingroup group_stats
  namespace rnd
  {

    /// @ingroup group_stats
    ///
    /// @brief User-defined multivariate distribution.
    ///
    /// A distribution is a function **sums / integrates to 1**
    ///
    /// @param ValueType: scalar type used for sample values.
    /// @param Dim: dimension of the distribution.
    /// @Func: a functor or lambda describing the distribution
    /// function: a **pdf or pmf.**
    ///
    template<typename ValueType, int Dim, typename Func>
    class Distribution:
      public abstract::distrbase<Distribution<ValueType,Dim,Func> >
    {
    public:

      using exact_t = Distribution<ValueType,Dim,Func>;
      using specs_t =                traits::specs<exact_t>;
      using scalr_t =             typename specs_t::scalr_t;
      using value_t =             typename specs_t::value_t;
      using locat_t =             typename specs_t::locat_t;
      using distr_t =             typename specs_t::distr_t;

      /// @brief Default constructor.
      Distribution() = default;

      /// @breif Ctor.
      ///
      /// Taking `lvalue` ref of the functional distribution.
      ///
      explicit Distribution(const Func &distr):
        _distribution(distr) {};

      /// @breif Ctor.
      ///
      /// Taking `rvalue` ref of the functional distribution.
      ///
      explicit Distribution(Func &&distr):
        _distribution(std::move(distr)) {};

      /// @brief Default copy ctor.
      Distribution(const Distribution &) = default;

      /// @brief Default Move ctor.
      Distribution(Distribution &&) = default;

      /// @brief Default copy assignment operator.
      exact_t& operator=(const Distribution &) = default;

      /// @brief Default Move assignment operator.
      exact_t& operator=(Distribution &&) = default;

    private:

      /// Sample a realization following current distribution.
      value_t draw_impl() const;

      /// Return the max value of the uniform pdf.
      scalr_t max_distr_val_impl() const;

      /// Return the value at specified location of the current distr.
      ///
      /// @param location: input index where the distr will be evaluated.
      /// For Dim == 1, it is a scalr value. For Dim > 1, it must be an
      /// **Eigen fixed size column vector expression**.
      ///
      template<typename Location,
               typename = enable_if_t<dim_dispatch_v<Location>()==Dim> >
      scalr_t distr_val_at_impl(Location &&location) const;

      distr_t _distribution; //!< The current distribution function.
      scalr_t _distr_maxima; //!< Maximum value of the distribution.
    };

  }
}
