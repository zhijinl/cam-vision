// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Poisson.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Fri Nov 18 15:14:15 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace rnd
  {

    // =====================================================================
    template<typename T>
    template<typename PT, enable_if_t<is_arithmetic_v<PT>()>*>
    Poisson<T>::Poisson(PT mean):
      abstract::distrbase<Poisson<T> >(),
      _distribution(distr_t(mean)) {}

    // =====================================================================
    template<typename T>
    auto Poisson<T>::draw_impl() const -> value_t
#ifdef STG_NON_REPRODUCIBLE
    { return _distribution(this->_engine); };
#else
    { return _distribution(utils::shared_engine()); };
#endif

    // =====================================================================
    template<typename T>
    auto Poisson<T>::max_distr_val_impl() const -> scalr_t
    {
      auto __integral_mean = std::floor(mean());
      return std::pow(mean(),__integral_mean)*std::exp(-mean())/
        std::tgamma(__integral_mean+1);
    };

    // =====================================================================
    template<typename T>
    auto Poisson<T>::distr_val_at_impl(locat_t location) const -> scalr_t
    {
      return std::pow(mean(),location)*std::exp(-mean())/
        std::tgamma(location+1);
    };

  } //!rnd
} //!stogeo
