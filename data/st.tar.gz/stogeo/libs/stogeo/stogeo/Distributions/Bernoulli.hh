// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Bernoulli.hh for MO3
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Wed Feb 15 11:32:25 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_BERNOULLI_HH
# define STOGEO_BERNOULLI_HH

# include "distrbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace rnd { class Bernoulli; }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::rnd::Bernoulli`
    /// class.
    ///
    template<> struct specs<rnd::Bernoulli>
    {
      static const stg_ids stg_id    =   stg_ids::STOGEO_RNDVR;
      static const int dim           =                       1;
      static const bool is_symmetric =                   false;
      typedef double                                   scalr_t;
      typedef std::bernoulli_distribution::result_type value_t;
      typedef std::bernoulli_distribution::result_type locat_t;
      typedef std::bernoulli_distribution              distr_t;
      typedef typename distr_t::param_type             param_t;
    };

  }

  /// @ingroup group_stats
  namespace rnd
  {

    /// @ingroup group_stats
    ///
    /// @brief Class for Bernoulli distribution.
    ///
    class Bernoulli: public abstract::distrbase<Bernoulli>
    {
    public:

      using exact_t =              Bernoulli;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using value_t = typename specs_t::value_t;
      using locat_t = typename specs_t::locat_t;
      using distr_t = typename specs_t::distr_t;
      using param_t = typename specs_t::param_t;

      using parnt_t = abstract::distrbase<exact_t>;
      friend parnt_t;

      using parnt_t::draw;
      using parnt_t::distr_max;
      using parnt_t::operator();
      using parnt_t::reset_state;
      using parnt_t::reset_param;

      /// Ctor
      template<typename PT,
               enable_if_t<is_arithmetic_v<PT>()>* = nullptr>
      explicit Bernoulli(PT );

      /// Default ctor.
      Bernoulli() = default;

      /// Default copy ctor.
      Bernoulli(const Bernoulli &rhs) = default;

      /// Default move ctor.
      Bernoulli(Bernoulli &&rhs) = default;

      /// Default copy assignment operator.
      exact_t& operator=(const Bernoulli &rhs) = default;

      /// Default move assignment operator.
      exact_t& operator=(Bernoulli &&rhs) = default;

      /// Access the distribution param.
      ///
      /// @return The success rate.
      ///
      scalr_t success_rate() const { return _distribution.p(); }

    private:

      /// Sample a Uniform read r.v.
      value_t draw_impl() const;

      /// Return the max value of the Bernoulli pmf.
      ///
      /// @return The maximum of current Bernoulli pmf, i.e. max of
      /// success & failure rate.
      ///
      scalr_t max_distr_val_impl() const;

      /// Return the value at specified index of the Bernoulli pmf.
      ///
      /// @param location: input index where the pmf will be evaluated.
      /// @return The Bernoulli pmf evaluated at `location`.
      ///
      scalr_t distr_val_at_impl(locat_t location) const;

      mutable distr_t _distribution;
    };

  } //!rnd
} //!stogeo


# include "Bernoulli.hxx"
#endif //!STOGEO_BERNOULLI_HH
