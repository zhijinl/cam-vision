// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Poisson.hh for MO3
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Wed Feb 15 11:32:41 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_POISSON_HH
# define STOGEO_POISSON_HH

# include "distrbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace rnd { template<typename T> class Poisson; }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::rnd::Poisson`
    /// class.
    ///
    template<typename T> struct specs<rnd::Poisson<T> >
    {
      static const stg_ids stg_id    = stg_ids::STOGEO_RNDVR;
      static const int dim           =                     1;
      static const bool is_symmetric =                 false;
      typedef T                                      value_t;
      typedef double                                 scalr_t;
      typedef T                                      locat_t;
      typedef std::poisson_distribution<T>           distr_t;
      typedef typename distr_t::param_type           param_t;
    };
  }

  namespace rnd
  {

    /// @ingroup group_stats
    ///
    /// @brief Class for Poisson distribution.
    ///
    /// @param T: the scalar value, result type of each sampling.
    /// In this case must be an integral type.
    ///
    template<typename T> class Poisson
      : public abstract::distrbase<Poisson<T> >
    {
      static_assert(std::is_integral<T>::value,
                    "ERROR: POISSON DISTR RETURN INTEGRAL TYPES.");
    public:

      using exact_t =             Poisson<T>;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using value_t = typename specs_t::value_t;
      using locat_t = typename specs_t::locat_t;
      using distr_t = typename specs_t::distr_t;
      using param_t = typename specs_t::param_t;

      using parnt_t = abstract::distrbase<exact_t>;
      friend parnt_t;

      using parnt_t::draw;
      using parnt_t::distr_max;
      using parnt_t::operator();
      using parnt_t::reset_state;
      using parnt_t::reset_param;

      /// Ctor.
      template<typename PT,
               enable_if_t<is_arithmetic_v<PT>()>* = nullptr>
      explicit Poisson(PT mean);

      /// Default ctor.
      Poisson() = default;

      /// Default copy ctor.
      Poisson(const Poisson &rhs) = default;

      /// Default move ctor.
      Poisson(Poisson &&rhs) = default;

      /// Default copy assignment operator.
      exact_t& operator=(const Poisson &rhs) = default;

      /// Default move assignment operator.
      exact_t& operator=(Poisson &&rhs) = default;

      /// Access mean / variance.
      ///
      /// @return The mean value for current Poisson distribution.
      ///
      scalr_t mean() const { return _distribution.mean(); }

    private:

      /// Sample a Poisson r.v.
      ///
      /// @return The sampled value.
      ///
      value_t draw_impl() const;

      /// Return the max value of the Poisson pmf.
      ///
      /// @return The maximum of Poisson pmf, i.e. value at
      /// `floor(mean)`.
      ///
      scalr_t max_distr_val_impl() const;

      /// Return the value at specified index of the Poisson pmf.
      ///
      /// @param location: input index where the pmf will be evaluated.
      /// @return The value of Poisson pmf at `location`.
      ///
      scalr_t distr_val_at_impl(locat_t location) const;

      mutable distr_t _distribution;
    };

  } //!rnd
} //!stogeo


# include "Poisson.hxx"
#endif //!STOGEO_POISSON_HH
