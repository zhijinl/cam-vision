// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// RUniform.hh for MO3
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Wed Feb 15 11:32:47 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_RUNIFORM_HH
# define STOGEO_RUNIFORM_HH

# include "distrbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace rnd { template<typename T> class RUniform; }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::rnd::RUniform`
    /// class.
    ///
    template<typename T> struct specs<rnd::RUniform<T> >
    {
      static const stg_ids stg_id = stg_ids::STOGEO_RNDVR;
      static const int dim        =                     1;
      static const bool is_symmetric =               true;
      typedef T                                   scalr_t;
      typedef T                                   value_t;
      typedef T                                   locat_t;
      typedef std::uniform_real_distribution<T>   distr_t;
      typedef typename distr_t::param_type        param_t;
    };
  }

  /// @ingroup group_stats
  namespace rnd
  {

    /// @ingroup group_stats
    ///
    /// @brief Class for Uniform real distribution.
    ///
    /// @param T: the scalar value, result type of each sampling.
    ///
    template<typename T> class RUniform
      : public abstract::distrbase<RUniform<T> >
    {
      static_assert(std::is_floating_point<T>::value,
                    "ERROR: RUNIFORM EXPECTS FLOATING POINT ARG.");
    public:

      using exact_t =               RUniform<T>;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using value_t = typename specs_t::value_t;
      using locat_t = typename specs_t::locat_t;
      using distr_t = typename specs_t::distr_t;
      using param_t = typename specs_t::param_t;

      using parnt_t = abstract::distrbase<exact_t>;
      friend parnt_t;

      using parnt_t::draw;
      using parnt_t::distr_max;
      using parnt_t::operator();
      using parnt_t::reset_state;
      using parnt_t::reset_param;

      /// Ctor
      template<typename... PT,
               enable_if_all_t<is_arithmetic_v<PT>()...>* = nullptr>
      explicit RUniform(PT ...);

      /// @brief Default ctor.
      RUniform() = default;

      /// @brief Default copy ctor.
      RUniform(const RUniform &rhs) = default;

      /// @brief Default Move ctor.
      RUniform(RUniform &&rhs) = default;

      /// @brief Default copy assignment operator.
      exact_t& operator=(const RUniform &rhs) = default;

      /// @brief Default Move assignment operator.
      exact_t& operator=(RUniform &&rhs) = default;

      /// Access lower bound.
      scalr_t min() const { return _distribution.min(); };

      /// Access upper bound.
      scalr_t max() const { return _distribution.max(); };

    protected:

      /// Sample a Uniform real r.v.
      value_t draw_impl() const;

      /// Return the max value of the uniform pdf.
      scalr_t max_distr_val_impl() const;

      /// Return the value at specified index of the uniform pdf.
      ///
      /// @param location: input index where the pdf will be evaluated.
      ///
      scalr_t distr_val_at_impl(locat_t location) const;

    private:
      mutable distr_t _distribution;
    };

  } //!rnd
} //!stogeo


# include "RUniform.hxx"
#endif //!STOGEO_RUNIFORM_HH
