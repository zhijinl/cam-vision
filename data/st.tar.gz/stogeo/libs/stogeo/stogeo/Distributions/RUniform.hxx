// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// RUniform.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Fri Nov 18 15:14:10 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace rnd
  {

    // =====================================================================
    template<typename T>
    template<typename... PT,
             enable_if_all_t<is_arithmetic_v<PT>()...>*>
    RUniform<T>::RUniform(PT ...pars):
      abstract::distrbase<RUniform<T> >(),
      _distribution(pars...) {}

    // =====================================================================
    template<typename T>
    auto RUniform<T>::draw_impl() const -> value_t
#ifdef STG_NON_REPRODUCIBLE
    { return _distribution(this->_engine); };
#else
    { return _distribution(utils::shared_engine()); };
#endif

    // =====================================================================
    template<typename T>
    auto RUniform<T>::max_distr_val_impl() const -> scalr_t
    { return 1.0/(max()-min()); };

    // =====================================================================
    template<typename T>
    auto RUniform<T>::distr_val_at_impl(locat_t) const -> scalr_t
    { return 1.0/(max()-min()); };

  } //!rnd
} //!stogeo
