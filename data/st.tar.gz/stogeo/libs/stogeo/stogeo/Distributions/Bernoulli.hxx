// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// Bernoulli.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 18 18:39:07 2015 Zhijin Li
// Last update Fri Nov 18 15:13:49 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace rnd
  {
    // =====================================================================
    template<typename PT, enable_if_t<is_arithmetic_v<PT>()>*>
    Bernoulli::Bernoulli(PT p):
      abstract::distrbase<Bernoulli>(),
      _distribution(distr_t(p)) {}

    // =====================================================================
    inline auto Bernoulli::draw_impl() const -> value_t
#ifdef STG_NON_REPRODUCIBLE
    { return _distribution(this->_engine); };
#else
    { return _distribution(utils::shared_engine()); };
#endif

    // =====================================================================
    inline auto Bernoulli::max_distr_val_impl() const -> scalr_t
    { return std::max(success_rate(), 1-success_rate()); };

    // =====================================================================
    inline auto Bernoulli::distr_val_at_impl(locat_t location)
      const -> scalr_t
    { return location ? success_rate() : (1-success_rate()); };

  } //!rnd
} //!stogeo
