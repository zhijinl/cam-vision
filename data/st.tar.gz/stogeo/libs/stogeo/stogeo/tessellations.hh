// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// tessellations.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Feb 16 15:29:21 2016 Zhijin Li
// Last update Fri Aug  5 14:28:18 2016 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_TESSELLATIONS_HH
# define STOGEO_TESSELLATIONS_HH

# include "voro++/voro++.hh"
# include "Tessellations/VoronoiDiagram.hh"

#endif //!STOGEO_TESSELLATIONS_HH
