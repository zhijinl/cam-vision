// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// StatsOps.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Feb 21 22:42:35 2016 Zhijin Li
// Last update Wed Nov 15 18:10:55 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_STATSOPS_HH
# define STOGEO_STATSOPS_HH

# include "common/FwdIterator.hh"
# include "mipp/core/Histogram.hh"
# include "stogeo/core.hh"
# include "../Utilities/mipp_helpers.hh"
# include "../Utilities/computations.hh"


namespace stogeo
{
  /// @ingroup group_stats
  namespace stats
  {

    ///@{
    /// @ingroup group_stats
    ///
    /// @brief Comp mean of an STL vec or Eigen structure.
    ///
    /// @param vec: the input STL vector or Eigen structure.
    /// @return The computed mean value or column vector.
    ///
    template<typename Scalar, typename VT,
             enable_if_t<!is_eigen_v<VT>()>* = nullptr>
    inline Scalar mean(VT &&);

    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1>* = nullptr>
    inline Scalar mean(VT &&);

    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(),
                             dim_dispatch_v<MT>()!=1>* = nullptr>
    inline auto mean(MT &&) -> Eigen::Matrix<Scalar,dim_dispatch_v<MT>(),1>;
    ///@}

    ///@{
    /// @ingroup group_stats
    ///
    /// @brief Comp (co)variance of an Eigen structure or STL vector.
    ///
    /// If the input is an STL containers, it is treated as a coumn
    /// vector and a scalar variance value is computed. Same as when
    /// the input is an Eigen vector. When an Eigen matrix is given
    /// as input, the covariance matrix is estimated. In this case,
    /// the input matrix is assumed to be a storage of observation
    /// vectors in columns.
    ///
    /// @note The **Bessel correction** is applied by default. This
    /// means that the division factor is `n-1` instead of `n`, where
    /// n is the sample size. The correction can be deactivated by
    /// specifying a second `uncorrected` argument to the function.
    /// When the correction is deactivated, it is recommanded to use
    /// the third overload, which takes a second argument as the true
    /// mean value / vector, and use it to compute the variance /
    /// covariance.
    ///
    /// @param data: the input Eigen structure or STL vector.
    /// @return Computed variance value or covariance matrix.
    ///
    template<typename Scalar, typename VT,
             enable_if_t<!is_eigen_v<VT>()>* = nullptr>
    inline Scalar var(VT &&);

    template<typename Scalar, typename VT,
             enable_if_t<!is_eigen_v<VT>()>* = nullptr>
    inline Scalar var(VT &&, uncorrected_t corr);

    template<typename Scalar, typename VT,
             enable_if_t<!is_eigen_v<VT>()>* = nullptr>
    inline Scalar var(VT &&, Scalar true_mean);


    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1>* = nullptr>
    inline Scalar var(VT &&);

    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1>* = nullptr>
    inline Scalar var(VT &&, uncorrected_t corr);

    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1>* = nullptr>
    inline Scalar var(VT &&, Scalar true_mean);


    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(),
                             dim_dispatch_v<MT>()!=1>* = nullptr>
    inline auto var(MT &&)
      -> Eigen::Matrix<Scalar, dim_dispatch_v<MT>(), dim_dispatch_v<MT>()>;

    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(),
                             dim_dispatch_v<MT>()!=1>* = nullptr>
    inline auto var(MT &&, uncorrected_t corr)
      -> Eigen::Matrix<Scalar, dim_dispatch_v<MT>(), dim_dispatch_v<MT>()>;

    template<typename Scalar, typename MT, typename VT,
             enable_if_all_t<is_eigen_v<MT>(),
                             is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1,
                             dim_dispatch_v<MT>()!=1>* = nullptr>
    inline auto var(MT &&, VT &&true_mean)
      -> Eigen::Matrix<Scalar, dim_dispatch_v<MT>(), dim_dispatch_v<MT>()>;
    ///@}

    /// @ingroup group_stats
    ///
    /// @brief Compute histogram from an eigen vector.
    ///
    /// @param vec: the input Eigen vector. Must be colmajored.
    /// @param bin_width: bin width.
    /// @param bord_ext: # of bins to be extended to each side of histogram.
    /// @return: the computed mipp::Histogram.
    ///
    template<typename VT, typename = enable_if_t<is_eigen_v<VT>()> >
    inline auto comp_histogram(VT &&, float , int bord_ext=0)
      -> mipp::Histogram<typename decay_t<VT>::RealScalar>;

  }
}


# include "StatsOps.hxx"
#endif
