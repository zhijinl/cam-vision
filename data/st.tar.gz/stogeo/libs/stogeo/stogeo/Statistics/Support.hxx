// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Support.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 17 23:11:40 2016 Zhijin Li
// Last update Sat Sep  9 18:47:53 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace stats
  {

    // =====================================================================
    template<typename Scalar, int Dim> template<typename Data>
    void Support<Scalar,Dim,false>::set_from_data(Data &&data,
                                                  scalr_t scale)
    {
      lattice().set_bound
        ( utils::scale_bound
          ( utils::comp_bound(std::forward<Data>(data)), scale ) );
    }

    // =====================================================================
    template<typename Shape> template<typename Func>
    void Support<Shape,0,true>::traverse(Func handler) const
    {
      _lattc.traverse
        ([this,handler] (const locat_t& __loc)
         {
           if( _shape.inside_test(__loc) ) handler(__loc);
         });
    }

  } //!stats

  namespace utils
  {

    // =====================================================================
    template<typename Scalar, typename Data, typename Params>
    auto make_support(Data && data, Params &&params, double scale)
      -> stats::Support<Scalar,dim_dispatch_v<Params>()>
    {
      constexpr int __dim = dim_dispatch_v<Params>();

      return stats::Support<Scalar, __dim>
        ( utils::scale_bound
          ( utils::comp_bound(std::forward<Data>(data)), scale ),
          std::forward<Params>(params) );
    }

  } //!utils
} //!stogeo
