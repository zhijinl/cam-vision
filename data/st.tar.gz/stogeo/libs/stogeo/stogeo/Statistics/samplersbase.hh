// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// samplersbase.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Feb 29 18:59:43 2016 Zhijin Li
// Last update Sat Sep 16 18:20:07 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_SAMPLERSBASE_HH
# define STOGEO_SAMPLERSBASE_HH

# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "Kernels.hh"


namespace stogeo
{
  namespace stats
  {
    namespace abstract
    {

      /// The abstract class samplersbase.
      template<typename EXACT>
      class samplersbase: public internal__::root__<EXACT>
      {
      private:

        using internal__::root__<EXACT>::   exact;
        using specs_t =      traits::specs<EXACT>;
        using scalr_t = typename specs_t::scalr_t;
        using sampl_t = typename specs_t::sampl_t;

      protected:
        /// Default ctor.
        samplersbase() = default;

        /// Draw a sample.
        ///
        /// @return: the sampled value.
        ///
        sampl_t draw() const;

        /// Draw samples into an Eigen dynamic vector.
        ///
        /// @param vec: the input Eigen dynamic vector. Can be row or column
        /// ordered
        ///
        template<typename Vector,
                 enable_if_all_t<dim_dispatch_v<Vector>()==1,
                                 is_eigen_dynamic_vec_v<Vector>()>* = nullptr>
        void draw(Vector &vec);

        /// Draw samples into an Eigen structure other than a dynamic vector.
        ///
        /// @param structure: the input Eigen struct. **Must be col ordered**.
        ///
        template<typename Struct,
                 enable_if_all_t<dim_dispatch_v<Struct>()!=1,
                                 is_eigen_v<Struct>()>* = nullptr>
        void draw(Struct &structure);

        /// @brief Reset the sampler state.
        ///
        /// This resets the state of the internal random variables and
        /// distributions.
        ///
        /// Together with the `stogeo::utils::reset_shared_engine()`
        /// function, they can be used to reproduce the same simulation
        /// results.
        ///
        EXACT& reset_state() { return exact().reset_state_impl(); }

      };

    } //!abstract
  } //!stats
} //!stogeo


# include "samplersbase.hxx"
#endif //!STOGEO_SAMPLERSBASE_HH
