// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// StatsOps.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri May 27 13:19:29 2016 Zhijin Li
// Last update Wed Nov 15 18:06:06 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace stats
  {

    // =====================================================================
    template<typename Scalar, typename VT, enable_if_t<!is_eigen_v<VT>()>*>
    inline Scalar mean(VT &&vec)
    {
      return utils::ref_as_eigen(vec).mean();
    }

    // =====================================================================
    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(), dim_dispatch_v<VT>()==1>*>
    inline Scalar mean(VT &&vec)
    {
      return vec.mean();
    }

    // =====================================================================
    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(), dim_dispatch_v<MT>()!=1>*>
    inline auto mean(MT &&mat)
      -> Eigen::Matrix<Scalar,dim_dispatch_v<MT>(),1>
    {
      return mat.rowwise().mean().template cast<Scalar>();
    }

    // =====================================================================
    template<typename Scalar, typename VT, enable_if_t<!is_eigen_v<VT>()>*>
    inline Scalar var(VT &&vec)
    {
      auto __vec_eigen = utils::ref_as_eigen(vec);
      // auto __factor = 1.0/static_cast<Scalar>(__vec_eigen.size()-1);

      return (__vec_eigen.array() - __vec_eigen.mean()).square().sum()/
        static_cast<Scalar>(__vec_eigen.size()-1);

      // return (__vec_eigen.array()*__vec_eigen.array()).sum()*__factor -
      //   __vec_eigen.mean()* __vec_eigen.mean()*__vec_eigen.size()*__factor;
    }

    // =====================================================================
    template<typename Scalar, typename VT, enable_if_t<!is_eigen_v<VT>()>*>
    inline Scalar var(VT &&vec, uncorrected_t)
    {
      auto __vec_eigen = utils::ref_as_eigen(vec);
      // return (__vec_eigen.array()*__vec_eigen.array()).sum()/
      //   static_cast<Scalar>(__vec_eigen.size()) - __vec_eigen.mean()*
      //   __vec_eigen.mean();
      return (__vec_eigen.array() - __vec_eigen.mean()).square().sum()/
        static_cast<Scalar>(__vec_eigen.size());
    }

    // =====================================================================
    template<typename Scalar, typename VT, enable_if_t<!is_eigen_v<VT>()>*>
    inline Scalar var(VT &&vec, Scalar true_mean)
    {
      auto __vec_eigen = utils::ref_as_eigen(vec);
      return (__vec_eigen.array()*__vec_eigen.array()).sum()/
        static_cast<Scalar>(__vec_eigen.size()) - true_mean*true_mean;
    }

    // =====================================================================
    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(), dim_dispatch_v<VT>()==1>*>
    inline Scalar var(VT &&vec)
    {
      auto __factor = 1.0/static_cast<Scalar>(vec.size()-1);
      return (vec.array()*vec.array()).sum()*__factor -
        vec.mean()*vec.mean()*__factor*vec.size();
    }

    // =====================================================================
    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(), dim_dispatch_v<VT>()==1>*>
    inline Scalar var(VT &&vec, uncorrected_t)
    {
      return (vec.array()*vec.array()).sum()/static_cast<Scalar>(vec.size())
        -vec.mean()*vec.mean();
    }

    // =====================================================================
    template<typename Scalar, typename VT,
             enable_if_all_t<is_eigen_v<VT>(), dim_dispatch_v<VT>()==1>*>
    inline Scalar var(VT &&vec, Scalar true_mean)
    {
      return (vec.array()*vec.array()).sum()/static_cast<Scalar>(vec.size())
        -true_mean*true_mean;
    }

    // =====================================================================
    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(), dim_dispatch_v<MT>()!=1>*>
    inline auto var(MT &&data)
      -> Eigen::Matrix<Scalar,dim_dispatch_v<MT>(),dim_dispatch_v<MT>()>
    {
      auto __mean = mean<Scalar>(data);
      auto __factor = 1.0/static_cast<Scalar>(data.cols()-1);
      return (data*data.transpose()).template cast<Scalar>()*__factor
        - (__mean*__mean.transpose())*__factor*data.cols();
    }

    // =====================================================================
    template<typename Scalar, typename MT,
             enable_if_all_t<is_eigen_v<MT>(), dim_dispatch_v<MT>()!=1>*>
    inline auto var(MT &&data, uncorrected_t)
      -> Eigen::Matrix<Scalar,dim_dispatch_v<MT>(),dim_dispatch_v<MT>()>
    {
      auto __mean = mean<Scalar>(data);
      return (data*data.transpose()).template cast<Scalar>()/(data.cols())
        - (__mean*__mean.transpose());
    }

    // =====================================================================
    template<typename Scalar, typename MT, typename VT,
             enable_if_all_t<is_eigen_v<MT>(),
                             is_eigen_v<VT>(),
                             dim_dispatch_v<VT>()==1,
                             dim_dispatch_v<MT>()!=1>*>
    inline auto var(MT &&data, VT &&true_mean)
      -> Eigen::Matrix<Scalar,dim_dispatch_v<MT>(),dim_dispatch_v<MT>()>
    {
      return (data*data.transpose()).template cast<Scalar>()/(data.cols())
        - (true_mean * true_mean.transpose());
    }

    // =====================================================================
    template<typename VT, typename>
    inline auto comp_histogram(VT &&vec, float bin_width, int bord_ext)
      -> mipp::Histogram<typename decay_t<VT>::RealScalar>
    {
      using T = typename decay_t<VT>::RealScalar;
      return mipp::Histogram<T>( cmn_domain_type(mipp::Histogram<T>)
                                 (bin_width,
                                  vec.minCoeff(),
                                  vec.maxCoeff(),
                                  bord_ext),
                                 utils::vec2signal(std::forward<VT>(vec)) );
    }

  }
}
