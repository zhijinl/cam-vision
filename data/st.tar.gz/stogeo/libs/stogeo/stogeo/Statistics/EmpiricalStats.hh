// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// EmpiricalStats.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Aug 21 16:49:02 2016 Zhijin Li
// Last update Wed Feb 15 11:40:02 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_EMPIRICAL_STATS
# define STOGEO_EMPIRICAL_STATS


namespace stogeo
{
  // Fwd decl.
  namespace stats { template<typename,int,typename,int> class EmpiricalStats; }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits property for the `stogeo::stats::EmpiricalStats`
    /// class.
    ///
    template<typename Scalr, int PtDim, typename Value, int ValDim>
    struct specs<stats::EmpiricalStats<Scalr,PtDim,Value,ValDim> >
    {
      static constexpr int locat_dim = PtDim;
      static constexpr int value_dim = ValDim;
      typedef Scalr                                        scalr_t;
      typedef Value                                        value_t;
      typedef Eigen::Matrix<scalr_t,PtDim,Eigen::Dynamic>  evals_t;
      typedef Eigen::Matrix<value_t,ValDim,Eigen::Dynamic> stats_t;
    };
  }

  /// @ingroup group_stats
  namespace stats
  {

    /// @ingroup group_stats
    ///
    /// @brief Empirical statistics container.
    ///
    /// Wraps a matrix / vector for empirically estimated statistics.
    /// And a point matrix / vector with corresponding evaluation points.
    ///
    /// @param Scalr: data type for an evaluation point.
    /// @param Value: data type for a statistic value.
    /// @param PtDim: dimension of evaluation points.
    /// @param ValDim: dimension of evaluated statistics.
    ///
    template<typename Scalr, int PtDim, typename Value, int ValDim>
    class EmpiricalStats
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t = EmpiricalStats<Scalr,PtDim,Value,ValDim>;
      using specs_t = traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using value_t = typename specs_t::value_t;
      using evals_t = typename specs_t::evals_t;
      using stats_t = typename specs_t::stats_t;

      static constexpr int locat_dim = specs_t::locat_dim;
      static constexpr int value_dim = specs_t::value_dim;

      /// Defaulr constructor.
      EmpiricalStats() = default;

      /// Ctor.
      ///
      /// Resize the number of elements in point & value matrices.
      /// @param n_elem: the number of element to be value-initialized.
      ///
      explicit EmpiricalStats(int n_elem):
        _locations(PtDim, n_elem), _statistic(ValDim, n_elem) {}

      /// Ctor.
      ///
      /// Initialize with point & value matrix / vector.
      /// @param pt_matrix: the input point matrix.
      /// @param estimates: the input estimates (value matrix / vector).
      ///
      template<typename PtMat, typename ValMat,
               enable_if_all_t<is_eigen_v<PtMat>(),
                               is_eigen_v<ValMat>(),
                               eigen_rows_v<PtMat>()==PtDim,
                               eigen_rows_v<ValMat>()==ValDim>* = nullptr>
      EmpiricalStats(PtMat &&pt_matrix, ValMat &&estimates):
        _locations(pt_matrix), _statistic(estimates) {}

      /// @return The number of elements.
      ///
      int n_elem() const { return _locations.cols(); }

      /// Const access all points.
      ///
      /// @return Const reference to point matrix / vector.
      ///
      const evals_t& points() const { return _locations; }

      /// Non-const access all points.
      ///
      /// @return Non-const reference to point matrix / vector.
      ///
      evals_t& points() { return _locations; }

      /// Const access all estimated statistics.
      ///
      /// @return Const reference to estimates matrix / vector.
      ///
      const stats_t& stats() const { return _statistic; }

      /// Non-const access all estimates.
      ///
      /// @return Non-const reference to estimates matrix / vector.
      ///
      stats_t& stats() { return _statistic; }

      /// Const indexed-access of an evaluation point.
      ///
      /// @param index: the access index.
      /// @return Const ref to indexed location in the point matrix / vector.
      ///
      auto point_at(int index) const
        -> decltype(utils::elem_at(add_const_t<evals_t>(),0))
      { return utils::elem_at(_locations,index); }

      /// Non-const indexed-access of an evaluation point.
      ///
      /// @param index: the access index.
      /// @return Non-const ref to indexed location in the point matrix / vector.
      ///
      auto point_at(int index) -> decltype(utils::elem_at(evals_t(),0))
      { return utils::elem_at(_locations,index); }

      /// Const indexed-access of an estimated value.
      ///
      /// @param index: the access index.
      /// @return Const ref to estimated value in the matrix / vector.
      ///
      auto value_at(int index) const
        -> decltype(utils::elem_at(add_const_t<stats_t>(),0))
      { return utils::elem_at(_statistic,index); }

      /// Non-const indexed-access of an estimated value.
      ///
      /// @param index: the access index.
      /// @return Non-const ref to estimated value in the matrix / vector.
      ///
      auto value_at(int index) -> decltype(utils::elem_at(stats_t(),0))
      { return utils::elem_at(_statistic,index); }

    private:

      evals_t _locations; //<! Point matrix/vector containing eval points.
      stats_t _statistic; //<! Value matrix/vector containing estimation values.

    };

  } //!stats
} //!stogeo


#endif //!STOGEO_EMPIRICAL_STATS
