// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Support.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 17 23:07:54 2016 Zhijin Li
// Last update Sat Sep  9 18:44:14 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_SUPPORT_HH
# define STOGEO_SUPPORT_HH

# include "stogeo/geometry.hh"
# include "stogeo/Discrete/Lattice.hh"


namespace stogeo
{
  namespace stats
  {
    template<typename T, int Dim=0, bool cond=is_stg_shape_v<T>()>
    class Support {};
  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the
    /// `stogeo::stats::Support<Scalar,Dim,false>` class:
    /// **the bounding box support.**
    ///
    template<typename Scalar, int Dim>
    struct specs<stats::Support<Scalar,Dim,false> >
    {
      static constexpr int dim    =                   Dim;
      static const stg_ids stg_id = stg_ids::STOGEO_SUPPR;
      typedef Scalar                              scalr_t;
      typedef discrete::Lattice<scalr_t,dim>      lattc_t;
      typedef typename lattc_t::locat_t           locat_t;
    };

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the
    /// `stogeo::stats::Support<Shape,0,true>` class:
    /// **the geometric support.**
    ///
    template<typename Shape> struct specs<stats::Support<Shape,0,true> >
    {
      static constexpr int dim    =     specs<Shape>::dim;
      static const stg_ids stg_id = stg_ids::STOGEO_SUPPR;
      typedef typename specs<Shape>::scalr_t      scalr_t;
      typedef discrete::Lattice<scalr_t,dim>      lattc_t;
      typedef typename lattc_t::locat_t           locat_t;
    };
  }

  namespace stats
  {

    /// @ingroup group_stats
    ///
    /// @brief Class for support with bounding box domain.
    ///
    /// It is equivalent to a lattice system by wrapping a
    /// lattice system inside.
    ///
    /// @param Scalar: type used as scalar for floating-point
    /// computations.
    /// @param Dim: an integer indicating dimension of the
    /// support.
    ///
    template<typename Scalar, int Dim> class Support<Scalar,Dim,false>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t = Support<Scalar,Dim,false>;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using lattc_t = typename specs_t::lattc_t;
      using locat_t = typename specs_t::locat_t;

      static constexpr int dim =   specs_t::dim;

      /// @brief Ctor.
      ///
      /// Forwards arguments to construct a bounding box support.
      /// It is just a wrapper for a lattice system.
      ///
      /// @param args: variadic arguments, must match exactly
      /// those for the discrete::Lattice<Scalar,Dim> class.
      ///
      template<typename ...Args>
      explicit Support(Args &&...args):
        _lattc(std::forward<Args>(args)...) {};

      /// @brief Traverse all locations of the Support using
      /// internal step-size.
      ///
      /// @param handler: the functional handler as in Lattice
      /// indicating an action on each location. A lambda or a
      /// functional object. It is recommanded to write generic
      /// functional object / lambda (if c++14 available), otherwise
      /// the input of functor should be const ref to locat_t.
      ///
      template<typename Func> void traverse(Func handler) const
      { _lattc.traverse(handler); }

      /// @brief Const access the internal lattice system.
      ///
      /// @return Const reference to the internal lattice system.
      ///
      const lattc_t& lattice() const { return _lattc; }

      /// @brief Non-const access the internal lattice system.
      ///
      /// @return Non-const reference to the internal lattice
      /// system.
      ///
      lattc_t& lattice() { return _lattc; }

      /// @brief Empirically set internal lattice bound from input
      /// data, with possible scaling.
      ///
      /// @param data: the input data. An Eigen vector or matrix.
      /// - When it's a dynamic Eigen vector, it can be **either
      ///   row or col ordered**.
      /// - When it's a matrix, it**must be column ordered**, each
      ///   column represents a data point.
      /// @param scale: a scaling factor indicating magnification
      /// in each dim of the computed bounding_box.
      ///
      template<typename Data>
      void set_from_data(Data &&data, scalr_t scale=1.2);

    private:

      lattc_t _lattc;
    };

    /// @ingroup group_stats
    ///
    /// @brief Class for geometric support.
    ///
    /// This support class holds inside a geometric shape. It
    /// contains also a lattice system where all discrete locations
    /// can be traversed together with a functional handler.
    /// Handler evaluations related to this class of support
    /// are done only on locations inside the held shape.
    ///
    /// @note Works only for Dim > 1, since stogeo::shapes are not
    /// well defined for Dim == 1.
    ///
    /// @param Shape: type for geometric shape.
    ///
    template<typename Shape> class Support<Shape,0,true>
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t =     Support<Shape,0,true>;
      using specs_t =    traits::specs<exact_t>;
      using scalr_t = typename specs_t::scalr_t;
      using lattc_t = typename specs_t::lattc_t;
      using locat_t = typename specs_t::locat_t;

      static constexpr int dim =   specs_t::dim;

      /// @brief Ctor.
      ///
      /// Construct a geometric support from input shape and spacing.
      ///
      /// @param shape: a stogeo::shapes object.
      /// @param steps: step-sizes for lattice traversal, used for
      /// evaluation of discrete locations inside the support.
      ///
      template<typename Input, typename Steps,
               typename = enable_if_t<is_stg_shape_v<Input>()> >
      Support(Input &&shape, Steps &&steps):
        _shape( std::forward<Input>(shape) ),
        _lattc( _shape.bounding_box(), std::forward<Steps>(steps)) {};

      /// @brief Traverse all locations of the Support.
      ///
      /// The handler will only apply on locations inside the
      /// support shape.
      ///
      /// @param handler: the functional handler as in `Lattice`
      /// indicating an action on each location. A lambda or a
      /// functional oject. It is recommanded to write generic
      /// functional oject / lambda (if c++14 available), otherwise
      /// the input of functor should be const ref to locat_t.
      ///
      template<typename Func>
      void traverse(Func handler) const;

      /// @brief Const access the internal lattice system.
      ///
      /// @return Const reference to the internal lattice system.
      ///
      const lattc_t& lattice() const { return _lattc; }

      /// @brief Non-const access the internal lattice system.
      ///
      /// @return Non-const reference to the internal lattice system.
      ///
      lattc_t& lattice() { return _lattc; }

      /// @brief Const access the internal shape.
      ///
      /// @return Const reference to the internal shape.
      ///
      const Shape& shape() const { return _shape; }

      /// @brief Non-const access the internal shape.
      ///
      /// @return Non-const reference to the internal shape.
      ///
      Shape& shape() { return _shape; }

    private:

      Shape   _shape; //<! Internal shape determining the bound.
      lattc_t _lattc; //<! The internal lattice system for location evals.
    };

  } //!stats

  /// @ingroup group_utils
  namespace utils
  {

    /// @ingroup group_stats group_utils
    ///
    /// @brief Create an empirical support from input data points.
    ///
    /// A `scale` factor can be applied to scale up the
    /// computed bound in each direction by a factor.
    ///
    /// @param Scalar: template argument for floating-point scalar
    /// type.
    /// @param data: the input data.
    /// - Can be a row or column orderd vector for 1D **dynamic**
    ///   case.
    /// - But for Dim > 1 or **fix sized** vector, it must be column
    ///   ordered.
    /// @param sizes: specifies bound's discrete sizes or floating-point scalar/Eigen point for step sizes . An
    /// Eigen Dim x 1 point if Dim > 1. A scalar when Dim == 1.
    /// @return The created support.
    ///
    template<typename Scalar, typename Data, typename Params>
    auto make_support(Data && data, Params &&params, double scale=1)
      -> stats::Support<Scalar,dim_dispatch_v<Params>()>;

  } //!utils

} //!stogeo


# include "Support.hxx"
#endif //!STOGEO_SUPPORT_HH
