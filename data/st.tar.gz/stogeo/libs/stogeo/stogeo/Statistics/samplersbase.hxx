// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// samplersbase.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Feb 29 19:12:39 2016 Zhijin Li
// Last update Sun Nov 20 22:26:56 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace stats
  {
    namespace abstract
    {
      // =====================================================================
      template<typename EXACT>
      auto samplersbase<EXACT>::draw() const -> sampl_t
      { return exact().draw_impl(); }

      // =====================================================================
      template<typename EXACT>
      template<typename Vector,
               enable_if_all_t<dim_dispatch_v<Vector>()==1,
                               is_eigen_dynamic_vec_v<Vector>()>*>
      void samplersbase<EXACT>::draw(Vector &vec)
      {
        for(int __n = 0; __n < vec.size(); __n++)
            vec(__n) = draw();
      }

      // =====================================================================
      template<typename EXACT>
      template<typename Struct,
               enable_if_all_t<dim_dispatch_v<Struct>()!=1,
                               is_eigen_v<Struct>()>*>
      void samplersbase<EXACT>::draw(Struct &structure)
      {
        for(int __c = 0; __c < structure.cols(); __c++)
          structure.col(__c) = draw();
      }

    } //!abstract
  } //!stats
} //!stogeo
