// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// KernelSmoothing.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 17 10:22:38 2016 Zhijin Li
// Last update Sat Sep  9 20:20:07 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace stats
  {

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Tag, typename Data, typename Suppr, typename Bandw,
             typename>
    auto KernelSmooth<Kernel,Dim>::
    estimate(Tag tag, Data &&data, Suppr &&support, Bandw &&band_width)
      const -> estim_t<Data>
    {
      _kernel.reset(std::forward<Bandw>(band_width));
      return estimate_impl(std::forward<Data>(data),
                           std::forward<Suppr>(support), tag);
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Tag, typename Data, typename Suppr,
             enable_if_all_t<is_eigen_v<Data>(),is_stg_support_v<Suppr>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate(Tag tag, Data &&data, Suppr &&support) const -> estim_t<Data>
    {
      _kernel.reset(kern::silverman_bw<value_t>(data));
      return estimate_impl(data, std::forward<Suppr>(support), tag);
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Tag, typename Data, typename Bandw,
             enable_if_all_t<is_eigen_v<Data>(), !is_stg_support_v<Bandw>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate(Tag tag, Data &&data, Bandw &&band_width)
      const -> estim_t<Data>
    {
      _kernel.reset(std::forward<Bandw>(band_width));
      return estimate_impl
        (data, utils::make_support<value_t>
         (data, utils::make_const_pt<value_t,Dim>(0.1), 1.2), tag);
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Tag, typename Data, typename>
    auto KernelSmooth<Kernel,Dim>::estimate(Tag tag, Data &&data) const
      -> estim_t<Data>
    {
      _kernel.reset(kern::silverman_bw<value_t>(data));
      return estimate_impl
        (data, utils::make_support<value_t>
         (data, utils::make_const_pt<value_t,Dim>(0.1), 1.2), tag);
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Data, typename Suppr,
             enable_if_t<is_stg_support_v<Suppr>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate_impl(Data &&data, Suppr &&support, cdf_tag_t)
      const -> estim_t<Data>
    {
      auto __cdf = estimate_impl(data, std::forward<Suppr>(support), pdf);
      __cdf.stats() = utils::cumsum(__cdf.stats())*
        support.lattice().elem_volume();
      return __cdf;
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Data, typename Suppr,
             enable_if_t<is_stg_support_v<Suppr>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate_impl(Data &&data, Suppr &&support, icdf_tag_t)
      const -> estim_t<Data>
    {
      assert(false && "this function has not been implemented yet ...");
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Data, typename Suppr,
             enable_if_t<is_stg_support_v<Suppr>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate_impl(Data &&data, Suppr &&support, pdf_tag_t)
      const -> estim_t<Data>
    {
      auto __result =
        estimate_impl(data, std::forward<Suppr>(support), inten);
      __result.stats() /= utils::n_elem(data);
      return __result;
    }

    // =====================================================================
    template<typename Kernel, int Dim>
    template<typename Data, typename Suppr,
             enable_if_t<is_stg_support_v<Suppr>()>*>
    auto KernelSmooth<Kernel,Dim>::
    estimate_impl(Data &&data, Suppr &&support, inten_tag_t)
      const -> estim_t<Data>
    {
      using __locat_t = typename traits::specs<decay_t<Suppr> >::locat_t;
      estim_t<Data> __result(support.lattice().card());

      int __count = 0;
      support.traverse
        ([this, &data, &__count, &__result] (const __locat_t &__loc)
         {
           __result.point_at(__count) = __loc;
           __result.value_at(__count) = _kernel(data, __loc);
           ++__count;
         });
      return __result;
    }

  } //!stats
} //!stogeo
