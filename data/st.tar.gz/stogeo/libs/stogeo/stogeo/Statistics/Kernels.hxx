// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Kernels.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Feb 22 18:29:57 2016 Zhijin Li
// Last update Sun Nov 20 22:21:04 2016 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace kern
  {

    // =====================================================================
    template<typename Value, typename Data,
             enable_if_t<is_eigen_vec_v<Data>()>*>
    Value silverman_bw(Data &&data)
    {
      return 1.06 * std::sqrt(stats::var<Value>(data)) *
        std::pow(data.size(),-0.2);
    }

    // =====================================================================
    template<typename Value, typename Data,
             enable_if_t<is_eigen_mat_v<Data>()>*>
    auto silverman_bw(Data &&data)
      -> Eigen::Matrix<Value,dim_dispatch_v<Data>(),dim_dispatch_v<Data>()>
    {
      constexpr int __dim = dim_dispatch_v<Data>();
      using __matrx_t = Eigen::Matrix<Value,__dim,__dim>;
      Value __coeff = std::pow(4.0/(__dim+2)/data.cols(),2.0/(__dim+4));

      return __matrx_t{ Eigen::LDLT<__matrx_t>
          ( stats::var<Value>(data) ).vectorD().asDiagonal() * __coeff };
    }

    // =====================================================================
    template<typename Value, typename Data>
    auto empirical_support(Data &&data)
      -> stats::Support<Value,dim_dispatch_v<Data>()>
    {
      return utils::make_support<Value>
        (std::forward<Data>(data), utils::make_const_pt
         <Value,dim_dispatch_v<Data>()>(0.1), 1.2);
    }

    // =====================================================================
    template<typename Value, int Dim>
    template<typename Bandw, enable_if_t<is_eigen_v<Bandw>()>*>
    GaussKernel<Value,Dim>::GaussKernel(Bandw &&bw_mat, value_t eps):
      _inv_sqrtbdw( utils::sqrt_mat(bw_mat) ),
      _inv_sqrtdet( std::pow(bw_mat.determinant(),-0.5) ),
      _cut_off_val( eval_cutoff(bw_mat, eps) ) {}

    // =====================================================================
    template<typename Value, int Dim>
    template<typename Matrix, typename Point,
             enable_if_all_t<is_eigen_mat_v<Matrix>(), is_eigen_v<Point>()>*>
    auto GaussKernel<Value,Dim>::operator()(Matrix &&data, Point &&pos) const
      -> value_t
    {
      static_assert( dim_dispatch_v<Matrix>() == dim_dispatch_v<Point>(),
                     "POINT AND DATA VEC DIMENSION MISMATCH." );

      Value __result = 0.0;
#pragma omp parallel for reduction (+:__result)
      for(int __n = 0; __n < data.cols(); ++__n)
      {
        Eigen::Matrix<Value,Dim,1> __curr = _inv_sqrtbdw*(data.col(__n)-pos);
        if( __curr.squaredNorm() < _cut_off_val )
          __result += (*this)(__curr);
      }
      return __result*one_over_sqrt2pi_pow<Dim>()*_inv_sqrtdet;
    }

    // =====================================================================
    template<typename Value, int Dim>
    template<typename Matrix, typename Weights, typename Point,
             enable_if_all_t<is_eigen_mat_v<Matrix>(),
                             is_eigen_vec_v<Weights>(),
                             is_eigen_v<Point>()>*>
    auto GaussKernel<Value,Dim>::operator()(Matrix &&data,
                                            Weights &&weights,
                                            Point &&pos) const -> value_t
    {
      static_assert( dim_dispatch_v<Matrix>() == dim_dispatch_v<Point>(),
                     "POINT AND DATA VEC DIMENSION MISMATCH." );
      // TODO: NEED TO PROPERLY IMPLEMENT WEIGHTING SCHEME.
      Value __result = 0.0;
#pragma omp parallel for reduction (+:__result)
      for(int __n = 0; __n < data.cols(); ++__n)
      {
        Eigen::Matrix<Value,Dim,1> __curr = _inv_sqrtbdw*(data.col(__n)-pos);
        if( __curr.squaredNorm() > _cut_off_val )
          __result += (*this)(__curr)*weights(__n);
      }
      return __result*one_over_sqrt2pi_pow<Dim>()*_inv_sqrtdet;
    }

    // =====================================================================
    template<typename Value, int Dim> template<typename Bandw>
    void GaussKernel<Value,Dim>::reset(Bandw &&bandwidth, value_t eps)
    {
      _inv_sqrtbdw = utils::sqrt_mat(bandwidth);
      _inv_sqrtdet = std::pow(bandwidth.determinant(),-0.5);
      _cut_off_val = eval_cutoff(bandwidth, eps);
    }

    // =====================================================================
    template<typename Value, int Dim> template<typename Bandw>
    auto GaussKernel<Value,Dim>::eval_cutoff(Bandw &&bandwidth, value_t eps)
      const -> value_t
    {
      return -2*std::log(eps*sqrt2pi_pow<Dim>()*std::sqrt
                         (bandwidth.determinant()));
    }

    // =====================================================================
    template<typename Value, int Dim>
    template<typename Point, enable_if_all_t<is_eigen_v<Point>()>*>
    auto GaussKernel<Value,Dim>::operator()(Point pos) const -> value_t
    {
      return std::exp(-0.5 * pos.squaredNorm());
    }

    // =====================================================================
    template<typename Value> template<typename Vec>
    auto GaussKernel<Value,1>::operator()(Vec &&data, value_t pos) const
      -> value_t
    {
      static_assert( (dim_dispatch_v<Vec>()==1 ), "EXPECT A VECTOR." );

      Value __result = 0.0;
#pragma omp parallel for reduction (+:__result)
      for(int __n = 0; __n < data.size(); ++__n)
        if( std::abs(data(__n)-pos) < _cutoff )
          __result += (*this)((data(__n)-pos)*_inv_bw);

      return __result*one_over_sqrt2pi*_inv_bw;
    }

    // =====================================================================
    template<typename Value>  template<typename Vec, typename Weights>
    auto GaussKernel<Value,1>::operator()(Vec &&data,
                                          Weights &&weights,
                                          value_t pos) const -> value_t
    {
      static_assert( (dim_dispatch_v<Vec>()==1 ), "EXPECT A VECTOR." );
      // TODO: NEED TO PROPERLY IMPLEMENT WEIGHTING SCHEME.
      // TODO: CHECK OUT THE ELEMINATING BRANCH PREDICTION OPTMIZATION!!
      Value __result = 0.0;
#pragma omp parallel for reduction (+:__result)
      for(int __n = 0; __n < data.size(); ++__n)
        if( std::abs(data(__n)-pos) < _cutoff )
          __result += (*this)((data(__n)-pos)*_inv_bw)*weights(__n);

      return __result*one_over_sqrt2pi*_inv_bw;
    }

    // =====================================================================
    template<typename Value>
    auto GaussKernel<Value,1>::eval_cutoff(value_t bandwidth, value_t eps)
      const -> value_t
    {
      return std::sqrt(-2*std::log(eps*sqrt2pi*bandwidth))*bandwidth;
    }

    // =====================================================================
    template<typename Value>
    void GaussKernel<Value,1>::reset(value_t bandwidth, value_t eps)
    {
      _inv_bw = 1.0/bandwidth;
      _cutoff = eval_cutoff(bandwidth, eps);
    }

    // =====================================================================
    template<typename Value>
    auto GaussKernel<Value,1>::operator()(value_t pos) const -> value_t
    {
      return std::exp(-0.5 * pos * pos);
    }

  } //!kern
} //!stogeo
