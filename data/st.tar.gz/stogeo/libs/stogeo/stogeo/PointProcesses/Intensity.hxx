// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Intensity.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug  3 17:14:50 2016 Zhijin Li
// Last update Wed Apr 19 17:37:05 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {

    // =====================================================================
    template<typename Func, typename Scalar>
    Intensity<Func,Scalar,false>::Intensity(Func inten, Scalar max_value):
      _intensity(inten), _max_value(max_value) {};

    // =====================================================================
    template<typename Func, typename Scalar>
    Intensity<Func,Scalar,false>::Intensity(Func inten): _intensity(inten) {};

    // =====================================================================
    template<typename Func, typename Scalar>
    Scalar Intensity<Func,Scalar,false>::get_max() const
    {
      assert(static_cast<bool>(_max_value) && "max value not initialized");
      return *_max_value;
    };

    // =====================================================================
    template<typename Func, typename Scalar>
    template<typename Shape, typename>
    auto Intensity<Func,Scalar,false>::eval_max(Shape &&shape,
                                                Scalar spacing,
                                                Scalar mag)
      const -> const exact_t&
    {
      constexpr int __dim = stg_dim_v<decay_t<Shape> >();
      using point_t = Eigen::Matrix<Scalar,__dim,1>;

      point_t __spacing; __spacing.setConstant(spacing);
      auto __grid = utils::make_cmn_domain
        (utils::comp_bound(std::forward<Shape>(shape)), __spacing);

      Scalar __max = 0; cmn_fwditr_t<__dim> __it(__grid);
      cmn_for_all(__it)
      {
        auto __tmp = _intensity(utils::cmn_itr_pos<Scalar>(__it));
        __max = ((__tmp > __max) ? __tmp : __max);
      }
      _max_value = __max*mag;

      return *this;
    }

  } //!pps
} //!stogeo
