// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MarkedPP.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Jul 31 22:43:41 2016 Zhijin Li
// Last update Thu Oct 12 22:29:44 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {

    // =====================================================================
    template<typename Proc, typename Mark>
    template<typename Matrix, typename Marks, typename ...Args, typename>
    void MarkedPP<Proc,Mark>::draw_impl(Matrix &mat, Marks &marks,
                                        Args &&...args) const
    {
      _pproc.draw(mat, std::forward<Args>(args)...);
      marks.resize(mark_dim, mat.cols());
      for(int __n = 0; __n < mat.cols(); ++__n)
        marks.col(__n) = _pmark.draw(no_center);
    }

    // =====================================================================
    template<typename Proc, typename Mark>
    template<typename ...Args>
    void MarkedPP<Proc,Mark>::draw_impl(realz_t &realz, Args &&...args) const
    {
      matrx_t __pts;
      _pproc.draw(__pts, std::forward<Args>(args)...);
      realz.marks().reserve(__pts.cols());
      for(int __n = 0; __n < __pts.cols(); ++__n)
        realz.append(_pmark.draw(__pts.col(__n)));
      // Note: this is benchmarked -> faster than mover_to().roll().
    }

    // =====================================================================
    template<typename Proc, typename Mark>
    auto MarkedPP<Proc,Mark>::reset_state_impl() -> exact_t&
    {
      _pproc.reset_state();
      _pmark.reset_state();
      return *this;
    }

  } //!pps
} //!stogeo
