// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// MaternClusterPP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri Nov  6 09:26:49 2015 Zhijin Li
// Last update Tue Sep 26 14:41:26 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_MATERNCLUSTERPP_HH
# define STOGEO_MATERNCLUSTERPP_HH

# include "ppsbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace pps
  {
    template<typename T, int Dim, template<typename,int> class,
             typename Parent=T, typename Child=T> class MaternClusterPP;
  }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the
    /// `stogeo::pps::MaternClusterPP<T,Dim,Shape,Parent,Child>`
    /// class: the **Matern clustered point process**.
    ///
    template<typename T, int Dim,
             template<typename,int> class Shape, typename Parent, typename Child>
    struct specs<pps::MaternClusterPP<T,Dim,Shape,Parent,Child> >
    {
      static constexpr int dim          =                        Dim;
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static constexpr bool has_window  = !is_arithmetic_v<Parent>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Parent>                         inten_t;
      typedef pps::Intensity<Child>                          child_t;
      typedef Shape<T,Dim>                                   shape_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef MarkedPointPattern<Shape<T,Dim> >              clust_t;
      typedef typename specs<realz_t>::point_t               point_t;
      typedef typename specs<realz_t>::vectr_t               vectr_t;
      typedef typename specs<realz_t>::matrx_t               matrx_t;
      typedef typename specs<realz_t>::slice_t               slice_t;
      typedef typename specs<realz_t>::dymmt_t               dymmt_t;
      typedef std::pair<realz_t,clust_t>                     extra_t;
    };
  }

  namespace pps
  {
    /// @ingroup group_pproc
    ///
    /// @brief Class of Matern cluster process with generic geometric shapes.
    ///
    /// A Matern clustered point process is constructed from two steps:
    /// 1. Construction of **parent points**. They issue from the
    ///    realization of a Poisson point process with intensity `Parent`,
    ///    called the **parent intensity**.
    /// 2. Construction of **child points**. They issue from the
    ///    realization of a Poisson point process with intensity `Child`,
    ///    called the **child intensity**.
    /// 3. Create a **cluster of geometric shapes**, centered at the
    ///    **parent points**. Each shape drawn from a shape object that
    ///    could be a random or deterministic `stogeo::shapes` object.
    /// 4. The **final points** are obtained by retaining only child points
    ///    falling inside the cluster of shapes.
    ///
    /// @param T: scalar type used for primary and child points.
    /// @param Dim: dimension of the point processes.
    /// @param Shape: type of the shape shape, a `stogeo::shapes` type.
    /// @param Parent: type of the parent Poisson point process intensity.
    /// @param Child: type of the child Poisson point process intensity.
    ///
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    class MaternClusterPP
      : public abstract::ppsbase<MaternClusterPP<T,Dim,Shape,Parent,Child> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t = MaternClusterPP<T,Dim,Shape,Parent,Child>;
      using specs_t =                   traits::specs<exact_t>;
      using scalr_t =                typename specs_t::scalr_t;
      using inten_t =                typename specs_t::inten_t;
      using child_t =                typename specs_t::child_t;
      using shape_t =                typename specs_t::shape_t;
      using point_t =                typename specs_t::point_t;
      using vectr_t =                typename specs_t::vectr_t;
      using matrx_t =                typename specs_t::matrx_t;
      using slice_t =                typename specs_t::slice_t;
      using realz_t =                typename specs_t::realz_t;
      using clust_t =                typename specs_t::clust_t;
      using extra_t =                typename specs_t::extra_t;

      using parnt_t =               abstract::ppsbase<exact_t>;
      friend                                           parnt_t;

      using                                      parnt_t::draw;
      using                                     parnt_t::print;
      using                               parnt_t::reset_state;

      static constexpr int dim =                           Dim;

      /// @brief Ctor.
      MaternClusterPP() = default;

      /// @brief Ctor. Taking parent intensity (scalar or functional)
      /// and child intensity (scalar or functional) as input, without
      /// the observation window.
      ///
      /// When the parent intensity is functional, it's max_value is
      /// assumed ready, otherwise the behavor is not garanteed.
      /// @param inten: the parent intensity value or function.
      /// @param child: the child intensity value or function.
      /// @param shape: the shape defining the shape of clusters. Can
      /// be stogeo random or deterministic shape.
      ///
      template<typename ParentType, typename ChildType, typename ShapeType,
               typename = enable_if_all_t<is_intensity_v<ParentType>(),
                                          is_intensity_v<ChildType>(),
                                          is_stg_shape_v<ShapeType>()> >
      MaternClusterPP(ParentType &&paren, ChildType &&child,
                      ShapeType &&shape);

      /// @brief Ctor. Taking functional parent intensity and child
      /// intensity (scalar or functional) as input, with obs window.
      ///
      /// @param window: the obs window, a stogeo deterministic shape.
      /// @param inten: the parent intensity function.
      /// @param child: the child intensity value or function.
      /// @param shape: the shape defining the shape of clusters. Can
      /// be stogeo random or deterministic shape.
      ///
      template<typename Window, typename ParentType, typename ChildType,
               typename ShapeType,
               typename = enable_if_all_t<is_intensity_v<ParentType>(),
                                          is_intensity_v<ChildType>(),
                                          is_stg_shape_v<ShapeType>()> >
      MaternClusterPP(Window &&window, ParentType &&paren,
                      ChildType &&child, ShapeType &&shape);

    private:

      /// @brief Draw a realization of the clusters.
      ///
      /// It uses the parent process to sample cluster centers and uses
      /// the internal shape to sample cluster shapes. An extra shape as
      /// obs window can be passed depending on if curr instance contains
      /// one.
      ///
      /// @param shape: a stogeo::shape as obs window or nothing.
      /// @return Sampled clusters, a stogeo::MarkedPointPattern.
      ///
      template<typename ...Args>
      clust_t draw_clusters(Args &&...shape) const;

      /// @brief Run a realization: this impl will be called by draw in
      /// ppsbase.
      ///
      /// @param mat: an Eigen matrix-like structure to draw realization
      /// into.
      /// @param args: a shape as obs window or nothing, depending on if
      /// curr instance need to hold an obs window.
      ///
      template<typename Matrix, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &mat, Args &&...args) const;

      /// @brief Draw a realization of child process.
      ///
      /// This version dispatches to scalar child intensity. Means that
      /// the child process contains no window and never needs max_val
      /// evaluation.
      ///
      /// @param tag: the dispatcher tag.
      /// @param mat: the input matrix where samples will be drawn into.
      /// @param shapes: the input MarkedPointPattern containing cluster
      /// shapes.
      ///
      template<typename Matrix, typename Shapes>
      void draw_child_dispatch(scalr_inten_tag_t tag, Matrix &mat,
                               const Shapes &shapes) const;

      /// @brief Draw a realization of child process.
      ///
      /// This version dispatches to functional child intensity. Means
      /// that the child process may contain initialized window and needs
      /// to check if an eval on max_val is needed to be able to use the
      /// child intensity.
      ///
      /// @param tag: the dispatcher tag.
      /// @param mat: the input matrix where samples will be drawn into.
      /// @param shapes: the input MarkedPointPattern containing cluster
      /// shapes.
      ///
      template<typename Matrix, typename Shapes>
      void draw_child_dispatch(funct_inten_tag_t tag, Matrix &mat,
                               const Shapes &shapes) const;

      /// @brief Draw samples into a matrix using child process. Cluster
      /// shape will be determined from the shapes.
      ///
      /// With each sampling a shape will be copy as the internal obs
      /// window of child process. This will trigger an evaluation of
      /// max_val of the intensity function in region bounded by each
      /// shape.
      ///
      /// @param mat: an input matrix where samples will be drawn into.
      /// @param shapes: the curr shapes containing all cluster shapes.
      /// a stogeo::MarkedPointPattern.
      ///
      template<typename Matrix, typename Shapes>
      void draw_child_eval(Matrix &mat, const Shapes &shapes) const;

      /// @brief Draw samples into a matrix using child process Cluster
      /// shape will be determined from an input shapes.
      ///
      /// With each sampling a shape will be used as the input obs wind
      /// arg for draw. This version makes sense for scalar child inten
      /// or child inten function with specified max_value.
      ///
      /// @param mat: an input matrix where samples will be drawn into.
      /// @param shapes: the curr shapes containing all cluster shapes.
      /// a stogeo::MarkedPointPattern.
      ///
      template<typename Matrix, typename Shapes>
      void draw_child(Matrix &mat, const Shapes &shapes) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      CSRSampler<scalr_t,dim,Parent> _paren_process; //:< The parent process.
      CSRSampler<scalr_t,dim,Child>  _child_process; //:< The child process.
      shape_t                        _cluster_shape; //:< The cluster shape.
    };

  }
}


# include "MaternClusterPP.hxx"
#endif
