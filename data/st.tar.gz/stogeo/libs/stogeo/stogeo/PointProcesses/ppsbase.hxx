// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// ppsbase.hxx for StoGeo
//
// Made by Zhijin LI
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 05 21:58:07 2015 Zhijin LI
// Last update Mon Sep 11 18:55:43 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {
    namespace abstract
    {

      // =====================================================================
      template<typename EXACT>
      auto ppsbase<EXACT>::draw() const -> realz_t
      {
        realz_t __realz(exact().obs_window());
        dispatch_draw(__realz, pp_tag_dispatch_t<EXACT>{});
        return __realz;
      }

      // =====================================================================
      template<typename EXACT>
      auto ppsbase<EXACT>::draw(extra_tag_t extra_tag) const -> extra_t
      {
        extra_t __extra(exact().obs_window());
        exact().draw_impl(__extra, extra_tag);
        return __extra;
      }

      // =====================================================================
      template<typename EXACT> template<typename Matrix, typename>
      void ppsbase<EXACT>::draw(Matrix &mat) const
      {
        exact().draw_impl(mat);
      }

      // =====================================================================
      template<typename EXACT> template<typename Shape, typename>
      auto ppsbase<EXACT>::draw(Shape &&window) const -> realz_t
      {
        realz_t __realz(window);
        dispatch_draw(__realz, pp_tag_dispatch_t<EXACT>{},
                      std::forward<Shape>(window));
        return __realz;
      }

      // =====================================================================
      template<typename EXACT> template<typename Shape, typename>
      auto ppsbase<EXACT>::draw(extra_tag_t extra_tag, Shape &&window)
        const -> extra_t
      {
        extra_t __extra(window);
        exact().draw_impl(__extra, extra_tag, std::forward<Shape>(window));
        return __extra;
      }

      // =====================================================================
      template<typename EXACT>
      template<typename Matrix, typename Shape, typename>
      void ppsbase<EXACT>::draw(Matrix &mat, Shape &&window) const
      {
        exact().draw_impl(mat, std::forward<Shape>(window));
      }

      // =====================================================================
      template<typename EXACT>
      template<typename Matrix, typename Marks, typename ...Args, typename>
      void ppsbase<EXACT>::draw(Matrix &mat, Marks &marks, Args &&...args) const
      {
        exact().draw_impl(mat, marks, std::forward<Args>(args)...);
      }

      // =====================================================================
      template<typename EXACT> template<typename ...Args>
      void ppsbase<EXACT>::dispatch_draw(realz_t &realz, simple_pp_tag_t,
                                         Args &&...args) const
      {
        exact().draw_impl(realz.pts(), std::forward<Args>(args)...);
      }

      // =====================================================================
      template<typename EXACT> template<typename ...Args>
      void ppsbase<EXACT>::dispatch_draw(realz_t &realz, marked_pp_tag_t,
                                         Args &&...args) const
      {
        exact().draw_impl(realz, std::forward<Args>(args)...);
      }

      // =====================================================================
      template<typename EXACT>
      template<typename ...Args, typename>
      auto csrbase<EXACT>::draw(Args &&...args) const -> realz_t
      {
        static_assert(sizeof...(Args) <= 1, "ERROR: MAX 1 SHAPE EXPECTED.");
        realz_t __result(args...);
        draw(__result.pts(), std::forward<Args>(args)...);
        return __result;
      }

      // =====================================================================
      template<typename EXACT>
      template<typename Matrix, typename ...Args, typename>
      void csrbase<EXACT>::draw(Matrix &mat, Args &&...args) const
      {
        exact().draw_impl(mat, std::forward<Args>(args)...);
      }

      // =====================================================================
      template<typename EXACT>
      template<typename Matrix, typename Shape, typename>
      void csrbase<EXACT>::
      csr_draw(Matrix &mat, Shape &&window, int n_samples) const
      {
        mat.resize(dim, n_samples);
        bind_to_bound(utils::comp_bound(window));

        for(int __d = 0; __d < dim; ++__d) _rnd_smplr[__d].draw(mat.row(__d));
        utils::logical_slice(mat, utils::inside_test(window, mat));
      }

      // =====================================================================
      template<typename EXACT> template<typename Bound>
      void csrbase<EXACT>::bind_to_bound(Bound &&bound) const
      {
        for(auto __i = 0; __i < dim; ++__i)
          _rnd_smplr[__i].reset_param(bound(__i,0), bound(__i,1));
      }

    } //!abstract


    // =====================================================================
    template<typename T, int Dim> template<typename IntenType>
    CSRSampler<T,Dim,T,true>::CSRSampler(IntenType &&intensity):
      _intensity( std::forward<IntenType>(intensity) )
    {
      static_assert(is_scalr_inten_v<IntenType>() ||
                    is_arithmetic_v<IntenType>(),
                    "ERROR: SCALAR INTENSITY IS EXPECTED.");
      assert(_intensity.get() > 0 && "intensity cannot be negative");
    };

    // =====================================================================
    template<typename T, int Dim> template<typename Bound>
    long int CSRSampler<T,Dim,T,true>::n_samples(Bound &&bound) const
    {
      _nsampl_rv = rnd::Poisson<long int>
        ( (bound.col(1)-bound.col(0)).prod()* _intensity.get() );
      return _nsampl_rv.draw();
    }

    // =====================================================================
    template<typename T, int Dim>
    template<typename Matrix, typename Shape, typename>
    void CSRSampler<T,Dim,T,true>::
    draw_impl(Matrix &mat, Shape &&window) const
    {
      auto __n_samples = n_samples(utils::comp_bound(window));
      csr_draw(mat, std::forward<Shape>(window), __n_samples);
    }

    // =====================================================================
    template<typename T, int Dim>
    auto CSRSampler<T,Dim,T,true>::reset_state_impl() -> exact_t&
    {
      for(auto &&__rv : _rnd_smplr)
        __rv.reset_state();
      _nsampl_rv.reset_state();
      return *this;
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename IntenType>
    CSRSampler<T,Dim,Inten,false>::CSRSampler(IntenType &&func):
      _intensity( std::forward<IntenType>(func) )
    {
      static_assert(is_funct_inten_v<IntenType>(),
                    "ERROR: FUNCTIONAL INTENSITY IS EXPECTED.");
      assert(_intensity.get_max() >= 0.0 && "max inten cannot be negative.");
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename IntenType, typename Shape, typename>
    CSRSampler<T,Dim,Inten,false>::
    CSRSampler(Shape && window, IntenType &&inten_func):
      _obs_windw( std::forward<Shape>(window) ),
      _intensity( std::forward<IntenType>(inten_func) )
    {
      static_assert(is_funct_inten_v<IntenType>(),
                    "ERROR: FUNCTIONAL INTENSITY IS EXPECTED.");

      _intensity.eval_max(*_obs_windw);
      assert(_intensity.get_max() >= 0.0 && "max inten cannot be negative.");

      reset_nsampl_rv(utils::comp_bound(*_obs_windw));
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto CSRSampler<T,Dim,Inten,false>::obs_window() -> obswd_t&
    {
      assert( static_cast<bool>(_obs_windw) &&
              "error: window is not initialized." );
      return *_obs_windw;
    };

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto CSRSampler<T,Dim,Inten,false>::obs_window() const -> const obswd_t&
    {
      assert( static_cast<bool>(_obs_windw) &&
              "error: window is not initialized.");
      return *_obs_windw;
    };

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Shape, typename>
    void CSRSampler<T,Dim,Inten,false>::
    set_window(Shape &&window, bool eval_max, scalr_t spacing, scalr_t mag)
      const
    {
      _obs_windw.emplace(std::forward<Shape>(window));
      if( eval_max ) _intensity.eval_max(spacing,mag);
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten> template<typename Bound>
    int CSRSampler<T,Dim,Inten,false>::max_samples(Bound &&bound) const
    {
      reset_nsampl_rv(std::forward<Bound>(bound));
      return _nsampl_rv.draw();
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten> template<typename Bound>
    void CSRSampler<T,Dim,Inten,false>::reset_nsampl_rv(Bound &&bound) const
    {
      _nsampl_rv.reset_param( (bound.col(1)-bound.col(0)).prod()*
                              _intensity.get_max() );
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename>
    void CSRSampler<T,Dim,Inten,false>::draw_impl(Matrix &mat) const
    {
      assert( static_cast<bool>(_obs_windw) &&
              "error: window not initialized");

      csr_draw(mat, *_obs_windw, _nsampl_rv.draw());
      __thinning(mat);
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename Shape, typename>
    void CSRSampler<T,Dim,Inten,false>::draw_impl(Matrix &mat,
                                                  Shape &&window) const
    {
      csr_draw(mat, window, max_samples(utils::comp_bound(window)));
      __thinning(mat);
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename>
    void CSRSampler<T,Dim,Inten,false>::__thinning(Matrix &mat) const
    {
      rnd::RUniform<scalr_t> __urv;
      slice_t __lv = slice_t::Zero(mat.cols());
      for(auto __n = 0; __n < mat.cols(); ++__n)
        if( __urv.draw() <= _intensity(mat.col(__n))/_intensity.get_max() )
          __lv(__n) = true;

      utils::logical_slice(mat, __lv);
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto CSRSampler<T,Dim,Inten,false>::reset_state_impl() -> exact_t&
    {
      for(auto &&__rv : _rnd_smplr)
        __rv.reset_state();
      _nsampl_rv.reset_state();
      return *this;
    }

  } //!pps
} //!stogeo
