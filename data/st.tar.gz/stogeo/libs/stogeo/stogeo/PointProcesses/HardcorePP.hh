// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// HardcorePP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 17 17:28:07 2015 Zhijin Li
// Last update Tue Sep 26 14:41:26 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_HARDCOREPP_HH
# define STOGEO_HARDCOREPP_HH

# include "MaternHardPP.hh"


namespace stogeo
{
  // Fwd decl.
  namespace pps
  {
    template<typename T, int Dim, typename Inten=T> class HardcorePP;
  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits properties for the `stogeo::pps::HardcorePP`
    /// class.
    ///
    template<typename T, int Dim, typename Inten>
    struct specs<pps::HardcorePP<T,Dim,Inten> >
    {
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static constexpr int dim          =                        Dim;
      static constexpr bool has_window  =  !is_arithmetic_v<Inten>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten>                          inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef SimplePointPattern<T,Dim>                      extra_t;
    };
  }

  /// @ingroup group_pproc
  namespace pps
  {

    /// @ingroup group_pproc
    ///
    /// @brief Class of hardcore point process.
    ///
    /// This is a naive implementation, where points are obtained from thinning
    /// of a Poisson pp realization.
    /// 1. **All points are looped in random order**.
    /// 2. Then **each one is used to suppress points falling inside a
    ///    spheric neighborhood**.
    /// 3. The next loop **will not be affected by already-deleted
    ///    points**.
    ///
    /// @warning This process will usually produce a point pattern **more
    /// dense than the Matern hardcore processes of type II & type III**,
    /// and **it runs faster** tha them. However, I don't have any
    /// theoretical backup for its statistical properties.
    ///
    /// @param T: the scalar type used for data points.
    /// @param Dim: the dimension.
    /// @param Inten: the intensity type.
    ///  1. Defaults to be arithmetic, i.e. uniform intensity value. Can
    ///     use **convenient aliases** from the `stogeo::Intensity` class:
    ///     such as `stogeo::IntenVal_f`, `stogeo::IntenVal_d`.
    ///  2. Can also be functional. In this case, **wrap a functor or
    ///     lambda into functional version of `stogeo::Intensity` object.
    ///     Can use **convenient aliases** such as `stogeo::IntenFun_f`
    ///     or `stogeo::IntenVal_d`.
    ///
    template<typename T, int Dim, typename Inten> class HardcorePP
      : public abstract::hardbase<HardcorePP<T,Dim,Inten> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            =         HardcorePP<T,Dim,Inten>;
      using specs_t            =          traits::specs<exact_t>;
      using scalr_t            =       typename specs_t::scalr_t;
      using inten_t            =       typename specs_t::inten_t;
      using point_t            =       typename specs_t::point_t;
      using vectr_t            =       typename specs_t::vectr_t;
      using matrx_t            =       typename specs_t::matrx_t;
      using slice_t            =       typename specs_t::slice_t;
      using field_t            =       typename specs_t::dymmt_t;
      using realz_t            =       typename specs_t::realz_t;
      using extra_t            =       typename specs_t::extra_t;

      using parnt_t            =      abstract::ppsbase<exact_t>;
      using super_t            =     abstract::hardbase<exact_t>;
      friend                                             parnt_t;

      using parnt_t::                                       draw;
      using parnt_t::                                      print;
      using parnt_t::                                reset_state;
      using super_t::                                    hc_dist;

      static constexpr int dim =                             Dim;

      /// @brief Forwarding ctor.
      ///
      /// Forwards all arguments to matching ctor from `super_t`, i.e.
      /// `stogeo::pps::abstract::hardbase`.
      ///
      /// @param args: variadic arguments matching those of the ctors of
      /// `stogeo::pps::abstract::hardbase` class.
      ///
      /// @sa `stogeo::pps::abstract::hardbase`
      ///
      template<typename ...Args,
               enable_if_all_t<!is_base_of_v<exact_t,Args>()...>* = nullptr>
      HardcorePP(Args &&...args):
        super_t( std::forward<Args>(args)... ) {};

    private:

      /// @brief Run a realization
      template<typename Matrix, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &, Args &&...args) const;

      using super_t::reset_state_impl;

      using super_t::_csr_smplr;
      using super_t::_hdcr_sphr;
    };

  }
}


# include "HardcorePP.hxx"
#endif
