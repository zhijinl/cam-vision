// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// Intensity.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Aug  1 22:12:49 2016 Zhijin Li
// Last update Wed Feb 15 11:35:28 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_INTENSITY_HH
# define STOGEO_INTENSITY_HH

# include "stogeo/core.hh"
# include "../Utilities/mipp_helpers.hh"
# include "../Utilities/computations.hh"


namespace stogeo
{
  namespace pps
  {
    template<typename IntenType, typename Scalar=IntenType,
             bool cond=is_arithmetic_v<IntenType>()>
    struct Intensity {};
  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits for the
    /// `stogeo::pps::Intensity<Scalar,Scalar,true>` class:
    /// the scalar intensity.
    ///
    template<typename Scalar>
    struct specs<pps::Intensity<Scalar,Scalar,true> >
    {
      static const stg_ids stg_id = stg_ids::STOGEO_SCLR_INTEN;
    };

    /// @ingroup group_traits
    ///
    /// @brief Type traits for the
    /// `stogeo::pps::Intensity<Scalar,Scalar,true>` class:
    /// the functional intensity.
    ///
    template<typename IntenType, typename Scalar>
    struct specs<pps::Intensity<IntenType,Scalar,false> >
    {
      static const stg_ids stg_id = stg_ids::STOGEO_FUNC_INTEN;
    };

  }

  /// @ingroup group_pproc
  namespace pps
  {
    /// @ingroup group_pproc
    ///
    /// @brief Scalar / Uniform intensity value wrapper.
    ///
    /// @param Scalar: Scalar value used for computations.
    ///
    template<typename Scalar> struct Intensity<Scalar,Scalar,true>
    {

    public:

      /// @brief Default ctor.
      Intensity(): _inten{0} {};

      /// @brief Ctor.
      ///
      /// @param inten: the intensity value.
      ///
      Intensity(Scalar inten): _inten(inten) {};

      /// @brief Get the value of the intensity.
      ///
      /// @return The curr intensity value.
      ///
      Scalar get() const { return _inten; }

      /// @brief Check if user need to evaluate the intensity max
      ///
      /// @note This is purely for API compatibility: always return false
      /// for this uniform intensity case.
      ///
      /// @return Always false.
      ///
      bool need_eval() const { return false; }

    private:

      Scalar _inten; //:< Cached intensity value.
    };


    /// @ingroup group_pproc
    ///
    /// @brief Functional intensity.
    ///
    /// @param Func: the functional intensity type. Could be a type of a lambda
    /// or  type of a specific functor.
    /// @param Scalar: Scalar value used for computations.
    ///
    template<typename Func, typename Scalar> struct Intensity<Func,Scalar,false>
    {

    public:

      using exact_t = Intensity<Func,Scalar,false>;

      /// Ctor.
      Intensity() = default;

      /// @brief Ctor. Taking the intensity function without the max value.
      ///
      /// @warning In this case:
      /// * It is **mandatory to pass an obs window** to the point process
      ///   using this intensity function. Since the inten maximum can only
      ///   be grid-evaluated inside a finite size bound.
      /// * The intensity maximum is **not evaluated at construction**. It
      ///   is because there is no way for the constructor to have info on
      ///   the geometric bound for the grid-evaluation of the maximum. So
      ///   after construction, **the `get_max()` interface is not usesable**
      ///   and `need_eval()` will return `true`.
      /// * An interface `eval_max` is provided for manual evaluation of
      ///   the intensity max.
      ///
      /// @note An intensity func takes a const ref to point_t and returns
      /// scalr_t. Since the callee of inten func could be Eigen column
      /// expression, or just for genericity reason, it's recommanded to
      /// write generic functor / lambda for better perf (avoid create of
      /// tmp point_t at call site).
      ///
      /// @param inten: the input intensity function.
      ///
      explicit Intensity(Func inten);

      /// @brief Ctor. Taking the intensity function & it's max value hint.
      ///
      /// An intensity func takes a const ref to **a point_t expression**,
      /// and returns a scalr_t.
      ///
      /// @note In this case an obs window is **not needed** for the point
      /// process to use this intensity function.
      ///
      /// @note Since the callee of inten func could be Eigen column
      /// expression, or just for genericity reason, it's recommanded to
      /// write generic functor / lambda for better perf (avoid create of
      /// tmp point_t at call site).
      ///
      /// @warning The input `max_value` must be the **CORRECT max_val of
      /// the intensity function**, at least in obs window. Otherwise the
      /// simulation will produce undefined result.
      ///
      /// @param inten: the input intensity function.
      /// @param max_value: the max_value.
      ///
      Intensity(Func inten, Scalar max_value);

      /// @brief Fwding operator () to input function.
      ///
      /// @param args: arguments for evaluation of the intensity value
      /// at a specific position.
      /// @return The evaluated intensity value.
      ///
      template<typename ...Args> Scalar operator()(Args &&...args) const
      { return _intensity(std::forward<Args>(args)...); }

      /// @brief Get a copy of the currently held intensity function.
      ///
      /// @return A copy of the curr intensity func.
      ///
      Func get() const { return _intensity; }

      /// @brief Get a copy of the currently held intensity maximum.
      ///
      /// @return The curr intensity max value.
      ///
      Scalar get_max() const;

      /// @brief Check if user need to evaluate the intensity max
      /// using grid search.
      ///
      /// @note True also means an obs window is needed to use curr
      /// inten function.
      ///
      /// @return True if curr inten max needs to be evaluated.
      ///
      bool need_eval() const { return _max_value == false; }

      /// @brief (Re-)evaluate the max val of the intensity function
      /// in curr observation window.
      ///
      /// This does a grid search at each call site, could be expensive.
      ///
      /// @note Since an obs window is passed: the intensity func will
      /// then depend on it. The max is set to be:
      ///
      /// @f$ mag \times val @f$
      ///
      /// just to ensure coverage of max. Here @f$ val @f$ is the value
      /// evaluated using grid search. It is upto the user to make sure
      /// that a window large enough to cover the wanted max value is
      /// passed for eval.
      ///
      /// @param window: the window bounding the grid search, must be
      /// a stogeo::shape.
      /// @param spacing: specifies the grid size for grid search eval
      /// of the intensity max. Default to 0.1.
      /// @param mag: a maginfication param, applied to the max value
      /// computed by grid search. Default to 1.2.
      ///
      template<typename Shape,
               typename = enable_if_t<is_stg_shape_v<Shape>()> >
      const exact_t& eval_max(Shape &&window,
                              Scalar spacing=0.1,
                              Scalar mag=1.2) const;

    private:

      Func                     _intensity; //:< Cached intensity function.
      mutable optional<Scalar> _max_value; //:< Cached maximum value.
    };


    // Helper typedefs.
    using IntenVal_f = Intensity<float,float,true>;
    using IntenVal_d = Intensity<double,double,true>;

    template<typename Func>
    using IntenFun_f = Intensity<Func,float,false>;
    template<typename Func>
    using IntenFun_d = Intensity<Func,double,false>;

  }
}


# include "Intensity.hxx"
#endif
