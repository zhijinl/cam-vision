// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// PoissonPP.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 06 10:22:07 2015 Zhijin Li
// Last update Mon Sep 11 18:54:54 2017 Zhijin Li
// ---------------------------------------------------------------------------

namespace stogeo
{
  namespace pps
  {

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename IntenType, typename>
    PoissonPP<T,Dim,Inten>::PoissonPP(IntenType &&inten):
      _csr_sampler( std::forward<IntenType>(inten) ) {};

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename IntenType, typename Shape, typename>
    PoissonPP<T,Dim,Inten>::PoissonPP(Shape && window, IntenType &&inten_func):
      _csr_sampler( std::forward<Shape>(window),
                    std::forward<IntenType>(inten_func) ) {};

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto PoissonPP<T,Dim,Inten>::obs_window() -> obswd_t&
    {
      static_assert(specs_t::has_window,
                    "ERROR: THIS INSTANCE DOES NOT STORE WINDOW.");
      return _csr_sampler.obs_window();
    };

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto PoissonPP<T,Dim,Inten>::obs_window() const -> const obswd_t&
    {
      static_assert(specs_t::has_window,
                    "ERROR: THIS INSTANCE DOES NOT STORE WINDOW.");
      return _csr_sampler.obs_window();
    };

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename ...Args, typename>
    void PoissonPP<T,Dim,Inten>::draw_impl(Matrix &mat, Args &&...args) const
    {
      _csr_sampler.draw(mat, std::forward<Args>(args)...);
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    auto PoissonPP<T,Dim,Inten>::reset_state_impl() -> exact_t&
    {
      _csr_sampler.reset_state();
      return *this;
    }

  } //!pps
} //!pps
