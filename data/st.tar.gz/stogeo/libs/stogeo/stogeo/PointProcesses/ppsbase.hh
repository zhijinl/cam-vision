// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// ppsbase.hh for MO3
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jun 17 17:01:07 2015 Zhijin Li
// Last update Thu Oct 12 16:30:04 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_PPSBASE_HH
# define STOGEO_PPSBASE_HH

# include "common/Domain1D.hh"
# include "common/Domain2D.hh"
# include "common/Domain3D.hh"
# include "common/FwdIterator.hh"
# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "stogeo/geometry.hh"
# include "stogeo/point_patterns.hh"
# include "Intensity.hh"


namespace stogeo
{

  /// @defgroup group_pproc Spatial Point Processes
  ///
  /// @brief Classes for spatial simple / marked point processes,
  /// with homogeneous or inhomogeneous intensity.
  ///
  /// This module implements elementary point processes, such as:
  /// * **Simple point processes**:
  ///   * **Binomial point process**
  ///   * **Poisson point process**
  ///   * various **hardcore point processes (Matern Type I, II & III,
  ///     naive harcore etc.)**,
  ///   * and **Matern cluster process with generic cluster shape**.
  /// * **Marked point process**:
  ///   * with **arithmetic marks**
  ///   * or **geometric marks**.
  ///
  /// A generic version of intensity is also implemented. The
  /// intensity can be **scalar or functional**, enabling both
  /// **homogeneous and inhomogeneous** processes.
  ///

  namespace pps
  {
    /// @ingroup group_pproc
    ///
    /// @brief Base case for CSR random sampler.
    ///
    template<typename T, int Dim, typename Inten,
             bool cond=is_arithmetic_v<Inten>()> class CSRSampler {};
  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits for the `stogeo::pps::CSRSampler<T,Dim,T>`
    /// class: the **complete spatial randomness sampler with scalar
    /// intensity**.
    ///
    template<typename T, int Dim>
    struct specs<pps::CSRSampler<T,Dim,T> >
    {
      static constexpr int dim         =                         Dim;
      static const stg_ids stg_id      =       stg_ids::STOGEO_PPROC;
      static constexpr bool has_window =                       false;
      typedef T                                              scalr_t;
      typedef pps::Intensity<T>                              inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef std::array<rnd::RUniform<scalr_t>,dim>         smplr_t;
      typedef SimplePointPattern<scalr_t,dim>                realz_t;
    };

    /// @ingroup group_traits
    ///
    /// @brief Type traits for the `stogeo::pps::CSRSampler<T,Dim,T>`
    /// class: the **complete spatial randomness sampler with functional
    /// intensity**.
    ///
    template<typename T, int Dim, typename Inten>
    struct specs<pps::CSRSampler<T,Dim,Inten,false> >
    {
      static constexpr int dim         =                         Dim;
      static const stg_ids stg_id      =       stg_ids::STOGEO_PPROC;
      static constexpr bool has_window =                        true;
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten,T>                        inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef std::array<rnd::RUniform<scalr_t>,dim>         smplr_t;
      typedef SimplePointPattern<scalr_t,dim>                realz_t;
    };

  }

  /// @ingroup group_pproc
  namespace pps
  {
    namespace abstract
    {
      /// @ingroup group_pproc
      ///
      /// @brief The base class for all point processes (simple & marked).
      ///
      /// @param EXACT: type of the derived class inheriting from it.
      ///
      template<typename EXACT> class ppsbase: public internal__::root__<EXACT>
      {
      public:
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        using specs_t = stogeo::traits::specs<EXACT>;
        using scalr_t =    typename specs_t::scalr_t;
        using inten_t =    typename specs_t::inten_t;
        using point_t =    typename specs_t::point_t;
        using vectr_t =    typename specs_t::vectr_t;
        using matrx_t =    typename specs_t::matrx_t;
        using realz_t =    typename specs_t::realz_t;
        using extra_t =    typename specs_t::extra_t;
        using       internal__::root__<EXACT>::exact;

      protected:

        /// @brief Reset the internal state of the point process.
        ///
        /// Together with the `stogeo::utils::reset_shared_engine()`
        /// function, they can be used to reproduce the same simulation
        /// results.
        ///
        EXACT& reset_state() { return exact().reset_state_impl(); }

        /// @brief Draw a realization. For simple & marked pps.
        ///
        /// @return The realization. A `SimplePointPattern` for all
        /// simple point processes and a `MarkedPointPattern` for all
        /// marked point processes.
        ///
        realz_t draw() const;

        /// @brief Draw a realization of simple pp w/ extra content.
        ///
        /// This works for point processes containing additional info:
        /// for example, the Matern hardcore process of type II and III
        /// contain `birthday` marks associated with each survived pt,
        /// the final survived pts & the birthday marks can be drawn
        /// together into a `MarkedPointPattern`.
        ///
        /// @param extra_tag: `stogeo::extra_tag` indicating
        /// extra draw.
        /// @return The realization with extra draw info, normally a
        /// `MarkedPointPattern` object.
        ///
        extra_t draw(extra_tag_t extra_tag) const;

        /// @brief Draw a realization of simple pp into a matrix.
        ///
        /// @param mat: the input / output matrix where samples will
        /// be drawn into.
        ///
        template<typename Matrix,
                 typename = enable_if_t<is_eigen_v<Matrix>()> >
        void draw(Matrix &mat) const;

        /// @brief Draw a realization.
        ///
        /// With an input `stogeo::shapes` object specifying the obs
        /// window. This is especially for **point processes with
        /// functional intensity**, since they use sampling through
        /// thinning inside their draw method, and they necessitate
        /// the evaluation of intensity max, which in general need to
        /// be constrained inside an observation window.
        ///
        /// @param window: the observation window. A `stogeo::shapes`
        /// object.
        /// @return The realization. A `SimplePointPattern` for all
        /// simple point processes and a `MarkedPointPattern` for all
        /// marked point processes.
        ///
        template<typename Shape,
                 typename = enable_if_t<is_stg_shape_v<Shape>()> >
        realz_t draw(Shape &&window) const;

        /// @brief Draw a realization w/ extra content.
        ///
        /// This is the combination of extra draw and w/ obs window.
        ///
        /// @param extra_tag: `stogeo::extra_tag` indicating
        /// extra draw.
        /// @param window: the observation window. A `stogeo::shapes`
        /// object.
        /// @return The realization with extra draw info, normally a
        /// `MarkedPointPattern` object.
        ///
        template<typename Shape,
                 typename = enable_if_t<is_stg_shape_v<Shape>()> >
        extra_t draw(extra_tag_t extra_tag, Shape &&window) const;

        /// @brief Draw a realization into a matrix.
        ///
        /// An obs window is provided. This is for point processes with
        /// functional intensity.
        ///
        /// @param mat: the input / output matrix where samples will
        /// be drawn into.
        /// @param window: the observation window. A `stogeo::shapes`
        /// object.
        ///
        template<typename Matrix, typename Shape,
                 typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                            is_stg_shape_v<Shape>()> >
        void draw(Matrix &mat, Shape &&window) const;

        /// @brief Draw a realization of marked pp into matrices.
        ///
        /// Two Eigen matrices are provided to hold drawn points and
        /// marks separately.
        ///
        /// @note In case of geometric marked point processes, the
        /// **vector representation** of the marks will be drawn into
        /// the matrix used to hold marks.
        ///
        /// @param mat: the input / output matrix where **points**
        /// will be drawn into.
        /// @param marks: the input / output matrix where **marks**
        /// will be drawn into.
        /// @param args: an optional argument, to be a `stogeo::shapes`
        /// object or nothing. It is for when an observation window
        /// is needed (i.e. for pps w/ functional intensity).
        ///
        template<typename Matrix, typename Marks, typename ...Args,
                 typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                            is_eigen_v<Marks>()> >
        void draw(Matrix &mat, Marks &marks, Args &&...args) const;

        /// @brief Print out info of curr point process model.
        void print(const int &pr=18) const;

        /// @brief Default ctor.
        ppsbase() = default;

      private:

        /// @brief Dispatched version of draw for simple pp.
        ///
        /// @param realz: the input/output realization.
        /// @param tag: the simple pp tag.
        /// @param args: additional argument, either a window or nothing.
        ///
        template<typename ...Args>
        void dispatch_draw(realz_t &realz,
                           simple_pp_tag_t tag,
                           Args &&...args) const;

        /// @brief Dispatched version of draw for marked pp.
        ///
        /// @param realz: the input/output realization.
        /// @param tag: the marked pp tag.
        /// @param args: additional argument, either a window or nothing.
        ///
        template<typename ...Args>
        void dispatch_draw(realz_t &realz,
                           marked_pp_tag_t tag,
                           Args &&...args) const;

      };


      /// @ingroup group_pproc
      ///
      /// @brief The base class for complete spatial randomness samplers.
      ///
      /// @param EXACT: type of the derived class inheriting from it.
      ///
      template<typename EXACT> class csrbase: public internal__::root__<EXACT>
      {
      public:
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        using specs_t = stogeo::traits::specs<EXACT>;
        using scalr_t =    typename specs_t::scalr_t;
        using point_t =    typename specs_t::point_t;
        using vectr_t =    typename specs_t::vectr_t;
        using matrx_t =    typename specs_t::matrx_t;
        using smplr_t =    typename specs_t::smplr_t;
        using realz_t =    typename specs_t::realz_t;
        using internal__::root__<EXACT>::      exact;

        static constexpr int dim = specs_t::dim;

      protected:

        /// @brief Default ctor.
        csrbase() = default;

        /// @brief Reset the internal state of the point process.
        ///
        /// Together with the `stogeo::utils::reset_shared_engine()`
        /// function, they can be used to reproduce the same simulation
        /// results.
        ///
        EXACT& reset_state() { return exact().reset_state_impl(); }

        /// @brief Draw a realization: return a simple point pattern.
        ///
        /// @param args: an arguments specifying a shape for observation
        /// window or nothing.
        /// @return A `stogeo::SimplePointPattern`.
        ///
        template<typename ...Args,
                 typename = enable_if_all_t<is_stg_shape_v<Args>()...> >
        realz_t draw(Args &&...args) const;

        /// @brief Draw a realization into a matrix. This interface calls
        /// diff. impl versions of draw in diff. derived classes.
        ///
        /// @param mat: the input / output matrix where value will be
        /// drawn into. Will get resized first.
        /// @param args: a shape or nothing depending on derived type.
        ///
        template<typename Matrix, typename ...Args,
                 typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                            eigen_rows_v<Matrix>()==dim> >
        void draw(Matrix &mat, Args &&...args) const;

        /// @brief Draw a Complete Spatial Randomness realization into
        /// a mat, bounded by a shape, with specific number of samples.
        ///
        /// @param mat: the input / output matrix where pts are drawn.
        /// @param shape: the input bounding shape.
        /// @param n_samples: the number of samples to draw.
        ///
        template<typename Matrix, typename Shape,
                 typename = enable_if_all_t<is_stg_shape_v<Shape>(),
                                            is_eigen_v<Matrix>(),
                                            eigen_rows_v<Matrix>()==dim> >
        void csr_draw(Matrix &mat, Shape &&shape, int n_samples) const;

        /// @brief Alter upper & lower bound of the internal uniform r.v.
        /// according to input bounding box. This is a const ops,
        /// since it does not alter the distribution of the process.
        ///
        /// @param bound: an input bounding box.
        ///
        template<typename Bound> void bind_to_bound(Bound &&) const;

        mutable smplr_t _rnd_smplr; //:< The random uniform sampler array.
      };

    }

    /// @ingroup group_pproc
    ///
    /// @brief Complete Spatial Randomness sampler with scalar intensity.
    ///
    /// This class just wraps **a Dim-dimensional uniform random variable
    /// and a scalar intensity value**.
    ///
    /// @param T: the scalar type used for computations.
    /// @param Dim: the dimension.
    ///
    template<typename T, int Dim> class CSRSampler<T,Dim,T,true>
      : public abstract::csrbase<CSRSampler<T,Dim,T,true> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            =       CSRSampler<T,Dim,T,true>;
      using specs_t            = stogeo::traits::specs<exact_t>;
      using scalr_t            =      typename specs_t::scalr_t;
      using inten_t            =      typename specs_t::inten_t;
      using point_t            =      typename specs_t::point_t;
      using vectr_t            =      typename specs_t::vectr_t;
      using matrx_t            =      typename specs_t::matrx_t;
      using slice_t            =      typename specs_t::slice_t;

      using parnt_t            =     abstract::csrbase<exact_t>;
      friend                                            parnt_t;

      static constexpr int dim =                            Dim;

      using parnt_t::draw;
      using parnt_t::csr_draw;
      using parnt_t::reset_state;
      using parnt_t::bind_to_bound;

      /// @brief Default ctor.
      CSRSampler(): _intensity(0) {};

      /// @brief Ctor. Taking a scalar intensity value.
      ///
      /// @param intensity: the scalar intensity, stogeo::Intensity.
      /// Or samply just a scalar value.
      ///
      template<typename IntenType> explicit CSRSampler(IntenType &&intensity);

      /// @brief Const access to the curr held intensity value.
      ///
      /// @return A copy of curr held intensity value.
      ///
      scalr_t intensity() const { return _intensity.get(); }

    private:

      /// @brief Get the random number of samples within a given bound box.
      ///
      /// @param bound: an input bounding box.
      /// @return A Poisson r.v. computed from bound and curr inten.
      ///
      template<typename Bound> long int n_samples(Bound &&) const;

      /// @brief Draw a realization into a matrix, pts bounded by a shape.
      ///
      /// @param mat: the input / output matrix where value will be
      /// drawn into. Will get resized first.
      /// @param shape: a shape as a bound for drawn pts.
      ///
      template<typename Matrix, typename Shape,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim,
                                          is_stg_shape_v<Shape>()> >
      void draw_impl(Matrix &mat, Shape &&shape) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      using                 parnt_t::_rnd_smplr; //:< Unif sampler arr.
      mutable rnd::Poisson<long int> _nsampl_rv; //:< The Poisson generator.
      inten_t                        _intensity; //:< The intensity value.
    };


    /// @ingroup group_pproc
    ///
    /// @brief Complete Spatial Randomness sampler with functional
    /// intensity.
    ///
    /// This class just wraps **a Dim-dimensional uniform random
    /// variable**, an **intensity function**, and **an optional
    /// observation window**. The simulation uses **thinning
    /// strategy** which samples first unformly randomly, then
    /// performs thinning based on the shape of the intensity
    /// function.
    /// * When an intensity function is passed with a **max value
    ///   hint**, the `draw()` method **will not need an observation
    ///   window**.
    /// * When an intensity function is passed without **max value
    ///   hint**, the draw method **must be provided with an observation
    ///   window**. The max value will be evaluated internally, so
    ///   this will be slower.
    ///
    /// @warning When a max hint is provided, **it is the user's
    /// responsibility to garantee that it is indeed the max value.**
    /// Otherwise the **simulation will produce undefined results.**
    ///
    /// @param T: the scalar type used for computations.
    /// @param Dim: the dimension.
    /// @param Inten: the functional intensity type, can be type of a lambda
    /// or functional object.
    ///
    template<typename T, int Dim, typename Inten>
    class CSRSampler<T,Dim,Inten,false>
      : public abstract::csrbase<CSRSampler<T,Dim,Inten,false> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            =  CSRSampler<T,Dim,Inten,false>;
      using specs_t            = stogeo::traits::specs<exact_t>;
      using scalr_t            =      typename specs_t::scalr_t;
      using inten_t            =      typename specs_t::inten_t;
      using obswd_t            =      typename specs_t::obswd_t;
      using point_t            =      typename specs_t::point_t;
      using vectr_t            =      typename specs_t::vectr_t;
      using matrx_t            =      typename specs_t::matrx_t;
      using slice_t            =      typename specs_t::slice_t;

      static constexpr int dim =                            Dim;

      using parnt_t            =     abstract::csrbase<exact_t>;
      friend                                            parnt_t;

      using                                       parnt_t::draw;
      using                                   parnt_t::csr_draw;
      using                              parnt_t::bind_to_bound;

      /// @brief Default ctor.
      CSRSampler() = default;

      /// @brief Ctor taking an intensity function.
      ///
      /// @warning The maximum of the intensity function must be
      /// provided, so that the observe window won't be asked for
      /// ctor. Value of the max MUST BE REAL MAXIMUM VALUE OF THE
      /// INTEN FUNC WITHIN OBS WINDOW GIVEN BY DRAW LATTER, or else
      /// it might yield false results.
      ///
      /// @param func: an intensity func from stogeo::pps::Intensity.
      /// See class doc for convenient typedefs.
      ///
      template<typename IntenType> explicit CSRSampler(IntenType &&func);

      /// @brief Ctor taking functional intensity with obs window.
      ///
      /// A grid search will be performed to evaluate the inten max.
      /// Inten max and window are then used to set the mean of the
      /// nsample_rv Poisson random variable.
      ///
      /// @param shape: the observe window, must be a stogeo shape.
      /// @param func: an intensity func from stogeo::pps::Intensity.
      /// See class doc for convenient typedefs.
      ///
      template<typename IntenType, typename Shape,
               typename = enable_if_t<is_stg_shape_v<Shape>()> >
      CSRSampler(Shape &&shape, IntenType &&func);

      /// @brief Check if the window is initialized in curr instance.
      ///
      /// @return True if curr instance has an initialized window.
      ///
      bool window_ready() const
      { return static_cast<bool>(_obs_windw) == true; }

      /// @brief Access observation window.
      ///
      /// An assert is set on whether the window is initialized. If
      /// turned off, return an uninitialized instance is undefined
      /// behavior.
      ///
      /// @return A non-const reference to current held window.
      ///
      obswd_t& obs_window();

      /// @brief Const access observation window.
      ///
      /// An assert is set on whether the window is initialized. If
      /// turned off, return an uninitialized instance is undefined
      /// behavior.
      ///
      /// @return A const reference to current held window.
      ///
      const obswd_t& obs_window() const;

      /// @brief Reset the value of the window.
      ///
      /// Whether to re-evaluate the maximum of intensity value is
      /// specified by a bool tag.
      ///
      /// @param window: the new window to be set.
      /// @param eval_max: whether to re-evaluate the inten max val.
      /// Default to yes / true.
      /// @param spacing: grid size of max search. Default to 0.2.
      /// @param mag: magnification factor of max search. Default to
      /// 1.2.
      ///
      template<typename Shape,
               typename = enable_if_t<is_stg_shape_v<Shape>()> >
      void set_window(Shape &&window, bool eval_max=true,
                      scalr_t spacing=0.2, scalr_t mag=1.2) const;

      /// @brief Const access to the curr held intensity func.
      ///
      /// @return A const reference to curr held intensity func.
      ///
      const inten_t& intensity() const { return _intensity; }

    private:

      /// @brief Get the max number of samples within a given bound.
      ///
      /// The numb of samples before final thinning step is calculated
      /// from the max value of the curr held intensity function. It
      /// is called only for intensity function w/o obs window cache.
      ///
      /// @param bound: an input bounding box.
      /// @return A Poisson r.v. computed from bound and max_value of
      /// the current intensity function.
      ///
      template<typename Bound> int max_samples(Bound &&bound) const;

      /// @brief Draw into a matrix.
      ///
      /// Without specified obs window. This impl will be called by the
      /// draw interface in csrbase. The window held by the instance
      /// will be used and must be initialized.
      ///
      /// @param mat: the input matrix where realization will be drawn
      /// into.
      ///
      template<typename Matrix,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &mat) const;

      /// @brief Draw into a matrix.
      ///
      /// With specified obs window. This impl will be called by the
      /// draw interface in csrbase.
      ///
      /// @note This method will use the window specified by the
      /// input argument even if an internal window already exists.
      ///
      /// @param mat: the input mat where pts will be drawn into.
      /// @param window: the observation window used as bound.
      ///
      template<typename Matrix, typename Shape,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim,
                                          is_stg_shape_v<Shape>()> >
      void draw_impl(Matrix &mat, Shape &&window) const;

      /// @brief Peforms thinning to obtain final points.
      ///
      /// @param mat: pt matrix prior to the final thinning step.
      ///
      template<typename Matrix,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void __thinning(Matrix &mat) const;

      /// @brief Reset the mean of the nsample_rv Poisson random var.
      ///
      /// The new mean value is set to be the product of the bound's
      /// volume and the max value of the current intensity.
      ///
      /// @param bound: the input bounding box.
      ///
      template<typename Bound> void reset_nsampl_rv(Bound &&bound) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      using               parnt_t::_rnd_smplr;

      mutable optional<obswd_t> _obs_windw; //:< The observation window.
      mutable rnd::Poisson<int> _nsampl_rv; //:< The Poisson number generator.
      inten_t                   _intensity; //:< The intensity function.
    };

  }
}


# include "ppsbase.hxx"
#endif
