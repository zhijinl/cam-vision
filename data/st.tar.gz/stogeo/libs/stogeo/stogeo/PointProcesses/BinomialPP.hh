// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// BinomialPP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Aug  7 15:38:40 2016 Zhijin Li
// Last update Tue Sep 26 14:41:26 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_BINOMIALPP_HH
# define STOGEO_BINOMIALPP_HH

# include "ppsbase.hh"


namespace stogeo
{

  // Fwd decl.
  namespace pps
  {
    template<typename T, int, typename Inten=T,
             bool cond=is_arithmetic_v<Inten>()> class BinomialPP;
  }

  /// @ingroup group_traits
  namespace traits
  {

    template<typename T, int Dim, typename Inten>
    struct specs<pps::Binomial<T,Dim,Inten> >
    {
      static constexpr int dim          =                        Dim;
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static constexpr bool has_window  =  !is_arithmetic_v<Inten>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten>                          inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef SimplePointPattern<T,Dim>                      extra_t;
    };

    template<typename T, int Dim, typename Inten>
    struct specs<pps::Binomial<T,Dim,Inten> >
    {
      static constexpr int dim          =                        Dim;
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static constexpr bool has_window  =  !is_arithmetic_v<Inten>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten>                          inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef SimplePointPattern<T,Dim>                      extra_t;
    };

  }

  namespace pps
  {

    /// Class implementing the binomial sampler.
    template<typename EXACT> class BinoSampler: public csrbase<EXACT>
    {
    public:

      /// Ctor. Taking an observation window and number of samples
      /// as argument.
      ///
      /// @param window: the observation window.
      /// @param n_samples: total number of samples.
      ///
      template<typename Shape,
               typename = enable_if_t<is_stg_shape_v<Shape>()> >
      BinoSampler(Shape &&window, int n_samples):
        _obs_windw(std::forward<Shape>(window)),
        _n_samples(n_samples) {};

    private:


      using
      obswd_t _obs_windw;
      int     _n_samples;
    };


    /// Class for Binomial


  } //!pps
} //!stogeo


# include "BinomialPP.hxx"
#endif //!STOGEO_BINOMIALPP_HH
