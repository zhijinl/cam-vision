// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// PoissonPP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 06 10:22:07 2015 Zhijin Li
// Last update Tue Sep 26 14:41:26 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_POISSONPP_HH
# define STOGEO_POISSONPP_HH

# include "ppsbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace pps
  {
    template<typename, int, typename> class PoissonPP;
  }

  /// @ingroup group_traits
  namespace traits
  {

    /// @ingroup group_traits
    ///
    /// @brief Type traits for the `stogeo::pps::PoissonPP` class:
    /// the **Poisson point process**.
    ///
    template<typename T, int Dim, typename Inten>
    struct specs<pps::PoissonPP<T,Dim,Inten> >
    {
      static constexpr int dim          =                         Dim;
      static const stg_ids stg_id       =       stg_ids::STOGEO_PPROC;
      static constexpr bool has_window  =   !is_arithmetic_v<Inten>();
      typedef T                                               scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >       obswd_t;
      typedef typename traits::specs<pps::CSRSampler
                                     <T,Dim,Inten> >::inten_t inten_t;
      typedef Eigen::Matrix<T,Dim,1>                          point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>               vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>             matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>            slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic>  dymmt_t;
      typedef SimplePointPattern<T,Dim>                       realz_t;
      typedef SimplePointPattern<T,Dim>                       extra_t;
    };
  }


  /// @ingroup group_pproc
  namespace pps
  {

    /// @ingroup group_pproc
    ///
    /// @brief Class of homogeneous & inhomogeneous Poisson point process.
    ///
    /// @param T: the scalar type.
    /// @param Dim: dimension of the point process.
    /// @param Inten: type of the intensity. Can be arithmetic for
    /// homogeneous Poisson pp, or a lambda/functor for inhomogeneous Poisson
    /// pp.
    ///
    template<typename T, int Dim, typename Inten> class PoissonPP
      : public abstract::ppsbase<PoissonPP<T,Dim,Inten> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            =   PoissonPP<T,Dim,Inten>;
      using specs_t            =       traits::specs<exact_t>;
      using scalr_t            =    typename specs_t::scalr_t;
      using inten_t            =    typename specs_t::inten_t;
      using obswd_t            =    typename specs_t::obswd_t;
      using point_t            =    typename specs_t::point_t;
      using vectr_t            =    typename specs_t::vectr_t;
      using matrx_t            =    typename specs_t::matrx_t;
      using slice_t            =    typename specs_t::slice_t;
      using realz_t            =    typename specs_t::realz_t;
      using extra_t            =    typename specs_t::extra_t;

      using parnt_t            =   abstract::ppsbase<exact_t>;
      friend                                          parnt_t;

      using parnt_t::                                    draw;
      using parnt_t::                                   print;
      using parnt_t::                             reset_state;

      static constexpr int dim =                          Dim;

      /// @brief Default ctor.
      PoissonPP() = default;

      /// @brief Ctor. Taking only intensity, scalar or functional.
      ///
      /// When functional intensity is given, the inten func must be
      /// initialized with max_hint. Otherwise behavior is undefined:
      /// if assert enabled, program will exit.
      ///
      /// @param inten_func: the intensity value or func.
      ///
      /// @sa `stogeo::pps::CSRSampler<T,Dim,T,true>`
      /// @sa `stogeo::pps::CSRSampler<T,Dim,Inten,false>`
      ///
      template<typename IntenType,
               typename = enable_if_t<is_intensity_v<IntenType>()> >
      explicit PoissonPP(IntenType &&);

      /// @brief Ctor taking a functional intensity with a bounding
      /// shape as observation window.
      ///
      /// @param window: the observation window, a stogeo::shape.
      /// @param inten_func: the intensity func.
      ///
      /// @sa `stogeo::pps::CSRSampler<T,Dim,Inten,false>`
      ///
      template<typename IntenType, typename Shape,
               typename = enable_if_all_t<is_stg_shape_v<Shape>(),
                                          is_intensity_v<IntenType>()> >
      PoissonPP(Shape &&, IntenType &&);

      /// @brief Access observation window (if makes sense).
      ///
      /// @note Fails to compile if window does not exist: i.e. if the
      /// Poisson pp is defined on @f$ \mathbf{R}^d @f$.
      ///
      /// @return Reference to curr held observation window.
      ///
      obswd_t& obs_window();

      /// @brief Const access observation window (if makes sense).
      ///
      /// @note Fails to compile if window does not exist: i.e. if the
      /// Poisson pp is defined on @f$ \mathbf{R}^d @f$.
      ///
      /// @return Const reference to curr held observation window.
      ///
      const obswd_t& obs_window() const;

      /// @brief Const access to the curr held intensity func.
      ///
      /// @return A const reference to curr held intensity func.
      ///
      const inten_t& intensity() const
      { return _csr_sampler.intensity(); }

    private:

      /// @brief Run a realization.
      ///
      /// @param mat: the input/output matrix where points will be drawn
      /// into.
      /// @param args: a window or nothing.
      ///
      template<typename Matrix, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &mat, Args &&...args) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      CSRSampler<T,Dim,Inten> _csr_sampler; //:< A CSR sampler.
    };


  }
}


# include "PoissonPP.hxx"
#endif
