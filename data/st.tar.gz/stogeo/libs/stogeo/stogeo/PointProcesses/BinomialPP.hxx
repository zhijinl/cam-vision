// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// BinomialPP.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Aug  7 15:40:28 2016 Zhijin Li
// Last update Sun Aug  7 15:40:29 2016 Zhijin Li
// ---------------------------------------------------------------------------
