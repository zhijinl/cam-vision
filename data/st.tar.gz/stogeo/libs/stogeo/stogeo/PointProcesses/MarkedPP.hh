// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MarkedPP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jan  4 09:43:09 2016 Zhijin Li
// Last update Wed Oct 11 17:00:06 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_MARKEDPP_HH
# define STOGEO_MARKEDPP_HH

# include "ppsbase.hh"


namespace stogeo
{
  // Fwd decl.
  namespace pps
  {
    template<typename Proc, typename Mark, int Dim=0> class MarkedPP;
  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup group_traits
    ///
    /// @brief Type traits for the `stogeo::pps::MarkedPP<Proc,Mark>`
    /// class: the **marked point process with geometric marks**.
    ///
    template<typename Proc, typename Mark>
    struct specs<pps::MarkedPP<Proc,Mark> >
    {
      typedef Proc                                            pproc_t;
      typedef Mark                                            pmark_t;
      typedef typename traits::specs<Proc>::scalr_t           scalr_t;
      typedef typename traits::specs<Mark>::scalr_t           msclr_t;
      typedef typename traits::specs<Proc>::inten_t           inten_t;

      static constexpr stg_ids stg_id =         stg_ids::STOGEO_MPROC;
      static constexpr int dim        =      traits::specs<Proc>::dim;
      static constexpr int mark_dim   = traits::specs<Mark>::n_params;

      typedef MarkedPointPattern<Mark>                        realz_t;
      typedef MarkedPointPattern<Mark>                        extra_t;
      typedef typename specs<realz_t>::point_t                point_t;
      typedef typename specs<realz_t>::vectr_t                vectr_t;
      typedef typename specs<realz_t>::matrx_t                matrx_t;
      typedef typename specs<realz_t>::slice_t                slice_t;
      typedef typename specs<realz_t>::dymmt_t                dymmt_t;
    };

    /// @ingroup group_traits
    ///
    /// @brief Type traits for the `stogeo::pps::MarkedPP<Proc,MScalr,MDim>`
    /// class: the **marked point process with arithmetic marks**.
    ///
    template<typename Proc, typename MScalr, int MDim>
    struct specs<pps::MarkedPP<Proc,MScalr,MDim> >
    {
      typedef Proc                                         pproc_t;
      typedef pmark_dispatch_t<MScalr,MDim>                pmark_t;
      typedef typename traits::specs<Proc>::scalr_t        scalr_t;
      typedef MScalr                                       msclr_t;
      typedef variant<msclr_t,
                             rnd::RUniform<msclr_t>,
                             rnd::Poisson<msclr_t>,
                             rnd::Gaussian<msclr_t>,
                             rnd::Bernoulli>               distr_t;
      typedef mdist_dispatch_t<distr_t,MDim>               mdist_t;
      typedef typename traits::specs<Proc>::inten_t        inten_t;

      static constexpr stg_ids stg_id =      stg_ids::STOGEO_MPROC;
      static constexpr int dim        =   traits::specs<Proc>::dim;
      static constexpr int mark_dim   =                       MDim;

      typedef MarkedPointPattern<scalr_t,dim,msclr_t,MDim> realz_t;
      typedef MarkedPointPattern<scalr_t,dim,msclr_t,MDim> extra_t;
      typedef typename specs<realz_t>::point_t             point_t;
      typedef typename specs<realz_t>::vectr_t             vectr_t;
      typedef typename specs<realz_t>::matrx_t             matrx_t;
      typedef typename specs<realz_t>::slice_t             slice_t;
      typedef typename specs<realz_t>::dymmt_t             dymmt_t;
    };

  }

  /// @ingroup group_pproc
  namespace pps
  {

    /// @ingroup group_pproc
    /// @brief Class for geometric marked point processes.
    ///
    /// Marks types must one of `stogeo::shapes` types.
    ///
    /// @param Proc: the **ground point process** type.
    /// @param Mark: the mark type, must be one of `stogeo::shapes` types.
    ///
    template<typename Proc, typename Mark> class MarkedPP<Proc,Mark>
      : public abstract::ppsbase<MarkedPP<Proc,Mark> >
    {
      static_assert(is_stg_shape_v<Mark>(),
                    "ERROR: THIS SPECIALIZATION EXPECTS GEOMETRIC MARKS.");

    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t                   =           MarkedPP<Proc,Mark>;
      using specs_t                   =        traits::specs<exact_t>;
      using pproc_t                   =     typename specs_t::pproc_t;
      using pmark_t                   =     typename specs_t::pmark_t;
      using scalr_t                   =     typename specs_t::scalr_t;
      using msclr_t                   =     typename specs_t::msclr_t;
      using realz_t                   =     typename specs_t::realz_t;
      using point_t                   =     typename specs_t::point_t;
      using vectr_t                   =     typename specs_t::vectr_t;
      using matrx_t                   =     typename specs_t::matrx_t;
      using slice_t                   =     typename specs_t::slice_t;
      using dymmt_t                   =     typename specs_t::dymmt_t;

      using parnt_t                   =    abstract::ppsbase<exact_t>;
      friend                                                  parnt_t;

      using parnt_t::                                            draw;
      using parnt_t::                                           print;
      using parnt_t::                                     reset_state;

      static constexpr int dim        =      traits::specs<Proc>::dim;
      static constexpr int mark_dim   = traits::specs<Mark>::n_params;

      /// @brief Default ctor.
      MarkedPP() = default;

      /// @brief Ctor. Taking a point process and a geometric object.
      ///
      /// @param pproc: the input point process.
      /// @param shape: the input geometric mark: a (rnd) shape.
      ///
      template<typename PProc, typename Shape,
               typename = enable_if_all_t<is_same_v<PProc,pproc_t>(),
                                          is_stg_shape_v<Shape>()> >
      MarkedPP(PProc &&pproc, Shape &&pmark):
        _pproc(std::forward<PProc>(pproc)),
        _pmark(std::forward<Shape>(pmark)) {};

    private:

      /// @brief Run a realization.
      ///
      /// @warning Marks will be drawn into a matrix, so their **vector
      /// representation** are drawn, not the geometric representation.
      /// Need to explicitly call marks constructor to retrieve geometric
      /// objects.
      ///
      /// @param mat: the input/output matrix where points are drawn into.
      /// @param marks: the input/output matrix where marks are drawn into.
      /// @param args: additional arguments for observation window
      /// specification which can be a `stogeo::shapes` or nothing.
      ///
      template<typename Matrix, typename Marks, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          is_eigen_v<Marks>(),
                                          eigen_rows_v<Matrix>()==dim,
                                          eigen_rows_v<Matrix>()==mark_dim> >
      void draw_impl(Matrix &mat, Marks &marks, Args &&...args) const;

      /// @brief Run a realization.
      ///
      /// This draws a realization into a `stogeo::MarkedPointPattern<Mark>`
      /// with geometric marks.
      ///
      /// @param realz: the input/output `stogeo::MarkedPointPattern<Mark>`.
      /// @param args: additional arguments for observation window
      /// specification which can be a `stogeo::shapes` or nothing.
      ///
      template<typename ...Args>
      void draw_impl(realz_t &realz, Args &&...args) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      pproc_t         _pproc; //:< The ground point process.
      mutable pmark_t _pmark; //:< The geometric mark.
    };

  }
}


# include "MarkedPP.hxx"
#endif
