// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// MaternCluster.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri Nov  6 09:59:39 2015 Zhijin Li
// Last update Mon Sep 11 18:54:04 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename ParentType, typename ChildType,
             typename ShapeType, typename>
    MaternClusterPP<T,Dim,Shape,Parent,Child>::
    MaternClusterPP(ParentType &&paren, ChildType &&child, ShapeType &&shape):
      _paren_process(std::forward<ParentType>(paren)),
      _child_process(std::forward<ChildType>(child)),
      _cluster_shape(std::forward<ShapeType>(shape)) {};

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Window, typename ParentType, typename ChildType,
             typename ShapeType, typename>
    MaternClusterPP<T,Dim,Shape,Parent,Child>::
    MaternClusterPP(Window &&window, ParentType &&paren, ChildType &&child,
                    ShapeType &&shape):
      _paren_process(std::forward<Window>(window),
                     std::forward<ParentType>(paren)),
      _child_process(std::forward<ChildType>(child)),
      _cluster_shape(std::forward<ShapeType>(shape)) {};

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child> template<typename ...Args>
    auto MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_clusters(Args &&...args) const -> clust_t
    {
      auto __shp_ctrs = _paren_process.draw(std::forward<Args>(args)...);
      clust_t __clusters(__shp_ctrs.n_elem()); // reserve memory.

      for(int __n = 0; __n < __shp_ctrs.n_elem(); ++__n)
        __clusters.append(_cluster_shape.draw(__shp_ctrs.pt(__n)));
      return __clusters;
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Matrix, typename ...Args, typename>
    void MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_impl(Matrix &mat, Args &&...args) const
    {
      auto __clusters = draw_clusters(std::forward<Args>(args)...);
      draw_child_dispatch(inten_tag_dispatch_t<Child>{}, mat, __clusters);
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Matrix, typename Shapes>
    void MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_child_dispatch(scalr_inten_tag_t, Matrix &mat,
                        const Shapes &shapes) const
    {
      draw_child(mat, shapes);
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Matrix, typename Shapes>
    void MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_child_dispatch(funct_inten_tag_t,
                        Matrix &mat,
                        const Shapes &shapes) const
    {
      if( _child_process.intensity().need_eval() )
        draw_child_eval(mat, shapes); // need eval -> copy cluster shape.
      else
        draw_child(mat, shapes); // need not eval -> no copy.
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Matrix, typename Shapes>
    void MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_child_eval(Matrix &mat, const Shapes &shapes) const
    {
      std::vector<matrx_t> __child_vec;
      __child_vec.reserve(shapes.n_elem());
      for(int __n = 0; __n < shapes.n_elem(); ++__n)
      {
        _child_process.set_window(shapes.mark(__n)); // Triggers inten eval.
        __child_vec.emplace_back( std::move(_child_process.draw().pts()) );
      }
      mat = utils::bind_cols(__child_vec);
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    template<typename Matrix, typename Shapes>
    void MaternClusterPP<T,Dim,Shape,Parent,Child>::
    draw_child(Matrix &mat, const Shapes &shapes) const
    {
      std::vector<matrx_t> __child_vec;
      __child_vec.reserve(shapes.n_elem());
      for(int __n = 0; __n < shapes.n_elem(); ++__n)
      {
        __child_vec.emplace_back
          ( std::move(_child_process.draw(shapes.mark(__n)).pts()) );
      }
      mat = utils::bind_cols(__child_vec);
    }

    // =====================================================================
    template<typename T, int Dim, template<typename,int> class Shape,
             typename Parent, typename Child>
    auto MaternClusterPP<T,Dim,Shape,Parent,Child>::
    reset_state_impl() -> exact_t&
    {
      _paren_process.reset_state();
      _child_process.reset_state();
      _cluster_shape.reset_state();
      return *this;
    }

  } //!pps
} //!stogeo
