// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MaternHardPP.hh for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 20 10:21:07 2016 Zhijin Li
// Last update Tue Sep 26 17:14:53 2017 Zhijin Li
// ---------------------------------------------------------------------------


#ifndef STOGEO_MATERNHARDPP_HH
# define STOGEO_MATERNHARDPP_HH

# include "PoissonPP.hh"


namespace stogeo
{

  /// @ingroup group_pproc
  namespace pps
  {
    // Base-case for Matern Harcore processes.
    template<typename T, int Dim, mtn_hc Type, typename Inten=T,
             bool cond=(Type==mtn_hc::TypeI)> class MaternHardPP {};

    // Dispatcher for Matern Hardcore types.
    struct type_i_t {};
    struct type_ii_t {};
    struct type_iii_t {};
    template<mtn_hc> struct type_dispatcher { using type = void; };

    template<> struct type_dispatcher<mtn_hc::  TypeI>
    { using type = type_i_t; };
    template<> struct type_dispatcher<mtn_hc:: TypeII>
    { using type = type_ii_t; };
    template<> struct type_dispatcher<mtn_hc::TypeIII>
    { using type = type_iii_t; };

    template<mtn_hc Type>
    using matern_type_t = typename type_dispatcher<Type>::type;

  }

  /// @ingroup group_traits
  namespace traits
  {
    /// @ingroup goup_traits
    ///
    /// @brief Type traits porperties for the
    /// `stogeo::pps::MaternHardPP<T,Dim,mtn_hc::TypeI,Inten>` class:
    /// **the Matern hardcore process of type I.**.
    ///
    template<typename T, int Dim, typename Inten>
    struct specs<pps::MaternHardPP<T,Dim,mtn_hc::TypeI,Inten> >
    {
      static constexpr int dim          =                        Dim;
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static const mtn_hc matern_type   =              mtn_hc::TypeI;
      static constexpr bool has_window  =  !is_arithmetic_v<Inten>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten>                          inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef SimplePointPattern<T,Dim>                      extra_t;
    };

    /// @ingroup goup_traits
    ///
    /// @brief Type traits porperties for the
    /// `stogeo::pps::MaternHardPP<T,Dim,Type,Inten,false>` class:
    /// **the Matern hardcore process of type II & type III.**.
    ///
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    struct specs<pps::MaternHardPP<T,Dim,Type,Inten,false> >
    {
      static constexpr int dim          =                        Dim;
      static const stg_ids stg_id       =      stg_ids::STOGEO_PPROC;
      static const mtn_hc matern_type   =                       Type;
      static constexpr bool has_window  =  !is_arithmetic_v<Inten>();
      typedef T                                              scalr_t;
      typedef variant<shapes::Box<T,Dim> ,
                             shapes::Sphere<T,Dim> ,
                             shapes::Ellipsoid<T,Dim> ,
                             shapes::Rectangle<T,Dim> >      obswd_t;
      typedef pps::Intensity<Inten>                          inten_t;
      typedef Eigen::Matrix<T,Dim,1>                         point_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,1>              vectr_t;
      typedef Eigen::Matrix<T,Dim,Eigen::Dynamic>            matrx_t;
      typedef Eigen::Matrix<bool,Eigen::Dynamic,1>           slice_t;
      typedef Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic> dymmt_t;
      typedef Eigen::Matrix<T,1,Eigen::Dynamic>              times_t;
      typedef SimplePointPattern<T,Dim>                      realz_t;
      typedef MarkedPointPattern<T,Dim,T,1>                  extra_t;
    };

  }

  /// @ingroup group_pproc
  namespace pps
  {
    namespace abstract
    {
      /// @ingroup group_pproc
      ///
      /// @brief The base class for hardcore processes.
      ///
      /// @param EXACT: the type of derived class inheriting from it.
      ///
      template<typename EXACT> class hardbase: public abstract::ppsbase<EXACT>
      {
      public:
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        using exact_t = EXACT;
        using scalr_t = typename traits::specs<exact_t>::scalr_t;
        using inten_t = typename traits::specs<exact_t>::inten_t;

        static constexpr int dim = traits::specs<exact_t>::dim;

      protected:

        /// @brief Default ctor.
        hardbase() = default;

        /// @brief Ctor. Taking hardcore distance and intensity val / func.
        /// When an intensity func is taken, it must be initialized
        /// with max-hint, otherwise the result is undefined.
        ///
        /// @param hdcr_dist: the hardcore distance.
        /// @param intensity: the intensity value or function.
        ///
        template<typename IntenType,
                 typename = enable_if_t<is_intensity_v<IntenType>()> >
        hardbase(scalr_t hdcr_dist, IntenType &&intensity);

        /// @brief Ctor. Taking functional intensity and and obs window.
        ///
        /// @param window: the obs window, s stogeo::shape.
        /// @param hdcr_dist: the hardcore distance.
        /// @param intensity: the intensity value or function.
        ///
        template<typename IntenType, typename Shape,
                 typename = enable_if_all_t<is_stg_shape_v<Shape>(),
                                            is_intensity_v<IntenType>()> >
        hardbase(Shape &&window, scalr_t hdcr_dist, IntenType &&intensity);

        /// @brief Access the hardcore distance.
        ///
        /// @return The hardcore distance by value.
        ///
        scalr_t hc_dist() const { return _hdcr_sphr.param(); }

        /// @brief Reset the internal state of the point process.
        ///
        /// Together with the `stogeo::utils::reset_shared_engine()`
        /// function, they can be used to reproduce the same simulation
        /// results.
        ///
        exact_t& reset_state_impl();

        CSRSampler<scalr_t,dim,scalr_t>     _csr_smplr; //!< CSR sampler.
        mutable shapes::Sphere<scalr_t,dim> _hdcr_sphr; //!< Hardcore sphere.
      };

    }
  }

  /// @ingroup group_pproc
  namespace pps
  {

    /// @ingroup group_pproc
    ///
    /// @brief Matern Hardcore point process of type I.
    ///
    /// The Matern point process of type I is a **dependent thinning** of a
    /// Poisson point process. It works as follows.
    /// 1. Draw a realization of a Poisson point process.
    /// 2. Each point in the realization is **deleted if it has at least one
    ///    neighbor points within a hardcore distance.**
    /// In another words, it let only points **singled-out from the population
    /// with at least the hardcore distance survived**. It often deletes much
    /// more points than the Matern type II & type III process.
    ///
    /// @param T: the scalar type used for computations.
    /// @param Dim: the dimension.
    /// @param Type: in this case `TypeI` from `enum class mtn_hc`.
    /// @param Inten: the intensity type.
    ///  1. Defaults to be arithmetic, i.e. uniform intensity value. Can
    ///     use **convenient aliases** from the `stogeo::Intensity` class:
    ///     such as `stogeo::IntenVal_f`, `stogeo::IntenVal_d`.
    ///  2. Can also be functional. In this case, **wrap a functor or
    ///     lambda into functional version of `stogeo::Intensity` object.
    ///     Can use **convenient aliases** such as `stogeo::IntenFun_f`
    ///     or `stogeo::IntenVal_d`.
    ///
    template<typename T, int Dim, typename Inten>
    class MaternHardPP<T,Dim,mtn_hc::TypeI,Inten>
      : public abstract::hardbase<MaternHardPP<T,Dim,mtn_hc::TypeI,Inten> >
    {
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            = MaternHardPP<T,Dim,mtn_hc::TypeI,Inten>;
      using specs_t            = traits::specs<exact_t>;
      using scalr_t            = typename specs_t::scalr_t;
      using inten_t            = typename specs_t::inten_t;
      using point_t            = typename specs_t::point_t;
      using vectr_t            = typename specs_t::vectr_t;
      using matrx_t            = typename specs_t::matrx_t;
      using slice_t            = typename specs_t::slice_t;
      using field_t            = typename specs_t::dymmt_t;
      using realz_t            = typename specs_t::realz_t;

      using parnt_t            = abstract::ppsbase<exact_t>;
      using super_t            = abstract::hardbase<exact_t>;
      friend                     parnt_t;

      using parnt_t::               draw;
      using parnt_t::              print;
      using parnt_t::        reset_state;
      using super_t::            hc_dist;

      static constexpr int dim =     Dim;

      /// @brief Forwarding ctor.
      ///
      /// Forwards all arguments to matching ctor from `super_t`, i.e.
      /// `stogeo::pps::abstract::hardbase`.
      ///
      /// @param args: variadic arguments matching those of the ctors of
      /// `stogeo::pps::abstract::hardbase` class.
      ///
      /// @sa `stogeo::pps::abstract::hardbase`
      ///
      template<typename ...Args,
               enable_if_all_t<!is_base_of_v<exact_t,Args>()...>* = nullptr>
      MaternHardPP(Args &&...args):
        super_t( std::forward<Args>(args)... ) {};

    private:

      /// @brief Apply retaining rule of Type I.
      ///
      /// This function is of internal usage.
      ///
      /// @param indx: the index of current point.
      /// @param lv: a logical vector. Will be set to zero at `indx`, if
      /// that point is to be deleted.
      /// @parama mat: matrix containing all original Poisson pp points.
      ///
      template<typename Matrix,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void apply_rule(int indx, slice_t &lv, const Matrix &mat) const;

      /// @brief Run a realization.
      ///
      /// @note This `impl` will be dispatched to the generic interface
      /// in the base class `stogeo::pps::abstract::ppsbase`.
      ///
      /// @param mat: the matrix where sample points will be stored.
      /// @param args: additional parameters, can be an observation or
      /// not depending on the intensity setting.
      ///
      /// @sa `stogeo::pps::abstract::ppsbase::draw()`.
      ///
      template<typename Matrix, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &mat, Args &&...args) const;

      using super_t::reset_state_impl;

      using super_t::_csr_smplr;
      using super_t::_hdcr_sphr;
    };


    /// @ingroup group_pproc
    ///
    /// @brief Matern hardcore point process of type II & type III.
    ///
    /// The type II Matern hardcore process introduces an **independent
    /// uniform mark** to each sample point. It works as follows:
    /// 1. Draw a realization of a Poisson point process as usual.
    /// 2. Then associate each point with a uniform real random valued
    ///    in (0,1), called `birthday`, informally.
    /// 2. For each point, search for neighboring point as in the type
    ///    I process. If for the current point has a neighbor closer
    ///    than the hardcore distance, it will be **deleted only when
    ///    its associated birthday is greater than the neighbor's**.
    /// In another words, the type II process will **only deleted one of
    /// the points in a pair of points closer to each other than the
    /// hardcore distance. It will delete must less points than the type
    /// I process.
    ///
    /// The type III process also introduces the **birthday mark**. But
    /// it works in a recursivce fashion and it takes into account **if
    /// a neighbor point has already been deleted or not**. It works as
    /// follows:
    /// 1. The first & second steps are the same as with the type II
    ///    process.
    /// 2. For each point, if it has a neighbor closer than the hardcore
    ///    distance, first **check if the neighbor has already been
    ///    deleted**:
    ///    * If yes, keep the current point.
    ///    * If not, compare the birthday value, apply the same rule as
    ///      for the type II process.
    /// It generally will **delete even less points than the type II
    /// process**.
    ///
    /// @param T: the scalar type used for computations.
    /// @param Dim: the dimension.
    /// @param Type: an `enum class mtn_hc` type. In this case,tEither
    /// `TypeII` or `TypeIII`.
    /// @param Inten: the intensity type.
    ///  1. Defaults to be arithmetic, i.e. uniform intensity value. Can
    ///     use **convenient aliases** from the `stogeo::Intensity` class:
    ///     such as `stogeo::IntenVal_f`, `stogeo::IntenVal_d`.
    ///  2. Can also be functional. In this case, **wrap a functor or
    ///     lambda into functional version of `stogeo::Intensity` object.
    ///     Can use **convenient aliases** such as `stogeo::IntenFun_f`
    ///     or `stogeo::IntenVal_d`.
    ///
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    class MaternHardPP<T,Dim,Type,Inten,false>
      : public abstract::hardbase<MaternHardPP<T,Dim,Type,Inten,false> >
    {
      static_assert(Type==mtn_hc::TypeII || Type==mtn_hc::TypeIII,
                    "ERROR: HC TYPE II OR III EXPECTED.");
    public:
      EIGEN_MAKE_ALIGNED_OPERATOR_NEW

      using exact_t            = MaternHardPP<T,Dim,Type,Inten,false>;
      using specs_t            =               traits::specs<exact_t>;
      using scalr_t            =            typename specs_t::scalr_t;
      using inten_t            =            typename specs_t::inten_t;
      using point_t            =            typename specs_t::point_t;
      using vectr_t            =            typename specs_t::vectr_t;
      using matrx_t            =            typename specs_t::matrx_t;
      using slice_t            =            typename specs_t::slice_t;
      using field_t            =            typename specs_t::dymmt_t;
      using times_t            =            typename specs_t::times_t;
      using realz_t            =            typename specs_t::realz_t;
      using extra_t            =            typename specs_t::extra_t;

      using parnt_t            =           abstract::ppsbase<exact_t>;
      using super_t            =          abstract::hardbase<exact_t>;
      friend                                                  parnt_t;

      using parnt_t::                                            draw;
      using parnt_t::                                           print;
      using parnt_t::                                     reset_state;
      using super_t::                                         hc_dist;

      static constexpr int dim =                                  Dim;

      /// @brief Forwarding ctor.
      ///
      /// Forwards all arguments to matching ctor from `super_t`, i.e.
      /// `stogeo::pps::abstract::hardbase`.
      ///
      /// @param args: variadic arguments matching those of the ctors of
      /// `stogeo::pps::abstract::hardbase` class.
      ///
      /// @sa `stogeo::pps::abstract::hardbase`
      ///
      template<typename ...Args,
               enable_if_all_t<!is_base_of_v<exact_t,Args>()...>* = nullptr>
      MaternHardPP(Args &&...args):
        super_t( std::forward<Args>(args)... ) {};

    private:

      /// @brief Draw a realization of birthdays.
      ///
      /// @param n_elem: the number of elements in current draw of
      /// Poisson pp samples.
      ///
      void draw_birthdays(int n_elem) const;

      /// @brief Apply retaining rule of Type II.
      ///
      /// This function is of internal usage.
      ///
      /// @param tag: the type II tag.
      /// @param indx: index of current checking point.
      /// @param lv: a logical vector. Will be set to zero at `indx`, if
      /// that point is to be deleted.
      /// @parama mat: matrix containing all original Poisson pp points.
      ///
      template<typename Matrix,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void apply_rule(type_ii_t tag, int indx, slice_t &lv,
                      const Matrix &mat) const;

      /// @brief Apply retaining rule of Type III.
      ///
      /// This function is of internal usage.
      ///
      /// @param tag: the type III tag.
      /// @param indx: index of current checking point.
      /// @param lv: a logical vector. Will be set to zero at `indx`, if
      /// that point is to be deleted.
      /// @parama mat: matrix containing all original Poisson pp points.
      ///
      template<typename Matrix,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void apply_rule(type_iii_t tag, int indx, slice_t &lv,
                      const Matrix &mat) const;

      /// @brief Run a realization.
      ///
      /// @note This `impl` will be dispatched to the generic interface
      /// in the base class `stogeo::pps::abstract::ppsbase`.
      ///
      /// @param mat: the matrix where sample points will be stored.
      /// @param args: additional parameters, can be an observation or
      /// not depending on the intensity setting.
      ///
      /// @sa `stogeo::pps::abstract::ppsbase::draw()`.
      ///
      template<typename Matrix, typename ...Args,
               typename = enable_if_all_t<is_eigen_v<Matrix>(),
                                          eigen_rows_v<Matrix>()==dim> >
      void draw_impl(Matrix &mat, Args &&...args) const;

      /// @brief Run a realization with extra content
      ///
      /// Output a marked point pattern with additional birthday value.
      ///
      /// @param field: the marked point pattern where samples will be
      /// stored.
      /// @param tag: the `stogeo::extra` tag.
      /// @param args: additional parameters, can be an observation
      /// window or nothing, depending on the intensity setting.
      ///
      /// @sa `stogeo::pps::abstract::ppsbase::draw()`.
      ///
      template<typename ...Args>
      void draw_impl(extra_t &field, extra_tag_t tag, Args &&...args) const;

      /// @brief Internal method refactoring common part of draw_impl.
      ///
      /// @param mat: the matrix where sample points will be stored.
      /// @param args: additional parameters, can be an observation or
      /// not depending on the intensity setting.
      ///
      template<typename Matrix, typename ...Args>
      void __draw_common(Matrix &mat, Args &&...args) const;

      /// @brief Reset the internal state of the point process.
      ///
      /// Together with the `stogeo::utils::reset_shared_engine()`
      /// function, they can be used to reproduce the same simulation
      /// results.
      ///
      exact_t& reset_state_impl();

      using super_t::  _csr_smplr;
      using super_t::  _hdcr_sphr;

      mutable rnd::RUniform<T> _birth_var; //:< Generator for birthday marks.
      mutable times_t          _birthdays; //:< Cache the birthday marks.
    };

  }
}


# include "MaternHardPP.hxx"
#endif
