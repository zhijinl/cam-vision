// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// MaternHardPP.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 20 11:00:16 2016 Zhijin Li
// Last update Mon Sep 11 18:54:40 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {
    namespace abstract
    {

      // =====================================================================
      template<typename EXACT> template<typename IntenType, typename>
      hardbase<EXACT>::hardbase(scalr_t hdcr_dist, IntenType &&inten):
        _csr_smplr( std::forward<IntenType>(inten) ),
        _hdcr_sphr( shapes::Sphere<scalr_t,dim>(hdcr_dist) )
      {
        assert(hdcr_dist >= 0.0 && "hardcore distance cannot be negative.");
      }

      // =====================================================================
      template<typename EXACT>
      template<typename IntenType, typename Shape, typename>
      hardbase<EXACT>::hardbase(Shape &&shape,
                                scalr_t hdcr_dist,
                                IntenType &&inten_func):
        _csr_smplr( std::forward<Shape>(shape), inten_func ),
        _hdcr_sphr( shapes::Sphere<scalr_t,dim>(hdcr_dist) )
      {
        assert(hdcr_dist >= 0.0 && "hardcore distance cannot be negative.");
      }

      // =====================================================================
      template<typename EXACT>
      auto hardbase<EXACT>::reset_state_impl() -> exact_t&
      {
        _csr_smplr.reset_state();
        return (*this).exact();
      };

    }


    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename>
    void MaternHardPP<T,Dim,mtn_hc::TypeI,Inten>::
    apply_rule(int indx, slice_t &lv, const Matrix &mat) const
    {
      _hdcr_sphr.move_to(mat.col(indx));
      for(auto __c = 0; __c < mat.cols(); ++__c)
        if( __c != indx && _hdcr_sphr.inside_test(mat.col(__c)) )
        { lv(indx) = false; break; }
    }

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename ...Args, typename>
    void MaternHardPP<T,Dim,mtn_hc::TypeI,Inten>::
    draw_impl(Matrix &mat, Args &&...args) const
    {
      _csr_smplr.draw(mat, std::forward<Args>(args)...);

      slice_t __lv = slice_t::Ones(mat.cols());
      for(int __n = 0; __n < mat.cols(); ++__n) apply_rule(__n, __lv, mat);

      utils::logical_slice(mat, __lv);
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    draw_birthdays(int n_elem) const
    {
      _birthdays.resize(n_elem);
      _birth_var.draw(_birthdays);
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    template<typename Matrix, typename>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    apply_rule(type_ii_t, int indx, slice_t &lv, const Matrix &mat) const
    {
      _hdcr_sphr.move_to(mat.col(indx));
      for(auto __c = 0; __c < mat.cols(); ++__c)
        if( _hdcr_sphr.inside_test(mat.col(__c)) )
          if( _birthdays(__c) > _birthdays(indx) ) { lv(indx) = false; break; }
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    template<typename Matrix, typename>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    apply_rule(type_iii_t, int indx, slice_t &lv, const Matrix &mat) const
    {
      _hdcr_sphr.move_to(mat.col(indx));
      for(auto __c = 0; __c < mat.cols(); ++__c)
        if( lv(__c) && _hdcr_sphr.inside_test(mat.col(__c)) )
          if( _birthdays(__c) > _birthdays(indx) ) { lv(indx) = false; break; }
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    template<typename Matrix, typename ...Args, typename>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    draw_impl(Matrix &mat, Args &&...args) const
    {
      __draw_common(mat, std::forward<Args>(args)...);
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    template<typename ...Args>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    draw_impl(extra_t &field, extra_tag_t, Args &&...args) const
    {
      __draw_common(field.pts(), std::forward<Args>(args)...);
      field.marks() = _birthdays;
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    template<typename Matrix, typename ...Args>
    void MaternHardPP<T,Dim,Type,Inten,false>::
    __draw_common(Matrix &mat, Args &&...args) const
    {
      _csr_smplr.draw(mat, std::forward<Args>(args)...);
      draw_birthdays(mat.cols());

      slice_t __lv = slice_t::Ones(mat.cols());
      for(int __n = 0; __n < mat.cols(); ++__n)
        apply_rule(matern_type_t<Type>{}, __n, __lv, mat);

      utils::logical_slice(mat, __lv);
      utils::logical_slice(_birthdays, __lv);
    }

    // =====================================================================
    template<typename T, int Dim, mtn_hc Type, typename Inten>
    auto MaternHardPP<T,Dim,Type,Inten,false>::
    reset_state_impl() -> exact_t&
    {
      _csr_smplr.reset_state();
      _birth_var.reset_state();
      return *this;
    }

  }
}
