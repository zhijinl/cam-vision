// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// Hardcore.hxx for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Jul 06 10:22:07 2015 Zhijin Li
// Last update Mon Oct  9 11:41:21 2017 Zhijin Li
// ---------------------------------------------------------------------------


namespace stogeo
{
  namespace pps
  {

    // =====================================================================
    template<typename T, int Dim, typename Inten>
    template<typename Matrix, typename ...Args, typename>
    void HardcorePP<T,Dim,Inten>::draw_impl(Matrix &mat, Args &&...args) const
    {
      _csr_smplr.draw(mat, std::forward<Args>(args)...);
      slice_t __lv = slice_t::Ones(mat.cols());

      for(auto n = 0; n < mat.cols(); ++n)
        if(__lv(n))
        {
          _hdcr_sphr.move_to(mat.col(n));
          for(auto c = n + 1; c < mat.cols(); ++c)
            if( __lv(c) ) __lv(c) = !_hdcr_sphr.inside_test(mat.col(c));
        }
      utils::logical_slice(mat, __lv);
    }

  } //!pps
} //!stogeo
