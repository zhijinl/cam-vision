#!/bin/sh
## ---------------------------------------------------------------------------
## Copyright (c) 2011, 2012, 2013 by General Electric Medical Systems
##
## gen_sanity_rules.sh for har
## 
## Made by Giovanni Palma
## Mail:   <giovanni.palma@ge.com>
## 
## Started on  Wed Aug 24 16:30:31 2011 Giovanni Palma
## Last update Thu Mar 14 15:15:30 2013 Giovanni Palma
## ---------------------------------------------------------------------------
progs=""
tests=""

src_list=

for i in `\ls $1/*.cc *.cc | grep -v \~`
do
    src_list="$src_list `basename $i`"
done

for i in `echo $src_list | sed s/" "/'\n'/g | sort -u`
do
    p=`basename $i`
    t=`echo $p | sed s/\\\\.cc//g`
    progs="$progs $t"
    tests="$tests test_$t"
    echo `echo -n $t| sed s/"-"/_/g`"_SOURCES="$t.cc 
done


echo "check_PROGRAMS=$progs"
echo "TEST=$tests"
