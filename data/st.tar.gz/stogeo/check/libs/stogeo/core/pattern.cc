// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// pattern.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 12 18:48:15 2015 Zhijin Li
// Last update Fri Nov 18 15:20:34 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include <cstdio>
# include "stogeo/core.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/geometry.hh"


/// Functor for exclusion condition for shapes and GGMs.
class functor
{
public:
  double operator()(const Eigen::Matrix<double,3,1> &coord)
  {
    /// Points falling outside of a sphere w/ radius 20 are tagged true.
    return(double(coord(0)*coord(0)+coord(1)*coord(1)+coord(2)*coord(2))<20.0*20.0);
  }
};

int main()
{

  /// Convenient definitions & typedefs.
  constexpr std::size_t dim = 3;
  using dtype = double;
  using Point = Eigen::Matrix<dtype,dim,1>;

  const std::string file_thin = "__tmp.stogeo.unit.test.thin";
  const std::string file_init = "__tmp.stogeo.unit.test.init";

  /// Create a Poisson pp and roll a realization into a point pattern.
  dtype intensity = 1;
  dtype r_probability = 1e-3;
  Point obs_ctre;
  Point obs_size;
  for(std::size_t i = 0; i < dim; ++i) obs_ctre(i) = 0.0;
  for(std::size_t i = 0; i < dim; ++i) obs_size(i) = 51.2;

  stogeo::shapes::Box<dtype,dim> window(obs_ctre, obs_size);
  stogeo::pps::PoissonPP<dtype,dim> ppp(intensity);
  auto init = ppp.draw(window);


  /// Independent thinning on fld to produce germs.
  stogeo::SimplePointPattern<dtype,dim> germs(init);
  germs.thinning(r_probability);


  /// Create some random variables..
  stogeo::rnd::RUniform<dtype> rnd_radius(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_a(5.0,10.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_b(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_c(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_angle_a(0.0,3.14);
  stogeo::rnd::RUniform<dtype> rnd_angle_b(0.0,3.14);
  stogeo::rnd::RUniform<dtype> rnd_angle_c(0.0,3.14);


  /// Construct grains: ommitted centres default to the origin.
  stogeo::shapes::Sphere<dtype,dim> spher(rnd_radius);/// A spherical grain.
  stogeo::shapes::Ellipsoid<dtype,dim>
    ellip(obs_ctre,rnd_axis_a,rnd_axis_b,rnd_axis_c,
          rnd_angle_a,rnd_angle_b,rnd_angle_c); /// An ellipsoidal grain.


  /// Assemble germs and grain to produce the spherical germ-grain model.
  stogeo::MarkedPointPattern<stogeo::shapes::Sphere<dtype,dim> > spher_ggm(window,germs.n_elem());
  stogeo::MarkedPointPattern<stogeo::shapes::Ellipsoid<dtype,dim> > ellip_ggm(window,germs.n_elem());

  for(auto i = 0; i < germs.n_elem(); ++i)
  {
    spher_ggm.append(spher.draw(germs.pt(i)));
    ellip_ggm.append(ellip.draw(germs.pt(i)));
  }


    /// Constraint init by a ggm to obatin a modulated pp.
  init.restrict(ellip_ggm);


  /// Exclude can also be used w/ an external functor:
  init.constrain(functor());


  /// Write result ro a file.
  germs.write_to(file_thin);
  init.write_to(file_init);


  std::remove(file_thin.c_str());
  std::remove(file_init.c_str());


  return 0;
}
