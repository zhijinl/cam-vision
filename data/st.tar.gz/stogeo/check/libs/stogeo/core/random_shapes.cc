// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// random_shapes.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Sep  1 14:37:54 2015 Zhijin Li
// Last update Fri Nov 18 15:22:07 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include <chrono>
# include "stogeo/core.hh"
# include "stogeo/geometry.hh"


int main()
{
  constexpr int dim = 3;
  using dtype = float;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Define some random variables.
  stogeo::rnd::RUniform<dtype> sphere_radius(5.0, 10.0);
  stogeo::rnd::Gaussian<dtype> angle_a(0.0, 3.14);
  stogeo::rnd::Gaussian<dtype> angle_b(0.0, 3.14);
  stogeo::rnd::Gaussian<dtype> angle_c(0.0, 3.14);

  stogeo::rnd::RUniform<dtype> length_x(10.0, 15.0);
  stogeo::rnd::RUniform<dtype> length_y(5.0, 7.5);
  stogeo::rnd::RUniform<dtype> length_z(5.0, 7.5);


  /// Random shapes
  stogeo::shapes::Sphere<dtype,dim> sphere(sphere_radius);
  stogeo::shapes::Ellipsoid<dtype,dim> ellip(length_x, length_y, length_z,
                                             angle_a, angle_b, angle_c);
  stogeo::shapes::Rectangle<dtype,dim> rect(length_x, length_y, length_z,
                                            angle_a, angle_b, angle_c);


  /// Roll & draw.
  Point origin{0.0, 0.0, 0.0};
  for(auto k = 0; k < 1e5; ++k)
  {
    sphere.roll();
    ellip.roll();
    rect.roll();

    if( sphere.volume() < 4.0/3*stogeo::stg_pi*5*5*5-0.1 ||
        sphere.volume() > 4.0/3*stogeo::stg_pi*10*10*10+0.1 )
    {
      std::cerr << "sphere volume went wrong.\n";
      return 1;
    }
    if( ellip.volume() < 4.0/3*stogeo::stg_pi*5*5*5-0.1 ||
        ellip.volume() > 4.0/3*stogeo::stg_pi*15*15*15+0.1 )
    {
      std::cerr << "ellip volume went wrong.\n";
      return 1;
    }
    if( rect.volume() < 5*5*10-0.1 ||
        rect.volume() > 7.5*7.5*15+0.1 )
    {
      std::cerr << "rect volume went wrong.\n";
      return 1;
    }

    auto vec_1 = sphere.draw(origin);
    auto vec_2 = ellip.draw(origin);
    auto vec_3 = rect.draw(origin);

    if( vec_1.segment(dim,1).prod() < 0 )
    {
      std::cerr << "sphere draw went wrong ().\n";
      return 1;
    }
    if( vec_2.segment(dim,dim).prod() < 0 )
    {
      std::cerr << "ellip draw went wrong ().\n";
      return 1;
    }
    if( vec_3.segment(dim,dim).prod() < 0 )
    {
      std::cerr << "rect draw went wrong ().\n";
      return 1;
    }

  }


  /// Test for dflt shape constructions.
  stogeo::shapes::Box<dtype,dim> box_df;
  stogeo::shapes::Sphere<dtype,dim> sphere_df;
  stogeo::shapes::Ellipsoid<dtype,dim> ellip_df;
  stogeo::shapes::Rectangle<dtype,dim> rect_df;


  /// Roll & draw.
  for(auto k = 0; k < 1e5; ++k)
  {
    box_df.roll();
    sphere_df.roll();
    ellip_df.roll();
    rect_df.roll();

    if(box_df.centre() != Point::Zero() ||
       sphere_df.centre() != Point::Zero() ||
       ellip_df.centre() != Point::Zero() ||
       rect_df.centre() != Point::Zero() )
    {
      std::cerr << "default origin not zero.\n";
      return 1;
    }

    if(box_df.param() != Point::Ones() ||
       !stogeo::utils::f_equal(sphere_df.param(),dtype(1))  ||
       ellip_df.param().segment(0,dim) != Point::Ones() ||
       rect_df.param().segment(0,dim) != Point::Ones() )
    {
      std::cerr << "default not unit-length.\n";
      return 1;
    }

    if(ellip_df.param().segment(dim,dim) != Point::Zero() ||
       rect_df.param().segment(dim,dim) != Point::Zero() )
    {
      std::cerr << "default angles not zero.\n";
      return 1;
    }

    if(!stogeo::utils::f_equal(box_df.volume(), dtype(1)) ||
       !stogeo::utils::f_equal(sphere_df.volume(), dtype(4.0/3*stogeo::stg_pi)) ||
       !stogeo::utils::f_equal(ellip_df.volume(), dtype(4.0/3*stogeo::stg_pi)) ||
       !stogeo::utils::f_equal(rect_df.volume(), dtype(1)) )
    {
      std::cerr << "default origin not zero.\n";
      std::cout << box_df.volume() << ' '
                << sphere_df.volume() << ' '
                << ellip_df.volume() << ' '
                << rect_df.volume() << std::endl;
      return 1;
    }

    auto vec_1_df = sphere_df.draw(origin);
    auto vec_2_df = ellip_df.draw(origin);
    auto vec_3_df = rect_df.draw(origin);

    if( !stogeo::utils::f_equal(vec_1_df.segment(dim,1).prod(),dtype(1)) )
    {
      std::cerr << "sphere draw went wrong ().\n";
      return 1;
    }
    if( !stogeo::utils::f_equal(vec_2_df.segment(dim,dim).prod(),dtype(1)) )
    {
      std::cerr << "ellip draw went wrong ().\n";
      return 1;
    }
    if( !stogeo::utils::f_equal(vec_3_df.segment(dim,dim).prod(),dtype(1)) )
    {
      std::cerr << "rect draw went wrong ().\n";
      return 1;
    }

  }


  return 0;
}
