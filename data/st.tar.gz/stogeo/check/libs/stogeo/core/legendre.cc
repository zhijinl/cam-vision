// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// legendre.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri Feb 26 00:15:00 2016 Zhijin Li
// Last update Fri Nov 18 15:19:39 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/discrete.hh"
# include "mipp/io/io_raw.hh"


int main()
{
  using vtype = short;
  using dtype = double;
  constexpr int dim = 3;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Define ellipsoid geometric setting.
  Point ell_ctre;
  Point win_ctre;
  Point resolution{0.2, 0.2, 0.2};
  for(std::size_t i = 0; i < dim; ++i) ell_ctre(i) = 12.8;
  for(std::size_t i = 0; i < dim; ++i) win_ctre(i) = 25.6;
  stogeo::shapes::Box<dtype,dim> window(ell_ctre,win_ctre);


  /// Some random parameters.
  stogeo::rnd::RUniform<dtype> axis_rv(5.0, 10.0);
  stogeo::rnd::RUniform<dtype> angle_rv(1.0, 6.0);
  dtype axis_a = axis_rv.draw();
  dtype axis_b = axis_rv.draw();
  dtype axis_c = axis_rv.draw();

  for(int test = 0; test < 10; ++test)
  {
    dtype angle_a = angle_rv.draw(); // Fit val angle_a is rn if symmmetry: does not matter.
    dtype angle_b = angle_rv.draw();
    dtype angle_c = angle_rv.draw();


    /// Original ellipsoid.
    stogeo::shapes::Ellipsoid<dtype,dim> orig_ell(ell_ctre,axis_a,axis_b,axis_c,
                                                  angle_a,angle_b,angle_c);
    auto domain = stogeo::utils::make_cmn_domain(window, resolution);
    auto orig_ellip = orig_ell.discrete(domain,vtype(0),vtype(1));


    /// Fitted ellipsoid.
    auto estm_ell = stogeo::discrete::comp_legendre_ellipsoid<dtype>
      (orig_ellip, orig_ell,
       [&orig_ellip] (const cmn::Point3D &pt) { return !orig_ellip[pt]; });
    auto estm_ellip = estm_ell.discrete(domain,vtype(0),vtype(1));


    /// Test approximation accuracy.
    auto err = stogeo::discrete::cmn_count_if
      (orig_ellip, [&orig_ellip, &estm_ellip] (const cmn::Point3D &pt)
       {
         return orig_ellip[pt] != estm_ellip[pt];
       });
    auto total = stogeo::discrete::cmn_count_if
      (orig_ellip, [&orig_ellip] (const cmn::Point3D &pt)
       {
         return !orig_ellip[pt];
       });

    if( static_cast<float>(err)/total >= 0.1 )
    {
      std::cerr << "orig ellip & estm ellip mismatch.\n";
      return 1;
    }
  }
  return 0;
}
