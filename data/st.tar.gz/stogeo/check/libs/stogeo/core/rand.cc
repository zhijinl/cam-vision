// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// rand.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Sep  1 14:37:54 2015 Zhijin Li
// Last update Sat Sep 16 18:17:02 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include <chrono>
# include <algorithm>
# include "stogeo/core.hh"
# include "stogeo/statistics.hh"


template<typename T> using Vector = Eigen::Matrix<T,Eigen::Dynamic,1>;

int main()
{
  using dtype = double;
  dtype threshold = 0.3;


  /// Define r.vs.
  stogeo::rnd::Bernoulli       bg(0.3);
  stogeo::rnd::Poisson<int>    pg(1.3);
  stogeo::rnd::Gaussian<dtype> gg(0.0, 1.0);
  stogeo::rnd::RUniform<dtype>    ug(0.0, 1.0);

  int n_samples = 1000;
  Vector<dtype> gauss_samples(n_samples);
  Vector<bool>  berno_samples(n_samples);
  Vector<int>   poiss_samples(n_samples);
  Vector<dtype> runif_samples(n_samples);


  /// Reset global seed & start sampling.
  stogeo::utils::reset_shared_engine(42);
  gg.draw(gauss_samples);
  bg.draw(berno_samples);
  pg.draw(poiss_samples);
  ug.draw(runif_samples);


  /// Precision test: Bernoulli.
  dtype mean_bg = berno_samples.template cast<dtype>().sum()
    /berno_samples.size();
  if( std::fabs(mean_bg-0.3) > threshold )
  {
    std::cerr << "Bernoulli sampling went wrong: precision test failed.\n";
    return 1;
  }


  /// Precision test: Poisson.
  dtype mean_pg = poiss_samples.template cast<dtype>().mean();
  dtype var_pg = stogeo::stats::var<dtype>(poiss_samples.template cast<dtype>());
  if( std::fabs(mean_pg-1.3) > threshold ||
      std::fabs(var_pg-1.3) > threshold )
  {
    std::cerr << "Poisson sampling went wrong: precision test failed.\n";
    return 1;
  }


  /// Precision test: Gaussian.
  dtype mean_gg = gauss_samples.mean();
  dtype var_gg = stogeo::stats::var<dtype>(gauss_samples);
  if( std::fabs(mean_gg) > threshold ||
      std::fabs(var_gg-1.0) > threshold )
  {
    std::cerr << "Gaussian sampling went wrong: precision test failed.\n";
    return 1;
  }


  /// Precision test: Real Uniform.
  dtype mean_ug = runif_samples.mean();
  dtype var_ug = stogeo::stats::var<dtype>(runif_samples);
  if( std::fabs(mean_ug-0.5) > threshold ||
      std::fabs(var_ug-1.0/12) > threshold )
  {
    std::cerr << "Real Uniform sampling went wrong: precision test failed.\n";
    return 1;
  }


  /// Duplicates test: Gaussian.
  if( std::unique(gauss_samples.data(),
                  gauss_samples.data()+gauss_samples.size()) !=
      gauss_samples.data()+gauss_samples.size() )
  {
    std::cerr << "Gaussian sampling went wrong: duplicates test failed.\n";
    return 1;
  }


  /// Duplicates test: Real Uniform.
  if( std::unique(runif_samples.data(),
                  runif_samples.data()+runif_samples.size()) !=
      runif_samples.data()+runif_samples.size() )
  {
    std::cerr << "Real Uniform sampling went wrong: duplicates test failed.\n";
    return 1;
  }


  /// Test random engine reset.
  stogeo::utils::reset_shared_engine(42);
  gg.reset_state();

  Vector<dtype> gauss_samples2(n_samples);
  gg.draw(gauss_samples2);

  for(int i = 0; i < n_samples; ++i)
  {
    if( gauss_samples(i) != gauss_samples2(i) )
    {
      std::cerr << "Random engine reset went wrong. Values mismatch.\n";
      return 1;
    }
  }

  return 0;
}
