// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// dired_io.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Mar  3 16:28:54 2016 Zhijin Li
// Last update Fri Apr  7 17:40:46 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include <cstdio>
# include "stogeo/core.hh"
# include "stogeo/utilities.hh"


template<typename Scalar>
void print_arr(const std::unique_ptr<Scalar[]> &arr, int size)
{
  std::copy(arr.get(), arr.get()+size,
            std::ostream_iterator<Scalar>{std::cout, " "});
  std::cout << '\n';
}

int main()
{
  /// Definitions.
  using vtype = float;

  const std::string dir_name = "./";
  const std::string name_base = "__data.stogeo.unit.test.slice";
  const std::string hint = "__data.stogeo.unit.test";

  int n_files = 10;
  int arr_size = 25;
  int skip = 7*sizeof(vtype);


  /// Synthetic data.
  std::vector<vtype> data_vec(n_files*arr_size);
  std::iota(std::begin(data_vec), std::end(data_vec), 0.0f);

  for(int n = 0; n < n_files; ++n)
  {
    auto curr_name = name_base+"."+std::to_string(n);
    stogeo::io::write_arr_to_rawfile(data_vec.data()+n*arr_size,
                                     arr_size, curr_name);
  }


  /// Read hinted dir files.
  auto no_skip = stogeo::io::read_raw_dired_to_arr<vtype>(dir_name, hint);
  auto skipped = stogeo::io::read_raw_dired_to_arr<vtype>(dir_name, hint, skip);

  print_arr(std::get<2>(no_skip), std::get<0>(no_skip)*std::get<1>(no_skip));
  print_arr(std::get<2>(skipped), std::get<0>(skipped)*std::get<1>(skipped));


  /// Check for correct size.
  if( std::get<0>(no_skip) != n_files ||
      std::get<0>(skipped) != n_files )
  {
    std::cerr << "number of files went wrong.\n";
    return 1;
  }


  /// Check for correct skip.
  if( std::get<1>(no_skip) - std::get<1>(skipped) != 7)
  {
    std::cerr << "file size went wrong.\n";
    return 1;
  }


  /// Check for correct no skip val.
  for(int n = 0; n < std::get<0>(no_skip)*std::get<1>(no_skip); ++n)
  {
    if( !stogeo::utils::f_equal(std::get<2>(no_skip)[n], vtype(n)) )
    {
      std::cerr << "no_skip: multiple files reading went wrong.\n"
                << std::get<2>(no_skip)[n] << " vs " << vtype(n) << '\n';
      return 1;
    }
  }


  /// Check for correct skipped val.
  for(int n = 0; n < std::get<0>(skipped)*std::get<1>(skipped); ++n)
  {
    int period = arr_size-skip/sizeof(vtype);
    vtype val = (n/period)*arr_size + n%period + skip/sizeof(vtype);
    if( !stogeo::utils::f_equal(std::get<2>(skipped)[n], val) )
    {
      std::cerr << "skipped: multiple files reading went wrong.\n"
                << std::get<2>(skipped)[n] << " vs " << val << '\n';
      return 1;
    }
  }


  /// Remove files.
  for(int n = 0; n < n_files; ++n)
  {
    auto curr_name = name_base+"."+std::to_string(n);
    remove(curr_name.c_str());
  }


  return 0;
}
