// ---------------------------------------------------------------------------
// Copyright (c) 2017 by General Electric Medical Systems
//
// reset_state.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Sep 11 10:30:41 2017 Zhijin Li
// Last update Sat Sep 16 18:34:59 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "stogeo/geometry.hh"
# include "stogeo/utilities.hh"
# include "stogeo/statistics.hh"
# include "stogeo/point_processes.hh"


struct TargetDistr
{
  template<typename Value> Value operator()(Value val) const
  {
    return std::exp(-0.5*(val-5)*(val-5)/100) +
      2*std::exp(-0.5*(val-50)*(val-50)/100);
  }
};

int main()
{

  using dtype = float;

  /// Test rest_state for distributions.
  stogeo::rnd::Gaussian<float>  grv(1.0, 3.0);
  stogeo::rnd::Bernoulli brv(0.7);
  stogeo::rnd::Poisson<int>   prv(42.0);
  stogeo::rnd::RUniform<float>  urv(2.0, 7.0);

  stogeo::utils::reset_shared_engine(42);

  auto grv_val = grv.draw();
  auto brv_val = brv.draw();
  auto prv_val = prv.draw();
  auto urv_val = urv.draw();

  for( int n = 0; n < 100; ++n )
  {
    stogeo::utils::reset_shared_engine(42);
    grv.reset_state();
    brv.reset_state();
    prv.reset_state();
    urv.reset_state();

    auto new_grv_val = grv.draw();
    auto new_brv_val = brv.draw();
    auto new_prv_val = prv.draw();
    auto new_urv_val = urv.draw();

    if( grv_val != new_grv_val ||
        brv_val != new_brv_val ||
        prv_val != new_prv_val ||
        urv_val != new_urv_val )
    {
      std::cerr << "distribution reset_state failed.\n"
                << "EXPECT: "
                << grv_val << ' '
                << grv_val << ' '
                << grv_val << ' '
                << grv_val << "\n"
                << "GOT: "
                << new_grv_val << ' '
                << new_grv_val << ' '
                << new_grv_val << ' '
                << new_grv_val << "\n";
      return 1;
    }
  }

  /// Check reset_state for Metroplis-Hasting Monte Carlo sampler.
  stogeo::utils::reset_shared_engine(76);

  auto target_distr = TargetDistr{};
  auto propos_distr = stogeo::rnd::Gaussian<dtype>{0,10};

  int n_samples = 5e3;
  Eigen::Matrix<dtype,-1,1> vec(n_samples);
  stogeo::stats::MHSampler<dtype,1,TargetDistr>
    mh_sampler(target_distr, propos_distr);

  mh_sampler.draw(vec, propos_distr.draw());

  stogeo::utils::reset_shared_engine(76);
  mh_sampler.reset_state();
  propos_distr.reset_state();

  Eigen::Matrix<dtype,-1,1> vec2(n_samples);
  mh_sampler.draw(vec2, propos_distr.draw());

  for(int n = 0; n < n_samples; ++n)
  {
    if( vec(n) != vec2(n) )
    {
      std::cerr << "MH sampler sample value mismatch.\n"
                << "EXPECT: " << vec(n) << " | GOT: "
                << vec2(n) << '\n';
      return 1;
    }
  }

  return 0;
}
