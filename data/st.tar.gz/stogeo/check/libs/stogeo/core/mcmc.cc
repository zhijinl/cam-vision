// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// mcmc.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Fri Aug 26 18:00:59 2016 Zhijin Li
// Last update Fri Nov 18 15:20:21 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/random.hh"
# include "stogeo/statistics.hh"


struct TargetDistr
{
  template<typename Value> Value operator()(Value val) const
  {
    return std::exp(-0.5*(val-5)*(val-5)/100) + 2*std::exp(-0.5*(val-50)*(val-50)/100);
  }
};


int main()
{

  /// Definitions.
  using dtype = double;
  using distr = TargetDistr;
  using propo = stogeo::rnd::Gaussian<dtype>;

  distr target_distr = distr{};
  propo propos_distr = propo{0,10};

  stogeo::stats::MHSampler<dtype,1,distr> mh_sampler(target_distr, propos_distr);


  int n_samples = 5e3;
  Eigen::Matrix<dtype,-1,1> vec(n_samples);


  /// Run Metropolis-Hasting Markov chain Monte Carlo.
  mh_sampler.draw(vec, propos_distr.draw());


  /// Test for MSE: sample pdf vs analytical pdf.
  stogeo::stats::GaussianKS<dtype,1> ks_estimator;
  auto emp_pdf = ks_estimator.estimate(stogeo::pdf, vec);

  dtype mse = 0.0;
  dtype constant = 75.1;
  for(auto n = 0; n < emp_pdf.n_elem(); ++n)
  {
    auto err = target_distr(emp_pdf.point_at(n))/constant
      - emp_pdf.value_at(n);
    mse += err*err;
  }
  mse /= emp_pdf.n_elem();

  if( mse > 1e-4 || vec.mean() > 45 || vec.mean() < 25)
  {
    std::cerr << "MH-MCMC went wrong.\n";
    return 1;
  }


  return 0;
}
