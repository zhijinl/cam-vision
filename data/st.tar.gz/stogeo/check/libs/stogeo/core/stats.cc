// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// stats.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Feb 21 02:00:21 2016 Zhijin Li
// Last update Fri Nov 18 15:21:29 2016 Zhijin Li
// ---------------------------------------------------------------------------

# include "stogeo/core.hh"
# include "stogeo/statistics.hh"
# include "common/Signal.hh"


int main()
{

  /// Defs.
  using dtype = float;
  constexpr int size = 100000;
  using Vec = Eigen::Matrix<dtype,Eigen::Dynamic,1>;


  /// Create Eigen & STL vectors.
  stogeo::rnd::Gaussian<dtype> grv(1.0, 2.0);
  stogeo::rnd::Gaussian<dtype> grv2(2.0, 5.0);

  Vec vec_eigen(size);
  Eigen::Matrix<dtype,2,-1> mat_eigen(2,size);
  std::vector<dtype> vec_stl(size);

  for(auto &i:vec_stl) i = grv.draw();
  for(int i = 0; i < size; ++i) vec_eigen(i) = vec_stl[i];
  for(int i = 0; i < size; ++i)
  {
    mat_eigen(0,i) = grv.draw();
    mat_eigen(1,i) = grv2.draw();
  }

  for(auto i = 0; i < vec_eigen.size(); ++i)
  {
    if( !stogeo::utils::f_equal(vec_stl[i],vec_eigen(i)) )
    {
      std::cerr << "vector value equality failed." << std::endl;
      return 1;
    }
  }


  /// Check mean & var computation.
  if( std::fabs(vec_eigen.mean()-stogeo::stats::mean<dtype>(vec_stl)) ||
      std::fabs(stogeo::stats::mean<dtype>(vec_stl) - 1.0) > 0.1)
  {
    std::cerr << "STL mean and Eigen mean mismatch.\n";
    return 1;
  }

  if( std::fabs(stogeo::stats::var<dtype>(vec_eigen)-
                stogeo::stats::var<dtype>(vec_stl)) > 0.1)
  {
    std::cerr << "STL var and Eigen var mismatch.\n";
    return 1;
  }


  /// Check mean & covariance computation. For matrix.
  Eigen::Matrix<dtype,2,1> truth_mean{1.0, 2.0};
  Eigen::Matrix<dtype,2,2> truth_cov;
  truth_cov << 4.0, 0.0,
    0.0, 25.0;

  if( (truth_mean-stogeo::stats::mean<dtype>(mat_eigen)).norm() > 0.1)
  {
    std::cerr << "Eigen matrix mean went wrong.\n";
    return 1;
  }

  if( (truth_cov-stogeo::stats::var<dtype>(mat_eigen)).squaredNorm() > 0.5)
  {
    std::cerr << "Eigen covariance matrix went wrong.\n";
    return 1;
  }


  /// Convert an Eigen vec to mipp::Signal.
  auto signal = stogeo::utils::vec2signal(vec_eigen);
  for(auto i = 0; i < vec_eigen.size(); ++i)
  {
    if( !stogeo::utils::f_equal(signal[i],vec_eigen(i)) )

    {
      std::cerr << "signal/vector value equality failed.\n";
      return 1;
    }
  }


  /// Convert back.
  auto vec_res = stogeo::utils::signal2vec(signal);
  for( auto n = 0; n < vec_res.size(); ++n)
  {
    if( !stogeo::utils::f_equal(vec_res(n), signal(n)) )
    {
      std::cerr << "signal/vector value equality failed.\n";
      return 1;
    }
  }


  /// Compute histogram of an Eigen vec.
  using hist_t = typename mipp::Histogram<dtype>;
  int bord_ext = 0;
  float bin_width = 0.01;
  auto hist_eigen = stogeo::stats::comp_histogram(vec_eigen,bin_width,bord_ext);

  /// Compute histogram of an mipp::Signal.
  mipp::Histogram<dtype> hist_mipp(cmn_domain_type(hist_t)
                                   (bin_width, vec_eigen.minCoeff(),
                                    vec_eigen.maxCoeff(), bord_ext), signal);

  /// Equality check.
  cmn_iter_type(hist_t) it_hist(hist_mipp.domain());
  cmn_for_all(it_hist)
  {
    if( hist_eigen[it_hist] != hist_mipp[it_hist] )
    {
      std::cerr << "histogram value equality failed.\n";
      return 1;
    }
  }


  /// Compyte Kernel smoothing density of Gaussian samples.
  dtype stdev = 10;
  int n_samples = 100000;

  Vec gauss_vec(n_samples);
  stogeo::rnd::Gaussian<dtype> gauss_rv(0,stdev);
  gauss_rv.draw(gauss_vec);


  auto support = stogeo::utils::make_support<dtype>(gauss_vec, 100, 1.2);

  stogeo::stats::GaussianKS<dtype,1> gauss_ks;
  auto ks_den = gauss_ks.estimate(stogeo::pdf,gauss_vec,support);

  dtype mse = 0.0;
  for(auto n = 0; n < ks_den.n_elem(); ++n)
  {
    auto err = gauss_rv(ks_den.point_at(n)) - ks_den.value_at(n);
    mse += err*err;
  }
  mse /= ks_den.n_elem();


  if( mse > 1e-4 )
  {
    std::cerr << "ks_density failed precision test.\n";
    return 1;
  }


  return 0;
}
