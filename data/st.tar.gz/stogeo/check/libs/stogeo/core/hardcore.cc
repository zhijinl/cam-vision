// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Healthcare
//
// hardcore.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on   Tue Aug 11 15:42:18 CEST 2015 Zhijin Li
// Last update Fri Nov 18 15:19:17 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/geometry.hh"
# include "stogeo/point_processes.hh"


int main()
{
  /// typedefs and stuff.
  constexpr std::size_t dim = 3;
  using dtype = double;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Params.
  Point obs_ctre;
  Point obs_size;
  dtype intensity = 1;
  dtype hc_dist = 3.0;
  for(std::size_t i = 0; i < dim; ++i) obs_ctre(i) = 0.0;
  for(std::size_t i = 0; i < dim; ++i) obs_size(i) = 51.2;

  stogeo::shapes::Box<dtype,dim> window(obs_ctre,obs_size);


  /// Create a Hardcore point process with hardcore distance hc_dist.
  stogeo::pps::HardcorePP<dtype,dim> hcp(hc_dist, intensity);
  auto fld = hcp.draw(window);


  /// Check hardcore constraint.
  stogeo::shapes::Sphere<dtype,dim> sphere(hc_dist);
  for(auto i = 0; i < fld.n_elem(); ++i)
    if( sphere.move_to(fld.pt(i)).inside_test(fld.pts()).count() > 1 )
    {
      std::cerr << "hardcore constaint failed.\n";
      return 1;
    }


  return 0;

}
