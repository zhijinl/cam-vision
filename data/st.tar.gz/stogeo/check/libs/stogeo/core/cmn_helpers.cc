// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// cmn_helpers.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 12 18:48:15 2015 Zhijin Li
// Last update Thu Dec 14 19:11:10 2017 Zhijin Li
// ---------------------------------------------------------------------------

# include "stogeo/core.hh"
# include "stogeo/utilities.hh"


using namespace std;

int main()
{

  /// Definitions.
  using dtype  = double;
  constexpr int dim = 2;
  using Point  = Eigen::Matrix<dtype,dim,1>;
  using IntPt  = Eigen::Matrix<int,dim,1>;
  using IntVec = Eigen::Matrix<int,Eigen::Dynamic,1>;
  using Mat    = Eigen::Matrix<dtype, dim, Eigen::Dynamic>;

  /// Three ways to create identical domains.
  Point  origin_a  {0.0, 0.0};
  Point  spacing_a {0.1, 0.1};
  Point  sizes_a   {1.0, 1.0};
  IntPt  sizes_b   {11, 11};

  Point  origin_d  {0.05, 0.05};
  Point  origin_e  {0.15, 0.15};
  Point  sizes_d   {0.9, 0.9};

  auto domain_a = stogeo::utils::make_cmn_domain(origin_a, spacing_a, sizes_a);
  auto domain_b = stogeo::utils::make_cmn_domain(origin_a, spacing_a, sizes_b);
  auto domain_c = stogeo::utils::make_cmn_domain(origin_a, spacing_a, 0, 11, 11);


  /// Create a slightly shift domain -> then align it with domain a
  auto __pair =
    stogeo::utils::make_aligned_domain(domain_a, origin_d, spacing_a, sizes_d);
  auto domain_d = std::get<1>(__pair);


  /// Check alignment
  auto __pair2 =
    stogeo::utils::make_aligned_domain(domain_a, origin_e, spacing_a, sizes_d);
  auto shift = std::get<0>(__pair2);
  if( shift != cmn::DPoint2D(1,1) )
  {
    std::cerr << "domain alignment produced wrong shift.\n";
    return 1;
  }


  /// Check for domain sizes, origins and spacings.
  if( domain_a != domain_b ||
      domain_a != domain_c ||
      domain_a != domain_d )
  {
    std::cerr << "domain sizes mismatch.\n";
    return 1;
  }

  if( domain_a.sp() != domain_b.sp() ||
      domain_a.sp() != domain_c.sp() ||
      domain_a.sp() != domain_d.sp() )
  {
    std::cerr << "domain spacings mismatch.\n";
    return 1;

  }

  for(int i = 0; i < dim; ++i)
  {
    if( domain_a.origin(i) != domain_b.origin(i) ||
        domain_a.origin(i) != domain_c.origin(i) ||
        domain_a.origin(i) != domain_d.origin(i) ||
        domain_a.originLU(i) != domain_b.originLU(i) ||
        domain_a.originLU(i) != domain_c.originLU(i) ||
        domain_a.originLU(i) != domain_d.originLU(i) )
    {
      std::cerr << "domain origins mismatch.\n";
      return 1;
    }
  }


  /// Test for forward iterator, position, index conversion.
  IntVec vec(11*11);
  Mat mat(dim, 11*11);
  stogeo::cmn_fwditr_t<dim> it(domain_a);

  int count = 0;
  cmn_for_all(it)
  {
    vec(stogeo::utils::cmn_itr_ind(it)) = count;
    mat.col(count) = stogeo::utils::cmn_itr_pos<dtype>(it);

    /// Test index to cmn point conversion.
    auto pos = stogeo::utils::cmn_ind_pos(count, it.domain());
    if( pos != it.point() )
    {
      std::cerr << "indx to point conversion went wrong\n";
      std::clog << "INDEX: " << count << '\n'
                << "CONVERTED POINT: " << pos << '\n'
                << "POINT: " << it.point() << "\n\n";
      return 1;
    }

    ++count;
  }

  for(int i = 0; i < 11*11; ++i)
  {
    if( vec(i) != i)
    {
      std::cerr << "iterator ind went wrong.\n";
      return 1;
    }

    if( std::fabs((mat.col(i) - Point{(i%11)*spacing_a(0),
              (i/11)*spacing_a(1)}).sum())
        > 0.1 )
    {
      std::cerr << "iterator pos went wrong.\n";
      return 1;
    }
  }


  /// Check shift computation.
  constexpr int shift_dim = 3;
  using point_t = Eigen::Matrix<dtype,shift_dim,1>;
  dtype org = 0.0;
  dtype sze = 6.4;
  dtype spc = 0.1;

  point_t shift_origin {org, org, org};
  point_t shift_sizes  {sze, sze, sze};
  point_t shift_spacing{spc, spc, spc};

  auto shift_domain =
    stogeo::utils::make_cmn_domain(shift_origin, shift_spacing, shift_sizes);
  stogeo::rnd::RUniform<dtype> urg(org, sze);

  point_t target{urg.draw(), urg.draw(), urg.draw()};
  stogeo::cmn_fwditr_t<shift_dim> shift_it(shift_domain);

  std::cout << "TARGET: " << target.transpose() << '\n';

  cmn_for_all(shift_it)
  {
    auto shift =
      stogeo::utils::comp_pos_shift<dtype>
      (target, shift_domain, shift_it.point());

    point_t truth{ shift_it.point()[0]*shift_domain.sp()[0] +
        shift_domain.originLU(0) - target(0),
        shift_it.point()[1]*shift_domain.sp()[1] +
        shift_domain.originLU(1) - target(1),
        shift_it.point()[2]*shift_domain.sp()[2] +
        shift_domain.originLU(2) - target(2) };

    if( !stogeo::utils::f_equal((shift - truth).norm(), 0.0) )
    {
      std::cerr << "computation of point shift went wrong\n";
      std::clog << "SHIFT: " << shift.transpose() << '\n'
                << "TRUTH: " << truth.transpose() << "\n\n";
      return 1;
    }
  }


  return 0;
}
