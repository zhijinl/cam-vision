// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// inside.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 12 18:48:15 2015 Zhijin Li
// Last update Fri Nov 18 15:19:23 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/geometry.hh"


int main()
{
  /// Definitions.
  constexpr int dim = 3;
  using dtype = float;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Create a box.
  Point box_center{0.25, 0.25, 0.75};
  Point box_lengths{0.5, 0.5, 0.5};
  stogeo::shapes::Box<dtype,dim> box(box_center, box_lengths);

  Point box_test_1{0.25, 0.25, 0.49}; // Not inside.
  Point box_test_2{0.49, 0.49, 0.51}; // Inside.


  /// Check box inside test.
  if( box.inside_test(box_test_1) )
  {
    std::cerr << "inside test 1 went wrong for box.\n";
    return 1;
  }

  if( !box.inside_test(box_test_2) )
  {
    std::cerr << "inside test 2 went wrong for box.\n";
    return 1;
  }


  /// Create a sphere
  Point sphere_center{0.75, 0.25, 0.25};
  stogeo::shapes::Sphere<dtype,dim> sphere(sphere_center, 0.3);

  Point sphere_test_1{0.75, 0.45, 0.50}; // Not inside.
  Point sphere_test_2{0.75, 0.45, 0.05}; // Inside.


  /// Check sphere inside test.
  if( sphere.inside_test(sphere_test_1) )
  {
    std::cerr << "inside test 1 went wrong for sphere.\n";
    return 1;
  }

  if( !sphere.inside_test(sphere_test_2) )
  {
    std::cerr << "inside test 2 went wrong for sphere.\n";
    return 1;
  }


  /// Create an ellipsoid.
  Point ellip_center{0.25, 0.75, 0.25};
  stogeo::shapes::Ellipsoid<dtype,dim> ellip(ellip_center,
                                            0.25,0.125,0.125,
                                            0.0,0.0,0.0);
  Point ellip_test_1{0.25, 0.75, 0.38}; // Not inside.
  Point ellip_test_2{0.25, 0.75, 0.36}; // Inside.


  /// Check ellipsoid inside test.
  if( ellip.inside_test(ellip_test_1) )
  {
    std::cerr << "inside test 1 went wrong for ellipsoid.\n";
    return 1;
  }

  if( !ellip.inside_test(ellip_test_2) )
  {
    std::cerr << "inside test 2 went wrong for ellipsoid.\n";
    return 1;
  }


  /// Create a rectangle.
  Point rect_center{0.75, 0.75, 0.75};
  stogeo::shapes::Rectangle<dtype,dim> rect(rect_center,
                                            0.5,0.05,0.05,
                                            0.0,0.0,stogeo::stg_pi*45.0/180);
  Point rect_test_1{0.786, 0.75, 0.75}; // Not inside.
  Point rect_test_2{0.785, 0.75, 0.75}; // Inside.
  Point rect_test_3{0.75, 0.786, 0.75}; // Not inside.
  Point rect_test_4{0.75, 0.785, 0.75}; // Inside.


  /// Check rectangle inside test.
  if( rect.inside_test(rect_test_1) )
  {
    std::cerr << "inside test 1 went wrong for rectangle.\n";
    return 1;
  }

  if( !rect.inside_test(rect_test_2) )
  {
    std::cerr << "inside test 2 went wrong for rectangle.\n";
    return 1;
  }

  if( rect.inside_test(rect_test_3) )
  {
    std::cerr << "inside test 3 went wrong for rectangle.\n";
    return 1;
  }

  if( !rect.inside_test(rect_test_4) )
  {
    std::cerr << "inside test 4 went wrong for rectangle.\n";
    return 1;
  }


  return 0;
}
