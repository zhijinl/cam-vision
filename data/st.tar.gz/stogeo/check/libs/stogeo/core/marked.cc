// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// marked.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Aug  1 09:01:13 2016 Zhijin Li
// Last update Sat Sep 16 18:15:24 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/point_processes.hh"

int main()
{

  /// Definitions.
  using dtype = double;
  constexpr int dim = 3;
  using point_t = Eigen::Matrix<dtype,dim,1>;

  using pproc_t = stogeo::pps::PoissonPP<dtype,dim>;
  using pmark_t = stogeo::shapes::Ellipsoid<dtype,dim>;

  point_t origin{0.0, 0.0, 0.0};
  stogeo::shapes::Box<dtype,dim> window(origin, 51.2, 51.2, 51.2);


  /// Create mark..
  stogeo::rnd::RUniform<dtype> rnd_radius(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_a(5.0,10.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_b(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_axis_c(1.0,5.0);
  stogeo::rnd::RUniform<dtype> rnd_angle_a(0.0,3.14);
  stogeo::rnd::RUniform<dtype> rnd_angle_b(0.0,3.14);
  stogeo::rnd::RUniform<dtype> rnd_angle_c(0.0,3.14);


  pmark_t ellip_mark(origin,rnd_axis_a,rnd_axis_b,rnd_axis_c,
                     rnd_angle_a,rnd_angle_b,rnd_angle_c);

  /// Define marked pp.
  dtype inten = 2;
  pproc_t poisson(inten);


  /// MPP drawn by hand.
  stogeo::utils::reset_shared_engine(0);

  auto fld = poisson.draw(window);
  stogeo::MarkedPointPattern<pmark_t> mpp2(window,fld.n_elem());
  for(auto i = 0; i < fld.n_elem(); ++i)
    mpp2.append(ellip_mark.draw(fld.pt(i)));


  /// MPP from marked point process.
  stogeo::utils::reset_shared_engine(0);
  poisson.reset_state();

  stogeo::pps::MarkedPP<pproc_t,pmark_t> marked_pp(poisson, ellip_mark);
  auto mpp = marked_pp.draw(window);


  /// Check equality.
  if( mpp.n_elem() != mpp2.n_elem() )
  {
    std::cerr << "equality check failed.\n";
    return 1;
  }

  for(int n = 0; n < mpp.n_elem(); ++n)
  {
    if( std::fabs( (mpp.mark(n).vpack() - mpp2.mark(n).vpack()).sum() ) > 0.1 )
    {
      std::cerr << "equality check failed.\n";
      return 1;
    }
  }


  return 0;
}
