// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// discrete_ellipsoids.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Mon Jul  4 17:59:57 2016 Zhijin Li
// Last update Fri Nov 18 15:19:11 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/geometry.hh"
# include "stogeo/utilities.hh"

int main()
{

  using dtype = double;
  using vtype = float;
  constexpr int dim = 3;

  using Point = Eigen::Matrix<dtype,dim,1>;
  using ParamVec = Eigen::Matrix<dtype,9,1>;

  Point resolution{0.1, 0.1, 0.1};

  ParamVec vec_1;
  ParamVec vec_2;
  vec_1 << 24.9525, -13.06,   3.45841, 6.59169,
    1.9607, 1.36436, 1.01154,  2.86119,   0.794918;
  vec_2 << 23.6246, -14.2722, 2.94106, 4.3448,
    1.9894, 1.34225, -1.07845, -0.274571, 0.884169;

  stogeo::shapes::Ellipsoid<double,dim> ellip_1(vec_1);
  stogeo::shapes::Ellipsoid<double,dim> ellip_2(vec_2);

  auto domain = stogeo::utils::make_cmn_domain(ellip_1.bounding_box(),
                                               resolution);

  auto discrete_1 = ellip_1.discrete(domain, vtype(0), vtype(1));
  auto discrete_2 = ellip_2.discrete(domain, vtype(0), vtype(1));

  stogeo::cmn_fwditr_t<dim> it(domain);
  int good = 0;
  int total = 0;
  cmn_for_all(it)
  {
    if( discrete_1[it] == 0 || discrete_2[it] == 0 ) ++total;
    if( discrete_1[it] == 0 && discrete_2[it] == 0 ) ++good;
  }

  if( std::fabs(good/double(total) - 0.563877) > 0.1 )
  {
    std::cerr << "discretization of ellipsoids went wrong.\n";
    return 1;
  }

  return 0;
}
