// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// property_ratio.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed May 18 17:44:24 2016 Zhijin Li
// Last update Mon Nov  7 15:47:19 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/discrete.hh"
# include "mipp/io/io_raw.hh"


/// Value assigned if outside of roi.
template<typename DataType> struct outer_val
{ constexpr static DataType value = 42; };

/// Functor class to check if val = outer_val
struct not_outer_t
{
  constexpr explicit not_outer_t() {};
  template<typename DataType> bool operator()(DataType val) const
  { return val != outer_val<DataType>::value; };
};
constexpr not_outer_t not_outer{};


int main()
{
  constexpr int dim = 3;
  using dtype = float;
  using point_t = Eigen::Matrix<dtype,dim,1>;


  /// Create a global bounding box.
  point_t box_centre{0.0, 0.0, 0.0};
  point_t lengths{12.8, 12.8, 12.8};
  point_t spacings{0.1, 0.1, 0.1};
  stogeo::shapes::Box<dtype,dim> box(box_centre, lengths);
  auto domain =  stogeo::utils::make_cmn_domain(box.bounding_box(),
                                                spacings);


  /** Another box with the following geometry:
   * ---------
   * | 1 | 0 |
   * ---------
   * | 1 | 1 |
   * ---------
   * So only a 1/4 part is filled with 0.
   */
  point_t box_centre2{3.2, 3.2, 0.0};
  point_t lengths2{6.4, 6.4, 12.8};
  stogeo::shapes::Box<dtype,dim> box2(box_centre2, lengths2);
  auto discrete_box = box2.discrete(domain, dtype(0),
                                    outer_val<dtype>::value);


  /** A sphere is created with the following geometry:
   * -----------
   * | 1 |/  |  \
   * ----|-------|
   * | 1 |\  |  /
   * -----------
   * Occupying part of the region with value 1
   * and part of the region with value 0.
   */
  dtype radius = lengths(0)/2;
  point_t sphere_centre{6.4, 0.0, 0.0};
  stogeo::shapes::Sphere<dtype,dim> sphere(sphere_centre,radius);


  /// Compute overlap ratio.
  auto ratio = stogeo::discrete::property_ratio
    (discrete_box, //sphere,
     [&discrete_box, &sphere](const cmn::Point3D &pt)
     {
       return stogeo::is_zero(discrete_box[pt]) &&
         sphere.inside_test(stogeo::utils::cmn_coord_pos<dtype>
                            (discrete_box.domain(),pt));
     },
     [&discrete_box](const cmn::Point3D &pt)
     {
       return not_outer(discrete_box[pt]);
     });


  /// Test overlap ratio.
  if( std::fabs(ratio-0.531848) > 0.1 )
  {
    std::cerr << "overlap ratio computation went wrong.\n";
    return 1;
  }

  return 0;
}
