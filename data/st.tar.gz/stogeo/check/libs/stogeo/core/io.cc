// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// io.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Feb 10 18:58:11 2016 Zhijin Li
// Last update Fri Dec  8 15:44:04 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include <iostream>
# include "stogeo/discrete.hh"
# include <cstdio>


int main()
{
  /// Definitions.
  using vtype = short;
  using dtype = float;
  const std::string file_path = "__tmp.stogeo.unit.test.io";
  Eigen::Matrix<dtype,3,1> origin{128,128,128};
  Eigen::Matrix<dtype,3,1> resolution{0.388,0.388,0.388};

  using volume_t = stogeo::stg_volume_t<vtype>;

  auto size_x = 50;
  auto size_y = size_x;
  auto size_z = size_x;
  auto arr_size = size_x*size_y*size_z;


  /// Generate synthetic data.
  std::unique_ptr<vtype[]> data_arr(new vtype[arr_size]);
  stogeo::rnd::Bernoulli rnd(0.5);
  for(auto i = 0; i < arr_size; ++i)
  {
    data_arr[i] =
      (rnd.draw()?static_cast<vtype>(1):static_cast<vtype>(0));
  }


  /// Write data to file in chunk.
  stogeo::io::write_arr_to_rawfile(data_arr.get(),arr_size,file_path);


  /// Re-load data from chunk.
  /// unique_ptr pair version.
  auto data_pair = stogeo::io::read_raw_to_array<vtype>(file_path);
  auto volume_pr = std::move(std::get<1>(data_pair));
  int vol_size_pr = std::get<0>(data_pair);

  auto data_pair2 = stogeo::io::read_raw_to_array<vtype>(file_path);
  auto volume_pr2 = std::move(std::get<1>(data_pair2));


  /// Re-load data from chunk.
  /// STL vector version.
  auto volume_vc = stogeo::io::read_raw_to_vec<vtype>(file_path);
  int vol_size_vc = volume_vc.size();


  /// Test size-equality
  if(vol_size_pr != arr_size)
  {
    std::cerr << "error: unique_ptr data size non-equal." << std::endl;
    return 1;
  }
  if(vol_size_vc != arr_size)
  {
    std::cerr << "error: std::vector data size non-equal." << std::endl;
    return 1;
  }


  /// Verify ownership transfer.
  if (std::get<1>(data_pair))
  {
    std::cerr << "error: ownership not transferred to volume_pr." << std::endl;
    return 1;
  }


  // Create discrete field: unique_ptr version.
  auto latt_p = stogeo::discrete::make_discrete_field<vtype>
    (std::move(volume_pr),
     stogeo::utils::make_cmn_domain(origin, resolution,
                                    Eigen::Matrix<int,3,1>(size_x, size_y, size_z)));

  /// Verify ownership transfer.
  if (volume_pr)
  {
    std::cerr << "error: ownership not transferred to cmn::Volume." << std::endl;
    return 1;
  }


  // Create discrete field: std::vector version.
  auto latt_v = stogeo::discrete::make_discrete_field<dtype>
    (volume_vc,
     stogeo::utils::make_cmn_domain
     (origin, resolution, Eigen::Matrix<int,3,1>{size_x, size_y, size_z}));


  // Create discrete field: update to img version.
  auto vol_dom = stogeo::utils::make_cmn_domain
    (origin, resolution, Eigen::Matrix<int,3,1>{size_x, size_y, size_z});
  volume_t latt_u(vol_dom);
  stogeo::discrete::make_discrete_field<dtype>(std::move(volume_pr2), vol_dom);


  /// Equality test.
  auto count_p = 0;
  auto count_v = 0;
  auto count_u = 0;
  cmn_iter_type_(volume_t) lattp_it(latt_p.domain());
  cmn_iter_type_(volume_t) lattv_it(latt_v.domain());
  cmn_iter_type_(volume_t) lattu_it(latt_v.domain());

  cmn_for_all(lattp_it)
  {
    if(count_p != stogeo::utils::cmn_itr_ind(lattp_it))
    {
      std::cerr << "error: indexing mismatch." << std::endl;
      return 1;
    }

    if(latt_p[lattp_it] !=
       data_arr[stogeo::utils::cmn_itr_ind(lattp_it)])
    {
      return 1;
    }
    ++count_p;
  }

  cmn_for_all(lattv_it)
  {
    if(count_v != stogeo::utils::cmn_itr_ind(lattv_it))
    {
      std::cerr << "error: indexing mismatch." << std::endl;
      return 1;
    }

    if(latt_v[lattv_it] !=
       data_arr[stogeo::utils::cmn_itr_ind(lattv_it)])
    {
      std::cerr << "error: data value non-equal." << std::endl;
      return 1;
    }
    ++count_v;
  }

  cmn_for_all(lattu_it)
  {
    if(count_u != stogeo::utils::cmn_itr_ind(lattu_it))
    {
      std::cerr << "error: indexing mismatch." << std::endl;
      return 1;
    }

    if(latt_p[lattu_it] !=
       data_arr[stogeo::utils::cmn_itr_ind(lattu_it)])
    {
      return 1;
    }
    ++count_u;
  }


  std::remove(file_path.c_str());


  return 0;
}
