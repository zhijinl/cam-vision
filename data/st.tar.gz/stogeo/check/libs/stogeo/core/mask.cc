// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// mask.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Jul 12 09:37:43 2016 Zhijin Li
// Last update Fri Nov 18 15:19:56 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/geometry.hh"
# include "mipp/io/io_raw.hh"


int main()
{

  using dtype = float;
  constexpr int dim = 2;
  using Point = Eigen::Matrix<dtype,dim,1>;

  /// Create a Box, size (0.9,0.9) centerred at (0.45, 0.45)
  Point centre{0.45, 0.45};
  Point lengths{0.9, 0.9};
  stogeo::shapes::Box<dtype,dim> box(centre, lengths);


  /// Create a single point pattern: append point at each lattice site
  /// starting from box's origin -> at 0.1 step.
  stogeo::SimplePointPattern<dtype,dim> pts(box);

  dtype step = 0.1;
  for( dtype i = 0.0f; i <= lengths(0); i += step)
    for( dtype j = 0.0f; j <= lengths(1); j += step)
        pts.append(Point{i,j});


  /// Check if the number is right.
  if( pts.n_elem() != ((lengths.array()/step)
                       .template cast<int>()).prod() )
  {
    std::cerr << "Something wrong with points"
              << " insertion: wrong total number.\n";
    return 1;
  }


  /// Create a sphere in the same bounding box, at the same center.
  /// With radius = 0.2; Discretize with fine-resolution.
  Point resolution{0.01, 0.01};
  stogeo::shapes::Sphere<dtype,dim> sphere(centre, 0.2);
  auto mask = sphere.discrete(resolution, dtype(0), dtype(1));


  /// Apply sphere mask. Compare with analytical slicing.
  stogeo::SimplePointPattern<dtype,dim> rep_pts(pts);
  rep_pts.restrict(sphere);
  pts.masking(mask);


  /// Check analytical restrict & discrete masking results.
  if( rep_pts.n_elem() != 12 )
  {
    std::cerr << "Analytical restrict yields wrong result.\n";
    return 1;
  }
  if( pts.n_elem() != 12 )
  {
    std::cerr << "Masking yields wrong result.\n";
    return 1;
  }

  return 0;
}
