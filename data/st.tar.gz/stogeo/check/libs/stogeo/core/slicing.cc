// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// slicing.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 25 20:21:04 2016 Zhijin Li
// Last update Fri Nov 18 15:21:37 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/geometry.hh"
# include "stogeo/utilities.hh"


int main()
{
  /// Defs.
  using dtype = float;
  constexpr int dim = 3;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Create vectors for slicing: note -> in-place slicing works only for
  /// dynamic vectors (Eigen).
  Eigen::Matrix<int,1,-1> int_vec(10);
  std::vector<int> int_vec_stl(10);

  std::iota(int_vec.data(), int_vec.data()+int_vec.size(), 0);
  std::iota(int_vec_stl.begin(), int_vec_stl.end(), 0);

  Eigen::Matrix<int,1,-1> int_vec2(int_vec);
  std::vector<int> int_vec_stl2(int_vec_stl);


  /// Define slicing vectors.
  std::vector<short> logical_stl(10);
  Eigen::Matrix<bool,10,1> logical_eig;
  for(int n = 0; n < 10; ++n)
    if(n%2 == 0)
    {
      logical_stl[n] = 42;
      logical_eig(n) = false;
    } else
    {
      logical_stl[n] = 0;
      logical_eig(n) = true;
    }

  stogeo::utils::logical_slice(int_vec, logical_stl, 42);
  stogeo::utils::logical_slice(int_vec_stl, logical_stl, 42);

  stogeo::utils::logical_slice(int_vec2, logical_eig);
  stogeo::utils::logical_slice(int_vec_stl2, logical_eig);


  /// Check correctness.
  if( int_vec.size() != 5 || int_vec_stl.size() != 5 ||
      int_vec2.size() != 5 || int_vec_stl2.size() != 5 )
  {
    std::cerr << "logical slice went wrong: size mismatch.\n";
    return 1;
  }
  for(int n = 0; n < 5; ++n)
  {
    if( int_vec(n)%2 != 0 ||  int_vec_stl[n]%2 != 0 )
    {
      std::cerr << "logical slice (42) went wrong: value mismatch.\n";
      return 1;
    }

    if( int_vec2(n)%2 == 0 ||  int_vec_stl2[n]%2 == 0 )
    {
      std::cerr << "logical slice (true) went wrong: value mismatch.\n";
      return 1;
    }
  }


  /// Define a geometric pattern with two spheres.
  Point origin     {0.0, 0.0, 0.0};
  Point center_1   {0.25, 0.25, 0.25};
  Point center_2   {0.75, 0.25, 0.25};
  Point roi_sides  {1.0, 0.5, 0.5};
  Point box_lengths{0.5, 0.5, 0.5};

  stogeo::shapes::Box<dtype,dim> window(origin, roi_sides);
  stogeo::MarkedPointPattern<stogeo::shapes::Box<dtype,dim> > pattern(window);
  pattern.append(center_1, box_lengths);
  pattern.append(center_1, box_lengths); // append twice box_1.
  pattern.append(center_2, box_lengths);

  Point test_2{0.6, 0.3, 0.3};
  stogeo::SimplePointPattern<dtype,dim> pts_1;
  pts_1.append(0.3f, 0.3f, 0.3f);
  pts_1.append(test_2);
  pts_1.append(test_2); // append twice test_2.
  stogeo::SimplePointPattern<dtype,dim> pts_2(pts_1);


  /// Three points should all fall inside.
  pts_1.restrict(pattern);
  if( pts_1.n_elem() != 3 )
  {
    {
      std::cerr << "Something went wrong with pts/geometric pattern.\n";
      return 1;
    }
  }


  /// Only the second falls inside after slicing.
  Eigen::Matrix<bool,3,1> slicer{false, true, true};
  pattern.slicing(slicer);
  pattern.remove(0); // only box_2 is left now.

  pts_2.restrict(pattern);
  pts_2.remove(0);
  if( pts_2.n_elem() != 1 )
  {
    std::cerr << "Something went wrong with geometric pattern slicing.\n";
    return 1;
  }
  for(int d = 0; d < dim; ++d)
  {
    if( !stogeo::utils::f_equal((pts_2.pt(0) - test_2).norm(),dtype(0)) )
    {
      std::cerr << "Something went wrong with geometric pattern slicing.\n";
      return 1;
    }
  }


  return 0;
}
