// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// conv.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Dec  9 16:26:40 2015 Zhijin Li
// Last update Thu Oct 12 16:29:46 2017 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/point_processes.hh"


int main()
{

  /// Definitions.
  using dtype = float;
  constexpr int dim = 3;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Create type i, ii, iii processes.
  Point obs_ctre;
  Point obs_size;
  dtype intensity = 0.1;
  dtype hc_dist = 3.0;
  for(std::size_t i = 0; i < dim; ++i) obs_ctre(i) = 0.0;
  for(std::size_t i = 0; i < dim; ++i) obs_size(i) = 51.2;
  stogeo::shapes::Box<dtype,dim> window(obs_ctre,obs_size);

  stogeo::pps::MaternHardPP<dtype,dim,stogeo::mtn_hc::TypeI>
    mtn_hc_i  (hc_dist, intensity);
  stogeo::pps::MaternHardPP<dtype,dim,stogeo::mtn_hc::TypeII>
    mtn_hc_ii (hc_dist, intensity);
  stogeo::pps::MaternHardPP<dtype,dim,stogeo::mtn_hc::TypeIII>
    mtn_hc_iii(hc_dist, intensity);


  /// Draw realizations.
  stogeo::utils::reset_shared_engine(0);
  auto fld_type_i         = mtn_hc_i.draw(window);

  stogeo::utils::reset_shared_engine(0);
  auto fld_type_ii_extra  = mtn_hc_ii.draw(stogeo::extra,window);

  stogeo::utils::reset_shared_engine(0);
  auto fld_type_iii_extra = mtn_hc_iii.draw(stogeo::extra,window);


  /// Check hardcore constraint.
  stogeo::shapes::Sphere<dtype,dim> sphere(hc_dist);

  for(auto i = 0; i < fld_type_i.n_elem(); ++i)
    if( sphere.move_to(fld_type_i.pt(i)).inside_test(fld_type_i.pts()).count() > 1 )
    {
      std::cerr << "hardcore constaint failed type i.\n";
      return 1;
    }

  for(auto i = 0; i < fld_type_i.n_elem(); ++i)
    if( sphere.move_to(fld_type_ii_extra.pt(i)).
        inside_test(fld_type_ii_extra.pts()).count() > 1 )
    {
      std::cerr << "hardcore constaint failed type ii.\n";
      return 1;
    }

  for(auto i = 0; i < fld_type_i.n_elem(); ++i)
    if( sphere.move_to(fld_type_iii_extra.pt(i)).
        inside_test(fld_type_iii_extra.pts()).count() > 1 )
    {
      std::cerr << "hardcore constaint failed type iii.\n";
      return 1;
    }


  /// Check intensity.
  if( fld_type_i.n_elem() > fld_type_ii_extra.n_elem() ||
      fld_type_ii_extra.n_elem() > fld_type_iii_extra.n_elem() )
  {
    std::cerr << "intensity check failed.\n";
    return 1;
  }


  return 0;
}
