// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// rot.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Feb 25 21:40:17 2016 Zhijin Li
// Last update Fri Nov 18 15:22:17 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/utilities.hh"


int main()
{

  using dtype = double;


  /// Test for 3D.
  constexpr int dim = 3;
  using Point = Eigen::Matrix<dtype,dim,1>;

  cmn::Domain3D grid(62,62,62,0,0.1,0.1,0.1,-31,-31,-31);
  cmn::FwdIterator3D it(grid);

  cmn_for_all(it)
  {
    Point angles = stogeo::utils::cmn_itr_pos<dtype>(it);
    auto rot_mat = stogeo::utils::comp_rotmat(angles);

    auto re_angles = stogeo::utils::comp_rot_angles(rot_mat);
    auto re_mat = stogeo::utils::comp_rotmat(re_angles);

    if( (rot_mat-re_mat).array().sum() > 1e-4)
    {
      std::cerr << "rotation angles computation failed.\n";
      return 1;
    }
  }


  /// Test for 2D.
  constexpr int dim2 = 3;
  using Point2 = Eigen::Matrix<dtype,dim2,1>;

  cmn::Domain3D grid2(62,62,0,0.1,0.1,-31,-31);
  cmn::FwdIterator3D it2(grid2);

  cmn_for_all(it2)
  {
    Point2 angles = stogeo::utils::cmn_itr_pos<dtype>(it);
    auto rot_mat = stogeo::utils::comp_rotmat(angles);

    auto re_angles = stogeo::utils::comp_rot_angles(rot_mat);
    auto re_mat = stogeo::utils::comp_rotmat(re_angles);

    if( (rot_mat-re_mat).array().sum() > 1e-4)
    {
      std::cerr << "rotation angles computation failed.\n";
      return 1;
    }
  }

  return 0;
}
