// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// sampler.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Mar  1 10:40:49 2016 Zhijin Li
// Last update Fri Nov 18 15:21:46 2016 Zhijin Li
// ---------------------------------------------------------------------------


#include "stogeo/core.hh"
#include "stogeo/statistics.hh"


int main()
{
  using dtype = float;
  using Vec = Eigen::Matrix<dtype,-1,1>;


  /// Sampling from a Gaussian distribution.
  dtype mean = 5.0;
  dtype stdv = 10.0;
  stogeo::rnd::Gaussian<dtype> gauss_rv(mean,stdv);

  constexpr int n_samples = 5e3;
  Vec samples(n_samples);
  Vec inv_samples(n_samples);
  Vec rej_samples(n_samples);

  gauss_rv.draw(samples);


  /// Constructed inverse & reject sampler.
  stogeo::stats::InverseSampler<dtype,1> inv_smplr;
  stogeo::stats::RejectSampler<dtype,1> rej_smplr;
  inv_smplr.bind(samples);
  rej_smplr.bind(samples);


  /// Do sampling from empirical estimation.
  inv_smplr.draw(inv_samples);
  rej_smplr.draw(rej_samples);


  auto inv_mean = inv_samples.mean();
  auto inv_stdv = std::sqrt(stogeo::stats::var<dtype>(inv_samples));
  auto rej_mean = rej_samples.mean();
  auto rej_stdv = std::sqrt(stogeo::stats::var<dtype>(rej_samples));

  std::cout << "Inverse Sampler mean: " << inv_mean << '\n';
  std::cout << "Inverse Sampler stdv: " << inv_stdv << '\n';

  std::cout << "Inverse Sampler mean: " << rej_mean << '\n';
  std::cout << "Inverse Sampler stdv: " << rej_stdv << '\n';

  /// Check sampling corectness.
  if( std::fabs(inv_mean - mean) > mean/2.0 ||
      std::fabs(inv_stdv - stdv) > stdv/4.0 )
  {
    std::cerr << "Inverse sampling robustness test failed.\n";
  }
  if( std::fabs(rej_mean - mean) > mean/2.0 ||
      std::fabs(rej_stdv - stdv) > stdv/4.0 )
  {
    std::cerr << "Rejection sampling robustness test failed.\n";
  }

  return 0;
}
