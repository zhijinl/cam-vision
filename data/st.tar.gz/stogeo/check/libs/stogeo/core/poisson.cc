// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// poisson.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Tue Aug 11 15:41:25 2015 Zhijin Li
// Last update Thu Oct 12 22:17:17 2017 Zhijin Li
// ---------------------------------------------------------------------------


#include <iostream>
#include <chrono>
#include "stogeo/point_processes.hh"


/// Test script for Poisson pp simulation.


/// Functor for retention probability.
class functor
{
public:
  double operator()(const Eigen::Matrix<double,3,1> &coord)
  {
    /// r_proba = 1e-2 for locations depassing a spherical region with radius 15.
    /// r_proba = 1e-1 otherwise.
    return(double(coord(0)*coord(0)+coord(1)*coord(1)+coord(2)*coord(2))>15.0*15.0?
           1e-2:1e-1);
  }
};

int main()
{
  /// Convenient definitions & typedefs.
  constexpr std::size_t dim = 3;
  using dtype = double;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Params of a Poisson pp.
  dtype intensity = 1;/// Intensity param.
  dtype r_probability = 1e-3;/// Retention probability for thinning.
  Point obs_ctre;/// Observation centre of pp.
  Point obs_size;/// Observation size of pp.

  /// Initialize centre and size.
  for(std::size_t i = 0; i < dim; ++i) obs_ctre(i) = 0.0;
  for(std::size_t i = 0; i < dim; ++i) obs_size(i) = 51.2;
  stogeo::shapes::Sphere<dtype,dim> window(obs_ctre,20.0);


  /// Creation of a Poisson pp:
  /// Construct an unit rate Poisson pp MODEL.
  stogeo::pps::PoissonPP<dtype,dim> ppp(intensity);
  /// Run a realization: into a point pattern.
  auto fld = ppp.draw(window);

  if( std::abs(fld.n_elem()/window.volume()-1) > 0.2 )
  {
    std::cerr << "poisson intensity pp went wrong.\n";
    return 1;
  }


  /// Perform thinnings on fld:
  /// An independent thinning: p-thinning.
  stogeo::SimplePointPattern<dtype,dim> p_thinned(fld);
  p_thinned.thinning(r_probability);
  /// An independent thinning: p(x)-thinning.
  stogeo::SimplePointPattern<dtype,dim> px_thinned(fld);
  px_thinned.thinning(functor());


  /// Check p-thinning correctness.
  if( std::fabs(double(p_thinned.n_elem())/fld.n_elem() - 1e-3) > 1e-3 )
  {
    std::cerr << "p-thinning went wrong: precision test failed.\n";
    return 1;
  }


  /// Check p(x)-thinning correctness.
  stogeo::shapes::Sphere<dtype,dim> Sphere(15.0);
  stogeo::SimplePointPattern<dtype,dim> outside_before(fld);
  stogeo::SimplePointPattern<dtype,dim> inside_before(fld);
  outside_before.exclude(Sphere);
  inside_before.restrict(Sphere);
  stogeo::SimplePointPattern<dtype,dim> outside_after(px_thinned);
  stogeo::SimplePointPattern<dtype,dim> inside_after(px_thinned);
  outside_after.exclude(Sphere);
  inside_after.restrict(Sphere);

  if( std::fabs(double(outside_after.n_elem())/outside_before.n_elem() - 1e-2) > 1e-2 ||
      std::fabs(double(inside_after.n_elem())/inside_before.n_elem() - 1e-1) > 1e-1 )
  {
    std::cout << double(outside_after.n_elem())/outside_before.n_elem() << std::endl;
    std::cout << double(inside_after.n_elem())/inside_before.n_elem() << std::endl;

    std::cerr << "p(x)-thinning went wrong: precision test failed.\n";
    return 1;
  }


  /// A pp can also be constrained by geometric shapes / patterns:
  stogeo::shapes::Ellipsoid<dtype,dim> ellip(15,5,5,0,0,0);
  ellip.rotate(1,2,3);
  stogeo::MarkedPointPattern<decltype(ellip)> pattern(window);
  pattern.append(ellip);
  /// Restrict fld to points within the sphere.
  stogeo::SimplePointPattern<dtype,dim> shape_constrained(fld);
  shape_constrained.restrict(ellip);
  stogeo::SimplePointPattern<dtype,dim> pattern_constrained(fld);
  pattern_constrained.restrict(pattern);


  /// Check geometric constraint correctness.
  if( shape_constrained.n_elem() != pattern_constrained.n_elem() )
  {
    std::cerr << "geometric constraint went wrong.\n";
    return 1;
  }

  for(int n = 0; n < shape_constrained.n_elem(); ++n)
  {
    if( shape_constrained.pt(n) != pattern_constrained.pt(n) )
    {
      std::cerr << "geometric constraint went wrong.\n";
      return 1;
    }
  }

  return 0;
}
