// ---------------------------------------------------------------------------
// Copyright (c) 2015 by General Electric Medical Systems
//
// mpp.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Wed Aug 12 18:48:15 2015 Zhijin Li
// Last update Fri Nov 18 15:20:28 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/core.hh"
# include "stogeo/point_patterns.hh"
# include "stogeo/point_processes.hh"


int main()
{
  /// Convenient definitions & typedefs.
  using dtype = float;
  constexpr int dim = 3;
  using Point = Eigen::Matrix<dtype,dim,1>;


  /// Create point centers.
  Point obs_ctre;
  Point obs_size;
  for(std::size_t i = 0; i < dim; ++i) obs_ctre(i) = 25.6;
  for(std::size_t i = 0; i < dim; ++i) obs_size(i) = 51.2;

  int n_init = 1000000;
  stogeo::rnd::RUniform<dtype> loc_rv(0.0,51.2);
  stogeo::shapes::Box<dtype,dim> window(obs_ctre,obs_size);
  stogeo::SimplePointPattern<dtype,dim> pts_locs(window, n_init);
  loc_rv.draw(pts_locs.pts());


  /// Test slicing.
  dtype thinning_pr = 1e-4;
  pts_locs.thinning(thinning_pr);


  /// Ellipsoid mark specs.
  dtype axis_a = 5;
  dtype axis_b = 2;
  dtype axis_c = 2;
  dtype angle_a = 0;
  dtype angle_b = 0;
  dtype angle_c = 0;


  /// Construct ellip marked point pattern.
  //  Construction via append.
  int n_pts = pts_locs.n_elem();
  stogeo::MarkedPointPattern<stogeo::shapes::Ellipsoid<dtype,dim> >
    ellip_mpp_a(window);

  for(auto i = 0; i < n_pts; ++i)
    ellip_mpp_a.append(pts_locs.pt(i),
                       axis_a,
                       axis_b,
                       axis_c,
                       angle_a,
                       angle_b,
                       angle_c);


  // Construction via matrix pack.
  Eigen::Matrix<dtype,4*dim-3,-1> mat_pack(4*dim-3,n_pts);
  mat_pack.block(0,0,dim,n_pts) = pts_locs.pts();
  mat_pack.row(3).setConstant(axis_a);
  mat_pack.row(4).setConstant(axis_b);
  mat_pack.row(5).setConstant(axis_c);
  mat_pack.row(6).setConstant(angle_a);
  mat_pack.row(7).setConstant(angle_b);
  mat_pack.row(8).setConstant(angle_c);

  stogeo::MarkedPointPattern<stogeo::shapes::Ellipsoid<dtype,dim> >
   ellip_mpp_m(window,mat_pack);

  // Construction via mark vec.
  // Note this needs Eigen's aligned_allocator which is annoying.
  using alloc_t =
    Eigen::aligned_allocator<stogeo::shapes::Ellipsoid<dtype,dim> >;
  std::vector<stogeo::shapes::Ellipsoid<dtype,dim>,alloc_t> mark_vec;
  for(auto i = 0; i < n_pts; ++i)
  {
    mark_vec.emplace_back(pts_locs.pt(i),
                           axis_a,
                           axis_b,
                           axis_c,
                           angle_a,
                           angle_b,
                           angle_c);
  }
  stogeo::MarkedPointPattern<stogeo::shapes::Ellipsoid<dtype,dim> >
    ellip_mpp_v(window,mark_vec);


  /// Equality check.
  for(auto g = 0; g < n_pts; ++g)
  {
    if( ellip_mpp_a.mark(g).vpack() != ellip_mpp_m.mark(g).vpack() ||
        ellip_mpp_a.mark(g).vpack() != ellip_mpp_v.mark(g).vpack() )
    {
      std::cerr << "marks values differ." << std::endl;
      return 1;
    }
  }


  /// Check window alternation.
  stogeo::shapes::Sphere<dtype,dim> spher(obs_ctre,20.0);
  ellip_mpp_v.set_window(spher);


  return 0;
}
