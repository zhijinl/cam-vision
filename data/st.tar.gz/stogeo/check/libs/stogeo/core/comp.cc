// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// comp.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Sun Feb 21 02:00:21 2016 Zhijin Li
// Last update Thu Sep  7 13:30:18 2017 Zhijin Li
// ---------------------------------------------------------------------------

# include "Eigen/Dense"
# include "stogeo/core.hh"
# include "stogeo/utilities.hh"

int main()
{

  /// Roll some vectors.
  using dtype = double;
  int n_samples = 1e5;


  /// Random vectors.
  Eigen::Matrix<dtype,Eigen::Dynamic,1> rnd_vec =
    Eigen::Matrix<dtype,Eigen::Dynamic,1>::Random(n_samples);

  std::vector<dtype> rnd_vec_stl;
  rnd_vec_stl.reserve(n_samples);
  for(int n = 0; n < n_samples; ++n) rnd_vec_stl.push_back(rnd_vec(n));
  for(int n = 0; n < rnd_vec.size(); ++n)
  {
    if( rnd_vec_stl[n] != rnd_vec(n) )
    {
      std::cerr << "vector copy failed.\n";
      return 1;
    }
  }


  /// Int vectors with ones.
  Eigen::Matrix<int,1,-1> int_vec = Eigen::Matrix<int,1,-1>::Ones(n_samples);

  std::vector<int> int_vec_stl(n_samples);
  std::fill(int_vec_stl.begin(), int_vec_stl.end(), 1);


  /// Test cumsum results.
  auto cum_int = stogeo::utils::cumsum(int_vec);
  auto cum_int_stl = stogeo::utils::cumsum(int_vec_stl);

  for(int i = 0; i < cum_int.size(); ++i)
  {
    if( cum_int(i) != i+1 || cum_int_stl[i] != i+1 )
    {
      std::cerr << "cumsum results went wrong..\n";
      return 1;
    }
  }


  /// Do ascendant & descendant indexing.
  auto indexing_a = stogeo::utils::ascend_indexing(rnd_vec);
  auto indexing_b = stogeo::utils::descend_indexing(rnd_vec);
  auto indexing_a2 = stogeo::utils::ascend_indexing(rnd_vec_stl);
  auto indexing_b2 = stogeo::utils::descend_indexing(rnd_vec_stl);


  /// Check ordering correctness of ascendant indexing.
  if( std::adjacent_find(indexing_a.data(),
                         indexing_a.data()+indexing_a.size(),
                         [&rnd_vec](int prev, int next)
                         { return rnd_vec(prev) > rnd_vec(next); })
      != indexing_a.data()+indexing_a.size() )
  {
    std::cerr << "ascend indexing order failure.\n";
    return 1;
  }
  if( std::adjacent_find(indexing_a2.data(),
                         indexing_a2.data()+indexing_a.size(),
                         [&rnd_vec](int prev, int next)
                         { return rnd_vec(prev) > rnd_vec(next); })
      != indexing_a2.data()+indexing_a2.size() )
  {
    std::cerr << "ascend indexing order failure.\n";
    return 1;
  }


  /// Check ordering correctness of descendant indexing.
  if( std::adjacent_find(indexing_b.data(),
                         indexing_b.data()+indexing_b.size(),
                         [&rnd_vec](int prev, int next)
                         { return rnd_vec(prev) < rnd_vec(next); })
      != indexing_b.data()+indexing_b.size() )
  {
    std::cerr << "descend indexing order failure.\n";
    return 1;
  }
  if( std::adjacent_find(indexing_b2.data(),
                         indexing_b2.data()+indexing_b.size(),
                         [&rnd_vec](int prev, int next)
                         { return rnd_vec(prev) < rnd_vec(next); })
      != indexing_b2.data()+indexing_b2.size() )
  {
    std::cerr << "descend indexing order failure.\n";
    return 1;
  }


  /// Check propagation of types.
  Eigen::Matrix<int,1,10> fixed_int_vec = Eigen::Matrix<int,1,10>::Ones();
  auto __tmp_cum = stogeo::utils::cumsum(fixed_int_vec);
  auto __tmp_asc = stogeo::utils::ascend_indexing(fixed_int_vec);
  auto __tmp_des = stogeo::utils::descend_indexing(fixed_int_vec);

  if( stogeo::eigen_cols_v<decltype(__tmp_cum)>() != 10 ||
      stogeo::eigen_cols_v<decltype(__tmp_asc)>() != 10 ||
      stogeo::eigen_cols_v<decltype(__tmp_des)>() != 10 )
  {
    std::cerr << "something went wrong with fixed size propagation..\n";
    return 1;
  }

  return 0;
}
