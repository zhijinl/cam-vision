// ---------------------------------------------------------------------------
// Copyright (c) 2016 by General Electric Medical Systems
//
// poisson_inhomo.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Sep 22 15:13:05 2016 Zhijin Li
// Last update Fri Nov 18 15:20:49 2016 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/point_processes.hh"
# include "stogeo/statistics.hh"


struct IntenFunc
{
  template<typename Point> float operator()(Point &&pt) const
  {
    float sigma = 10;
    Eigen::Matrix<float,2,1> origin{0, 0};
    return 10*std::exp(-(pt-origin).squaredNorm()/(sigma*sigma));
  }
};


int main()
{

  // Set random engine for test reproducibility.
  stogeo::utils::reset_shared_engine(0);

  // Setups.
  using dtype = float;

  constexpr int dim = 2;
  Eigen::Matrix<dtype,2,1> origin{0, 0};
  Eigen::Matrix<dtype,2,1> lattice_spacing{0.2, 0.2};
  stogeo::shapes::Sphere<dtype,dim> sphere(origin, 30.0);

  // Draw Poisson samples w/ inhomogeneous intensity function.
  auto ppp_inhomo = stogeo::pps::PoissonPP<dtype,dim,IntenFunc>
    (sphere, stogeo::pps::IntenFun_f<IntenFunc>(IntenFunc{}));
  auto samples = ppp_inhomo.draw();

  // Estimate intensity function using Gaussian KS.
  stogeo::stats::GaussianKS<dtype,dim> ks_estimator;
  stogeo::discrete::Lattice<dtype,dim> lattice(sphere.bounding_box(),
                                               lattice_spacing);
  auto inten_estim = ks_estimator.estimate
    (stogeo::inten, samples.pts(), stogeo::stats::Support<dtype,dim>(lattice));

  // Evaluate error.
  double mse = 0.0;
  for(int n = 0; n < inten_estim.n_elem(); ++n)
    mse += std::pow(inten_estim.value_at(n)-IntenFunc{}(inten_estim.point_at(n)),2);

  // Accuracy test.
  if( std::abs(mse/inten_estim.n_elem() - 0.0275) > 0.01 )
  {
    std::cerr << "Sample intensity not accurate enough.\n";
    return 1;
  }

  return 0;
}
