// ---------------------------------------------------------------------------
// Copyright (c) 2018 by General Electric Medical Systems
//
// config_parser.cc for StoGeo
//
// Made by Zhijin Li
// Mail:   <jonathan.li@ge.com>
//
// Started on  Thu Mar 22 17:57:47 2018 Zhijin Li
// Last update Fri Mar 23 11:09:58 2018 Zhijin Li
// ---------------------------------------------------------------------------


# include "stogeo/utilities.hh"


int main()
{

  using dtype = double;
  using vectr_t = Eigen::Matrix<dtype,Eigen::Dynamic,1>;

  std::string input = "{3.14, 1.57, 0.0} | {0.0} | {1.0} | {2.0} | {3.0}";
  stogeo::utils::rm_spaces(input);

  auto tokens = stogeo::utils::tokenize(input);

  std::cout << tokens[0] << '\n';
  std::cout << tokens[1] << '\n';
  std::cout << tokens[2] << '\n';
  std::cout << tokens[3] << '\n';
  std::cout << tokens[4] << '\n';

  std::vector<vectr_t> truth
  {
    (vectr_t(3) << 3.14, 1.57, 0.0).finished(),
      (vectr_t(1) << 0.0).finished(),
      (vectr_t(1) << 1.0).finished(),
      (vectr_t(1) << 2.0).finished(),
      (vectr_t(1) << 3.0).finished()
      };

  for( std::size_t n = 0; n < tokens.size(); ++n )
  {
    auto &&elem = tokens[n];
    auto res = stogeo::utils::parse_list_as_pt<dtype>(elem);
    std::cout << res.transpose() << '\n';

    if( res != truth[n] )
    {
      std::cerr << "point parsing went wrong. TRUTH: "
                << truth[n] << " | " << "PARSED: "
                << res << '\n';
      return 1;
    }
  }

  return 0;
}
