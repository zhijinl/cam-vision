#!/bin/sh
## ---------------------------------------------------------------------------
## Copyright (c) 2011, 2012, 2013, 2014 by General Electric Medical Systems
##
## gen_sanity_rules.sh for har
## 
## Made by Giovanni Palma
## Mail:   <giovanni.palma@ge.com>
## 
## Started on  Wed Aug 24 16:30:31 2011 Giovanni Palma
## Last update Wed Nov 26 14:09:51 2014 Giovanni Palma
## ---------------------------------------------------------------------------
progs=""
tests=""

for i in `\ls $1/*.hh`
do
    h=`basename $i`
    t=sanity_`echo $h | sed s/\\.hh//g`
    if [ ! -f $t.cc ] ; 
    then 
	echo "#include <$3$h>" > $t.cc
	echo "int main(){}" >> $t.cc
    fi
done

src_list=

for i in `\ls *.cc | grep -v \~`
do
    src_list="$src_list `basename $i`"
done

for i in `echo $src_list | sed s/" "/'\n'/g | sort -u`
do
    p=`basename $i`
    t=`echo $p | sed s/\\\\.cc//g`
    progs="$progs $t"
    tests="$tests test_$t"
    echo `echo -n $t| sed s/"-"/_/g`"_SOURCES="$t.cc 
done


echo "check_PROGRAMS=$progs"
echo "TEST=$tests"

