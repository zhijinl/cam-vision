#!/bin/bash
## ---------------------------------------------------------------------------
## Copyright (c) 2007-2015 by General Electric Medical Systems
##
## check.sh for geip
## 
## Made by Giovanni Palma
## Mail:   <giovanni.palma@ge.com>
## 
## Started on  Wed Jul 25 18:21:24 2007 Giovanni Palma
## Last update Mon Sep 28 14:00:51 2015 Giovanni Palma
## ---------------------------------------------------------------------------

red='\033[0;31m'
red_no_b='\033[0;31m'
RED='\[\e[1;31m\]'
green='\e[0;32m'
GREEN='\[\e[1;32m\]'
blue='\e[0;34m'
BLUE='\[\e[1;34m\]'
cyan='\[\e[0;36m\]'
CYAN='\[\e[1;36m\]'
yellow='\[\e[0;33m\]'
END='\e[m'
tests=$1
verbose=$2
output_status=0

if [ -z $tests ]
then
    tests=`\ls *.cc | sed s/'\.cc'//g`
fi

for t in $tests
do
  echo -n test for $t ...
  log=$t.log

  if [ "$verbose" = 1 ]
      then
      \time -f"%e" ./$t
      status=`echo $?`
  else
      \time -f"%e" ./$t  > $log 2>&1 
      status=`echo $?`
      run_time=`tail -n 1 $log`
  fi

  if [ $status = 0 ]
      then
      echo -e "("$run_time"s)" $green PASSED $END  
      rm $log
  else
      echo -e "("$run_time"s)" $red FAILED $END
      output_status=1
  fi

done

exit $output_status
