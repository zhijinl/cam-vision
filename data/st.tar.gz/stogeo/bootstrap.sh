#!/bin/bash
## ---------------------------------------------------------------------------
## Copyright (c) 2011-2016 by General Electric Medical Systems
##
## bootstrap.sh for StoGeo
##
## Made by Giovanni Palma
## Mail:   <giovanni.palma@ge.com>
##
## Started on  Tue Aug 23 18:15:30 2011 Giovanni Palma
## Last update Fri Jun 29 15:49:50 2018 Zhijin Li
## ---------------------------------------------------------------------------

# definitions of dependencies
CMN_VERSION=2.1.5
MIPP_VERSION=1.1.3

# some internal defs
SRC_DIR=`dirname $0`
BUILD_DIR=`pwd`

# Init autotools
function init_autotools()
{
    cd $SRC_DIR
    echo > libs/stogeo/.hdr.mk
    echo > check/libs/stogeo/core/.tests.mk
    echo > check/libs/stogeo/sanity/.tests.mk

    sleep 1
    aclocal -I m4
    autoheader
    libtoolize --force
    automake --add-missing
    autoconf -f
}


# Unpack a package into the current directory
function unpack()
{
    name=$1
    version=$2
    hw=$3
    if [ $version = "no" ]
    then
        echo discarding $name
    else
        if [ $version = "latest" ]
        then
            filename=`\ls $PATH_TO_RPKGS/$name-*-$hw*.tar.gz | \sort -V | \tail -n 1`
        else
            filename=$PATH_TO_RPKGS/$name-$version-$hw*.tar.gz
        fi
        echo -n unpacking $filename...
        tar zxf $filename || exit 1
        echo done
    fi
}

# Retrieve and extract dependencies
function extract_deps()
{
    PATH_TO_RPKGS=$1
    PATH_TO_LOCAL=$2
    HW=`uname -i`
    export https_proxy=""

    if [ ! -d "$PATH_TO_LOCAL" ]; then
        echo "creating dir: "$PATH_TO_LOCAL
        mkdir $PATH_TO_LOCAL
    fi

    cd $PATH_TO_LOCAL

    unpack common $CMN_VERSION $HW
    unpack mipp $MIPP_VERSION $HW
}

# launch the configure
function configure()
{
    cd $BUILD_DIR
    $SRC_DIR/configure --with-common=$1 --with-mipp=$1 --prefix=$1 "${CONFIGURE_ARGS[@]}"
}

# Usage help
function show_help()
{
    echo usage "$0 PATH_TO_DEPENDENCIES LOCAL_DIR [LIB_VERSION=x.y.z ...]"
    exit 1
}

# main part of the script
if [ $# -lt 2 ]
then
    show_help
fi

PATH_TO_DEPENDENCIES=$1
LOCAL_DIR=$2


shift 2
CONFIGURE_ARGS=("$@")

while [ "$1" != "" ]
do
    var=`echo $1 | sed -E s/=.*//g`

    if [ `echo -n $var | grep VERSION` ]
    then
        val=`echo $1 | sed s/$var=//g|sed s/" "/"\ "/g`
        eval $var='$val'
    fi
    shift
done

extract_deps $PATH_TO_DEPENDENCIES $LOCAL_DIR
init_autotools
configure $LOCAL_DIR
